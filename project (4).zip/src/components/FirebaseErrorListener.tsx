'use client';

/**
 * @fileOverview Firestore izin hatalarını Next.js hata ekranında göstermek için dinleyici.
 */

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';

export function FirebaseErrorListener() {
  useEffect(() => {
    const unsub = errorEmitter.on('permission-error', (error) => {
      // Geliştirme aşamasında hatayı Next.js overlay'e fırlatır
      console.error("Firebase Security Error Detected:", error);
      throw error;
    });
    return unsub;
  }, []);

  return null;
}
