
'use client';

import Link from "next/link";
import { Wallet, MessageSquare, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Request } from "@/lib/sample-data";

interface RequestCardProps {
  request: Request;
}

export function RequestCard({ request }: RequestCardProps) {
  const [city, district] = (request.location || "").split(' / ');

  return (
    <Card className="hover:shadow-md transition-all duration-300 border border-slate-100 bg-white overflow-hidden group rounded-[1.5rem] active:scale-[0.98]">
      <CardContent className="p-0">
        <Link href={`/requests/${request.id}`} className="block p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              {/* Header: Status / Category */}
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-primary bg-primary/5 px-2 py-0.5 rounded-full uppercase tracking-widest">
                  {request.category || "GENEL"}
                </span>
                <div className="flex items-center text-slate-400 text-[8px] font-bold uppercase tracking-tight">
                  <MessageSquare className="w-2.5 h-2.5 mr-1" />
                  {request.offerCount || 0} Teklif
                </div>
              </div>
              
              {/* Title */}
              <h3 className="text-[13px] font-black text-slate-900 mb-2 line-clamp-2 group-hover:text-primary transition-colors uppercase tracking-tight leading-snug">
                {request.title}
              </h3>

              {/* Location */}
              <div className="flex items-center text-[9px] font-bold text-slate-400 uppercase mb-3">
                <MapPin className="w-2.5 h-2.5 mr-1 text-slate-300" />
                <span className="truncate">{city} / {district}</span>
              </div>
              
              {/* Budget */}
              <div className="flex items-center text-[12px] font-black text-primary bg-primary/5 px-3 py-1.5 rounded-xl w-fit border border-primary/5">
                <Wallet className="w-3.5 h-3.5 mr-2 shrink-0" />
                <span className="truncate">{request.budget ? `${request.budget} TL` : "Görüşülecek"}</span>
              </div>
            </div>

            {/* Thumbnail */}
            <div className="shrink-0">
              <img 
                src={request.images?.[0] || `https://picsum.photos/seed/${request.id}/160/160`} 
                className="w-24 h-24 rounded-2xl object-cover border border-slate-50 shadow-sm" 
                alt={request.title}
                loading="lazy"
              />
            </div>
          </div>
        </Link>
      </CardContent>
    </Card>
  );
}
