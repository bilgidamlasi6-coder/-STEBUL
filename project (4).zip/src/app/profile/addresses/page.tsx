"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, MapPin, Plus, Trash2, Edit2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collection, query, onSnapshot, doc, deleteDoc, writeBatch } from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";

interface Address {
  id: string;
  title: string;
  detail: string;
  isDefault: boolean;
  province?: string;
  district?: string;
}

export default function AddressesPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user } = useAuth();
  const db = useFirestore();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (!user || !db) {
      if (!user) setLoading(false);
      return;
    }

    const q = query(collection(db, "kullanıcılar", user.uid, "addresses"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Address[];
      setAddresses(fetched);
      setLoading(false);
    }, (error) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `kullanıcılar/${user.uid}/addresses`,
        operation: 'list'
      }));
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, db]);

  const handleDelete = (id: string) => {
    if (!user || !db || actionLoading) return;
    
    setActionLoading(true);
    const docRef = doc(db, "kullanıcılar", user.uid, "addresses", id);
    
    deleteDoc(docRef)
      .then(() => {
        toast({ title: "Adres Silindi", description: "Adres başarıyla listeden kaldırıldı." });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'delete'
        }));
      })
      .finally(() => setActionLoading(false));
  };

  const setDefault = (id: string) => {
    if (!user || !db || actionLoading) return;
    
    setActionLoading(true);
    const batch = writeBatch(db);
    
    addresses.forEach(addr => {
      const addrRef = doc(db, "kullanıcılar", user.uid, "addresses", addr.id);
      if (addr.isDefault && addr.id !== id) {
        batch.update(addrRef, { isDefault: false });
      }
      if (addr.id === id) {
        batch.update(addrRef, { isDefault: true });
      }
    });
    
    batch.commit()
      .then(() => {
        toast({ title: "Varsayılan Güncellendi", description: "Seçili adres varsayılan olarak ayarlandı." });
      })
      .catch(async (err) => {
        toast({ variant: "destructive", title: "Hata", description: "Güncelleme başarısız." });
      })
      .finally(() => setActionLoading(false));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Adreslerim</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">TESLİMAT VE HİZMET NOKTALARI</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-4 pb-24">
        {addresses.map((address) => (
          <div key={address.id} className="bg-white p-5 rounded-[1.5rem] border border-slate-100 shadow-sm space-y-4 relative group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-primary/10 p-2.5 rounded-xl">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">{address.title}</h3>
                  {address.isDefault && (
                    <span className="text-[8px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase tracking-widest mt-1 inline-block">Varsayılan</span>
                  )}
                </div>
              </div>
              <div className="flex gap-1">
                <button 
                  disabled={actionLoading}
                  onClick={() => router.push(`/profile/addresses/edit?id=${address.id}`)}
                  className="p-2.5 text-slate-400 hover:text-primary transition-colors bg-slate-50 rounded-xl disabled:opacity-50"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  disabled={actionLoading}
                  onClick={() => handleDelete(address.id)} 
                  className="p-2.5 text-slate-400 hover:text-red-500 transition-colors bg-slate-50 rounded-xl disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <p className="text-[13px] text-slate-500 font-medium leading-relaxed">{address.detail}</p>
            {!address.isDefault && (
              <button 
                disabled={actionLoading}
                onClick={() => setDefault(address.id)}
                className="w-full py-3 bg-slate-50 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:bg-primary/5 hover:text-primary transition-all active:scale-95 disabled:opacity-50"
              >
                {actionLoading ? "İşleniyor..." : "Varsayılan Olarak Ayarla"}
              </button>
            )}
          </div>
        ))}

        {addresses.length === 0 && (
          <div className="py-16 text-center bg-white rounded-[2rem] border-2 border-dashed border-slate-100">
            <MapPin className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Kayıtlı adresiniz yok.</p>
          </div>
        )}

        <Button 
          disabled={actionLoading}
          onClick={() => router.push("/profile/addresses/new")}
          className="w-full bg-white text-primary border-2 border-dashed border-primary/30 hover:bg-primary/5 hover:border-primary h-16 rounded-[1.5rem] font-black text-sm uppercase tracking-widest transition-all"
        >
          <Plus className="w-5 h-5 mr-2" /> Yeni Adres Ekle
        </Button>
      </div>
    </div>
  );
}
