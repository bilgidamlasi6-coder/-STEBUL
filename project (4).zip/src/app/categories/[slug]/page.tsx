"use client";

import { useState, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/categories";
import { 
  ArrowLeft, 
  ChevronRight, 
  Search,
  House,
  CarFront,
  Truck,
  Wheat,
  HeartPulse,
  Hammer,
  Briefcase,
  ClipboardList,
  Laptop,
  LayoutGrid,
  LucideIcon
} from "lucide-react";
import { Input } from "@/components/ui/input";

const ICON_MAP: Record<string, LucideIcon> = {
  House,
  CarFront,
  Truck,
  Wheat,
  HeartPulse,
  Hammer,
  Briefcase,
  ClipboardList,
  Laptop,
  LayoutGrid
};

export default function CategoryDetail() {
  const { slug } = useParams();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  
  const category = CATEGORIES.find(c => c.slug === slug);

  const filteredSubCategories = useMemo(() => {
    if (!category) return [];
    if (!searchTerm) return category.subCategories;
    const term = searchTerm.toLocaleLowerCase("tr");
    return category.subCategories.filter(sub => 
      sub.name.toLocaleLowerCase("tr").includes(term)
    );
  }, [category, searchTerm]);

  if (!category) {
    return <div className="p-10 text-center font-bold">Kategori bulunamadı.</div>;
  }

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto">
      <header className="sticky top-0 z-40 bg-white px-6 pt-6 pb-4 border-b border-slate-50">
        <div className="flex items-center gap-4 mb-5">
          <button 
            onClick={() => router.back()} 
            className="p-2.5 bg-white border border-slate-100 rounded-full hover:bg-slate-50 transition-all shrink-0 shadow-sm active:scale-95"
          >
            <ArrowLeft className="w-4.5 h-4.5 text-slate-900" />
          </button>
          
          <div className="min-w-0">
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none uppercase truncate">
              {category.name}
            </h1>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input 
            placeholder={`${category.name} içinde ara...`} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-11 h-12 bg-slate-50/50 border border-slate-100 rounded-2xl focus-visible:ring-primary text-[12px] font-bold shadow-none"
          />
        </div>
      </header>

      <div className="px-6 py-2 space-y-px pb-32">
        {filteredSubCategories.length > 0 ? filteredSubCategories.map((sub) => (
          <button 
            key={sub.id}
            onClick={() => router.push(`/requests?category=${sub.name}`)}
            className="w-full flex items-center justify-between py-5 border-b border-slate-50 hover:bg-slate-50/30 transition-colors group"
          >
            <span className="text-[13px] font-bold text-slate-700 group-hover:text-primary transition-colors uppercase tracking-tight">
              {sub.name}
            </span>
            <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary transition-transform group-active:translate-x-1" />
          </button>
        )) : (
          <div className="py-24 text-center">
            <p className="text-slate-300 font-black uppercase text-[10px] tracking-widest">Hizmet bulunamadı.</p>
          </div>
        )}

        <div className="mt-16 p-10 bg-white rounded-[2.5rem] border border-slate-100 text-center shadow-sm">
          <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.15em] mb-5">Aradığınızı bulamadınız mı?</p>
          <button 
            onClick={() => router.push('/create')}
            className="bg-primary hover:bg-primary/90 text-white font-black h-14 rounded-2xl px-8 transition-all active:scale-95 shadow-xl shadow-primary/20 text-[11px] uppercase tracking-widest w-full"
          >
            Hemen Talep Oluştur
          </button>
        </div>
      </div>
    </div>
  );
}
