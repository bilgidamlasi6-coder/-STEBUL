"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { 
  ArrowLeft, 
  Search, 
  ChevronRight,
  House,
  CarFront,
  Truck,
  Wheat,
  HeartPulse,
  Hammer,
  Briefcase,
  ClipboardList,
  Laptop,
  LayoutGrid,
  LucideIcon
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { CATEGORIES } from "@/lib/categories";

const ICON_MAP: Record<string, LucideIcon> = {
  House,
  CarFront,
  Truck,
  Wheat,
  HeartPulse,
  Hammer,
  Briefcase,
  ClipboardList,
  Laptop,
  LayoutGrid
};

export default function AllCategoriesPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCategories = useMemo(() => {
    if (!searchTerm) return CATEGORIES;
    const term = searchTerm.toLocaleLowerCase("tr");
    return CATEGORIES.filter(cat => 
      cat.name.toLocaleLowerCase("tr").includes(term) ||
      cat.subCategories.some(sub => sub.name.toLocaleLowerCase("tr").includes(term))
    );
  }, [searchTerm]);

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm px-6 pt-6 pb-2 border-b border-slate-50">
        <div className="flex items-center gap-3 mb-3">
          <button 
            onClick={() => router.back()} 
            className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-900" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Kategoriler</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-0.5">İSTEBUL HİZMET MERKEZİ</p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input 
            placeholder="Kategori veya hizmet ara..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-11 h-10 bg-slate-50 border-none rounded-2xl focus-visible:ring-primary text-xs font-medium"
          />
        </div>
      </header>

      <div className="px-6 py-4 space-y-px pb-32">
        {filteredCategories.map((cat) => {
          const IconComponent = ICON_MAP[cat.iconName] || LayoutGrid;
          return (
            <button
              key={cat.id}
              onClick={() => router.push(`/categories/${cat.slug}`)}
              className="w-full flex items-center justify-between py-5 border-b border-primary/5 hover:bg-primary/5 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                  <IconComponent className="w-5 h-5 text-slate-400 group-hover:text-primary" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-black text-slate-800 uppercase tracking-tight leading-tight group-hover:text-primary">
                    {cat.name}
                  </p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                    {cat.subCategories.length} Alt Hizmet
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-200 group-hover:text-primary" />
            </button>
          );
        })}

        {filteredCategories.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-slate-300 font-black uppercase text-xs tracking-widest">Sonuç bulunamadı.</p>
          </div>
        )}
      </div>
    </div>
  );
}
