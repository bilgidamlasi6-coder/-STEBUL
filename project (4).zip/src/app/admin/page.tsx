"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { 
  collection, 
  query, 
  orderBy, 
  deleteDoc, 
  doc, 
  onSnapshot, 
  updateDoc, 
  serverTimestamp 
} from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";
import { 
  ArrowLeft, 
  Users, 
  FileText, 
  Trash2, 
  Loader2,
  ShieldCheck,
  Search,
  MoreVertical,
  Star,
  Clock,
  ExternalLink,
  Zap,
  PauseCircle,
  PlayCircle,
  CheckCircle2
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { RelativeTime } from "@/components/RelativeTime";
import { Button } from "@/components/ui/button";

export default function AdminDashboard() {
  const { profile, loading: authLoading } = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  
  const [data, setData] = useState({
    users: [] as any[],
    requests: [] as any[],
    reviews: [] as any[]
  });
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (!authLoading && profile?.rol !== 'SUPER_ADMIN') {
      router.push('/');
    }
  }, [profile, authLoading, router]);

  useEffect(() => {
    if (!db || profile?.rol !== 'SUPER_ADMIN') return;

    const unsubUsers = onSnapshot(collection(db, "kullanıcılar"), (snap) => {
      setData(prev => ({ ...prev, users: snap.docs.map(d => ({ id: d.id, ...d.data() })) }));
    });

    const unsubReqs = onSnapshot(query(collection(db, "requests"), orderBy("createdAt", "desc")), (snap) => {
      setData(prev => ({ ...prev, requests: snap.docs.map(d => ({ id: d.id, ...d.data() })) }));
      setLoading(false);
    });

    const unsubReviews = onSnapshot(query(collection(db, "reviews"), orderBy("createdAt", "desc")), (snap) => {
      setData(prev => ({ ...prev, reviews: snap.docs.map(d => ({ id: d.id, ...d.data() })) }));
    });

    return () => {
      unsubUsers();
      unsubReqs();
      unsubReviews();
    };
  }, [db, profile]);

  const handleDeletePermanently = (coll: string, id: string, e?: any) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    if (!db || actionLoading) return;
    
    const isConfirmed = window.confirm("DİKKAT: Bu kayıt TAMAMEN silinecektir. Emin misiniz?");
    if (!isConfirmed) return;

    const docRef = doc(db, coll, id);
    setActionLoading(true);

    deleteDoc(docRef)
      .then(() => {
        toast({ title: "Silindi", description: "Kayıt kalıcı olarak kaldırıldı." });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'delete'
        }));
      })
      .finally(() => setActionLoading(false));
  };

  const handleUpdateField = (id: string, field: string, value: any) => {
    if (!db || actionLoading) return;

    const docRef = doc(db, "requests", id);
    const updateData = { 
      [field]: value,
      updatedAt: serverTimestamp() 
    };

    setActionLoading(true);
    updateDoc(docRef, updateData)
      .then(() => {
        toast({ 
          title: "Güncellendi", 
          description: `İlan bilgisi güncellendi.` 
        });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      })
      .finally(() => setActionLoading(false));
  };

  const filteredUsers = data.users.filter(u => 
    `${u.isim} ${u.soyadı}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pendingRequests = data.requests.filter(r => r.status === 'pending');
  const activeRequests = data.requests.filter(r => r.status === 'active' || r.status === 'in_progress');

  if (loading || authLoading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4 mb-6">
          <button onClick={() => router.push('/profile')} className="p-2 bg-slate-50 rounded-full">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight uppercase">Yönetim Paneli</h1>
            <div className="flex items-center gap-1.5 mt-1">
              <ShieldCheck className="w-3 h-3 text-primary" />
              <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest">SİSTEM YÖNETİCİSİ</p>
            </div>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input 
            placeholder="Ara..." 
            className="h-12 pl-11 bg-slate-50 border-none rounded-2xl font-bold"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </header>

      <div className="px-6 py-6 space-y-6 pb-24">
        <div className="grid grid-cols-3 gap-2">
          <StatCard icon={Clock} label="BEKLEYEN" value={pendingRequests.length} color="text-amber-500" />
          <StatCard icon={FileText} label="AKTİF" value={activeRequests.length} color="text-emerald-500" />
          <StatCard icon={Users} label="ÜYELER" value={data.users.length} color="text-blue-500" />
        </div>

        <Tabs defaultValue="pending" className="w-full">
          <TabsList className="w-full h-12 bg-white p-1 rounded-2xl border border-slate-100 mb-6">
            <TabsTrigger value="pending" className="flex-1 rounded-xl text-[10px] font-black uppercase">Bekleyen</TabsTrigger>
            <TabsTrigger value="active" className="flex-1 rounded-xl text-[10px] font-black uppercase">Aktif</TabsTrigger>
            <TabsTrigger value="users" className="flex-1 rounded-xl text-[10px] font-black uppercase">Üyeler</TabsTrigger>
            <TabsTrigger value="reviews" className="flex-1 rounded-xl text-[10px] font-black uppercase">Yorumlar</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="space-y-3 m-0">
            {pendingRequests.map(req => (
              <RequestAdminCard 
                key={req.id} 
                req={req} 
                onUpdate={handleUpdateField} 
                onDelete={handleDeletePermanently}
                router={router}
                disabled={actionLoading}
              />
            ))}
            {pendingRequests.length === 0 && <div className="py-20 text-center text-slate-300 font-black uppercase text-[10px]">Bekleyen talep yok.</div>}
          </TabsContent>

          <TabsContent value="active" className="space-y-3 m-0">
            {activeRequests.map(req => (
              <RequestAdminCard 
                key={req.id} 
                req={req} 
                onUpdate={handleUpdateField} 
                onDelete={handleDeletePermanently}
                router={router}
                disabled={actionLoading}
              />
            ))}
            {activeRequests.length === 0 && <div className="py-20 text-center text-slate-300 font-black uppercase text-[10px]">Aktif talep yok.</div>}
          </TabsContent>

          <TabsContent value="users" className="space-y-3 m-0">
            {filteredUsers.map(u => (
              <Card key={u.id} className="border-none rounded-3xl bg-white shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center cursor-pointer" onClick={() => router.push(`/profile?uid=${u.id}`)}>
                      <img src={u.avatar || "https://picsum.photos/seed/user/40/40"} className="w-10 h-10 rounded-xl mr-3 object-cover" alt="" />
                      <div>
                        <p className="text-xs font-black text-slate-900 leading-none">{u.isim} {u.soyadı}</p>
                        <p className="text-[8px] font-bold text-slate-400 mt-1 uppercase">{u.rol}</p>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><button className="p-1 text-slate-300"><MoreVertical className="w-4 h-4" /></button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-2xl border-none shadow-xl bg-white min-w-[140px]">
                        <DropdownMenuItem onSelect={() => router.push(`/profile?uid=${u.id}`)} className="font-bold text-xs py-3">Profili Gör</DropdownMenuItem>
                        <DropdownMenuItem 
                          onSelect={(e) => handleDeletePermanently('kullanıcılar', u.id, e)} 
                          disabled={actionLoading}
                          className="font-bold text-xs text-red-500 py-3"
                        >
                          <Trash2 className="w-3.5 h-3.5 mr-2" /> Kalıcı Sil
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="reviews" className="space-y-3 m-0">
            {data.reviews.map(rev => (
              <Card key={rev.id} className="border-none rounded-3xl bg-white shadow-sm overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <p className="text-[10px] font-black text-slate-900 uppercase">{rev.reviewerName}</p>
                      <div className="flex gap-0.5">
                        {[1,2,3,4,5].map(s => <Star key={s} className={`w-2 h-2 ${rev.rating >= s ? 'fill-yellow-400 text-yellow-400' : 'text-slate-100'}`} />)}
                      </div>
                    </div>
                    <button 
                      onClick={(e) => handleDeletePermanently('reviews', rev.id, e)} 
                      disabled={actionLoading}
                      className="text-slate-300 hover:text-red-500 transition-colors disabled:opacity-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 italic line-clamp-2">"{rev.comment}"</p>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function RequestAdminCard({ req, onUpdate, onDelete, router, disabled }: any) {
  return (
    <Card className="border-none rounded-3xl bg-white shadow-sm overflow-hidden mb-3">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap gap-1 mb-2">
              {req.status === 'pending' && <span className="text-[8px] font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded uppercase">Onay Bekliyor</span>}
              {req.isShowcase && <span className="text-[8px] font-black text-white bg-emerald-600 px-2 py-0.5 rounded uppercase flex items-center gap-1"><Star className="w-2 h-2 fill-white" /> Vitrin</span>}
              {req.urgent && <span className="text-[8px] font-black text-white bg-red-500 px-2 py-0.5 rounded uppercase flex items-center gap-1"><Zap className="w-2 h-2 fill-white" /> Acil</span>}
            </div>
            <p className="text-xs font-black text-slate-900 mt-1 line-clamp-1">{req.title}</p>
            <p className="text-[10px] text-slate-400 mt-1 line-clamp-1">{req.description}</p>
            
            <div className="flex flex-wrap items-center gap-2 mt-4">
              {req.status === 'pending' ? (
                <Button size="sm" disabled={disabled} onClick={() => onUpdate(req.id, 'status', 'active')} className="h-8 bg-primary rounded-xl font-black text-[9px] uppercase px-3 border-none">
                  <CheckCircle2 className="w-3 h-3 mr-1" /> Onayla
                </Button>
              ) : req.status === 'active' ? (
                <Button size="sm" variant="outline" disabled={disabled} onClick={() => onUpdate(req.id, 'status', 'inactive')} className="h-8 rounded-xl font-black text-[9px] uppercase px-3 border-slate-100 text-amber-500">
                  <PauseCircle className="w-3 h-3 mr-1" /> Pasife Al
                </Button>
              ) : (
                <Button size="sm" variant="outline" disabled={disabled} onClick={() => onUpdate(req.id, 'status', 'active')} className="h-8 rounded-xl font-black text-[9px] uppercase px-3 border-slate-100 text-emerald-500">
                  <PlayCircle className="w-3 h-3 mr-1" /> Yayınla
                </Button>
              )}

              <button 
                onClick={() => onUpdate(req.id, 'isShowcase', !req.isShowcase)}
                disabled={disabled}
                className={`p-2 rounded-xl transition-all disabled:opacity-50 ${req.isShowcase ? 'bg-amber-50 text-amber-500' : 'bg-slate-50 text-slate-300'}`}
                title="Vitrin Durumu"
              >
                <Star className={`w-4 h-4 ${req.isShowcase ? 'fill-amber-500' : ''}`} />
              </button>
              
              <button 
                onClick={() => onUpdate(req.id, 'urgent', !req.urgent)}
                disabled={disabled}
                className={`p-2 rounded-xl transition-all disabled:opacity-50 ${req.urgent ? 'bg-red-50 text-red-500' : 'bg-slate-50 text-slate-300'}`}
                title="Acil Durumu"
              >
                <Zap className={`w-4 h-4 ${req.urgent ? 'fill-red-500' : ''}`} />
              </button>

              <Button size="sm" variant="ghost" onClick={() => router.push(`/requests/${req.id}`)} className="h-8 text-slate-400 font-black text-[9px] uppercase">
                <ExternalLink className="w-3 h-3 mr-1" /> GÖR
              </Button>

              <button 
                onClick={(e) => onDelete('requests', req.id, e)} 
                disabled={disabled}
                className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors ml-auto disabled:opacity-50"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          {req.images?.[0] && <img src={req.images[0]} className="w-16 h-16 rounded-2xl object-cover border border-slate-50 shrink-0" alt="" />}
        </div>
      </CardContent>
    </Card>
  );
}

function StatCard({ icon: Icon, label, value, color }: any) {
  return (
    <div className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm text-center">
      <Icon className={`w-4 h-4 ${color} mx-auto mb-1`} />
      <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
      <p className="text-lg font-black text-slate-900">{value}</p>
    </div>
  );
}
