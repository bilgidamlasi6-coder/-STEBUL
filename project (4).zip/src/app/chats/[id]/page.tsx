"use client";

import { useParams, useRouter } from "next/navigation";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { doc, onSnapshot, collection, query, orderBy, addDoc, serverTimestamp, updateDoc, getDoc, writeBatch, deleteDoc } from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";
import { ArrowLeft, Send, Phone, MessageCircle, Loader2, XCircle, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { RelativeTime } from "@/components/RelativeTime";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from "@/components/ui/alert-dialog";

export default function ChatRoom() {
  const { id } = useParams();
  const router = useRouter();
  const db = useFirestore();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [chat, setChat] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputText, setInputText] = useState("");
  const [otherUser, setOtherProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!db || !id || !user) return;

    const unsubChat = onSnapshot(doc(db, "chats", id as string), async (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        const isAdmin = profile?.rol === 'SUPER_ADMIN';
        if (!data.participants.includes(user.uid) && !isAdmin) {
          toast({ variant: "destructive", title: "Yetkisiz Erişim" });
          router.push('/chats');
          return;
        }

        setChat(data);
        const otherId = data.participants.find((p: string) => p !== user.uid);
        if (otherId) {
          const uSnap = await getDoc(doc(db, "kullanıcılar", otherId));
          if (uSnap.exists()) setOtherProfile(uSnap.data());
        }
        setLoading(false);
      } else {
        setLoading(false);
        router.push('/chats');
      }
    }, (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `chats/${id}`,
        operation: 'get'
      }));
    });

    const q = query(collection(db, "chats", id as string, "messages"), orderBy("createdAt", "asc"));
    const unsubMsg = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: `chats/${id}/messages`,
        operation: 'list'
      }));
    });

    return () => { unsubChat(); unsubMsg(); };
  }, [db, id, user?.uid, profile?.rol]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !db || !id || !user || sending) return;

    setSending(true);
    const text = inputText;
    setInputText("");
    
    const messagesRef = collection(db, "chats", id as string, "messages");
    const chatRef = doc(db, "chats", id as string);
    const msgData = {
      senderId: user.uid,
      text,
      createdAt: serverTimestamp()
    };

    addDoc(messagesRef, msgData)
      .then(() => {
        updateDoc(chatRef, {
          lastMessage: text,
          updatedAt: serverTimestamp()
        }).catch(err => {
           errorEmitter.emit('permission-error', new FirestorePermissionError({
             path: chatRef.path,
             operation: 'update',
             requestResourceData: { lastMessage: text }
           }));
        });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: messagesRef.path,
          operation: 'create',
          requestResourceData: msgData
        }));
        // Hata durumunda metni geri al (opsiyonel UX tercihi)
        setInputText(text);
      })
      .finally(() => setSending(false));
  };

  const handleDeleteMessage = (messageId: string) => {
    if (!db || !id) return;
    const msgRef = doc(db, "chats", id as string, "messages", messageId);
    
    deleteDoc(msgRef)
      .then(() => toast({ title: "Mesaj Silindi" }))
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: msgRef.path,
          operation: 'delete'
        }));
      });
  };

  const handleCancelDeal = () => {
    if (!db || !id || !chat || sending) return;
    setSending(true);

    const batch = writeBatch(db);
    const reqRef = doc(db, "requests", chat.requestId);
    const chatRef = doc(db, "chats", id as string);

    batch.update(reqRef, { 
      status: 'active',
      acceptedOfferId: null,
      acceptedBusinessId: null
    });
    batch.update(chatRef, { status: 'cancelled' });

    batch.commit()
      .then(() => {
        toast({ title: "Süreç İptal Edildi" });
        router.push('/offers');
      })
      .catch(async (err) => {
        toast({ variant: "destructive", title: "Hata" });
      })
      .finally(() => setSending(false));
  };

  if (loading) return <div className="flex items-center justify-center min-h-screen bg-white"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  if (!chat) return null;

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-slate-50">
      <header className="bg-white px-6 pt-8 pb-4 border-b border-slate-100 flex items-center justify-between shadow-sm sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()} className="p-1.5 bg-slate-50 rounded-lg"><ArrowLeft className="w-4 h-4 text-slate-600" /></button>
          <div>
            <h2 className="text-sm font-black text-slate-900 leading-none">{otherUser?.isim || "Görüşme"}</h2>
            <p className="text-[9px] text-primary font-black uppercase mt-1 tracking-widest truncate max-w-[150px]">{chat.requestTitle}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {otherUser?.telefon && (
            <a href={`tel:${otherUser.telefon}`} className="p-2 bg-primary/5 text-primary rounded-xl"><Phone className="w-4 h-4" /></a>
          )}
          <AlertDialog>
            <AlertDialogTrigger asChild><button disabled={sending} className="p-2 bg-red-50 text-red-500 rounded-xl disabled:opacity-50"><XCircle className="w-4 h-4" /></button></AlertDialogTrigger>
            <AlertDialogContent className="rounded-[2.5rem] p-8 border-none bg-white">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-xl font-black uppercase">İptal Edilsin mi?</AlertDialogTitle>
                <AlertDialogDescription className="text-xs">Süreci iptal edip talebi tekrar yayına almak istediğinize emin misiniz?</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="mt-6 flex gap-2">
                <AlertDialogCancel className="flex-1 rounded-xl font-black text-[10px] uppercase border-none bg-slate-50 h-12">VAZGEÇ</AlertDialogCancel>
                <AlertDialogAction onClick={handleCancelDeal} className="flex-1 rounded-xl font-black text-[10px] uppercase bg-red-500 text-white border-none h-12">İPTAL ET</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg) => {
          const isMe = msg.senderId === user?.uid;
          const canDelete = isMe || profile?.rol === 'SUPER_ADMIN';
          return (
            <div key={msg.id} className={`flex group ${isMe ? 'justify-end' : 'justify-start'}`}>
              {!isMe && canDelete && <button onClick={() => handleDeleteMessage(msg.id)} className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 transition-opacity"><Trash2 className="w-3 h-3" /></button>}
              <div className={`max-w-[80%] p-3.5 rounded-2xl text-[13px] font-medium shadow-sm relative ${
                isMe ? 'bg-primary text-white rounded-tr-none' : 'bg-white text-slate-700 rounded-tl-none border border-slate-100'
              }`}>
                {msg.text}
                <div className={`text-[7px] mt-1.5 font-bold uppercase opacity-50 ${isMe ? 'text-white' : 'text-slate-400'}`}>
                   <RelativeTime date={msg.createdAt} />
                </div>
              </div>
              {isMe && canDelete && <button onClick={() => handleDeleteMessage(msg.id)} className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 transition-opacity"><Trash2 className="w-3 h-3" /></button>}
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      <footer className="bg-white p-6 border-t border-slate-50 shadow-sm">
        <form onSubmit={sendMessage} className="flex gap-3">
          <Input 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={sending ? "Gönderiliyor..." : "Bir mesaj yazın..."} 
            disabled={sending}
            className="h-12 bg-slate-50 border-none rounded-2xl px-4 font-medium"
          />
          <Button type="submit" size="icon" disabled={sending || !inputText.trim()} className="h-12 w-12 rounded-2xl bg-primary border-none">
            {sending ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 text-white" />}
          </Button>
        </form>
      </footer>
    </div>
  );
}
