"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  Loader2, 
  MapPin, 
  Camera, 
  X, 
  ChevronRight,
  Wallet,
  Wand2,
  Search,
  ChevronDown,
  ChevronUp,
  LayoutGrid,
  House,
  CarFront,
  Truck,
  Wheat,
  HeartPulse,
  Hammer,
  Briefcase,
  ClipboardList,
  Laptop,
  LucideIcon
} from "lucide-react";
import { CATEGORIES, type CustomField } from "@/lib/categories";
import { useFirestore } from "@/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { AuthPanel } from "@/components/AuthPanel";
import { TURKEY_PROVINCES, getDistricts, getNeighborhoods } from "@/lib/turkey-data";
import { generateDescription } from "@/ai/flows/generate-description";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const ICON_MAP: Record<string, LucideIcon> = {
  House, CarFront, Truck, Wheat, HeartPulse, Hammer, Briefcase, ClipboardList, Laptop, LayoutGrid
};

type FlowMode = "category" | "location" | null;

interface ImageItem {
  file: File;
  preview: string;
}

export default function CreateRequest() {
  const router = useRouter();
  const db = useFirestore();
  const { toast } = useToast();
  const { user, profile, loading: authLoading } = useAuth();
  
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);
  
  const [formData, setFormData] = useState<any>({ 
    title: "", 
    description: "", 
    budget: "", 
    mainCategory: "",
    category: "", 
    location: "",
    customFields: {}
  });

  const [selectedImages, setSelectedImages] = useState<ImageItem[]>([]);
  const [activeFlow, setActiveFlow] = useState<FlowMode>(null);
  const [flowStep, setFlowStep] = useState(1);
  const [tempSelection, setTempSelection] = useState<any>({ main: "", sub: "", fields: {} });
  const [selectionSearch, setSelectionSearch] = useState("");

  useEffect(() => {
    if (!authLoading && !user) setIsAuthPanelOpen(true);
  }, [user, authLoading]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImages(prev => [...prev, { file, preview: reader.result as string }].slice(0, 5));
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleAiGenerate = async () => {
    if (!formData.title || aiLoading) {
      if (!formData.title) toast({ variant: "destructive", title: "Başlık Gerekli" });
      return;
    }
    setAiLoading(true);
    try {
      const suggestedText = await generateDescription({ title: formData.title });
      setFormData((prev: any) => ({ ...prev, description: suggestedText }));
      toast({ title: "AI Hazırladı!" });
    } catch (e) {
      toast({ variant: "destructive", title: "Hata" });
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || !db) return;
    if (!user) { setIsAuthPanelOpen(true); return; }
    if (!formData.title || !formData.category || !formData.location || !formData.description) {
      toast({ variant: "destructive", title: "Eksik Alanlar", description: "Zorunlu alanları doldurun." });
      return;
    }
    setLoading(true);
    try {
      const imageUrls = selectedImages.map((_, i) => `https://picsum.photos/seed/${Math.floor(Math.random() * 10000)}/800/600`);
      const requestsRef = collection(db, "requests");
      const finalData = {
        ...formData,
        images: imageUrls,
        createdAt: serverTimestamp(),
        status: "active",
        userId: user.uid,
        offerCount: 0,
        user: {
          uid: user.uid,
          name: `${profile?.isim || ""} ${profile?.soyadı || ""}`.trim(),
          avatar: profile?.avatar || `https://picsum.photos/seed/${user.uid}/100/100`,
          telefon: profile?.telefon || ""
        }
      };
      addDoc(requestsRef, finalData).then(() => {
        toast({ title: "İlan Yayınlandı!" });
        router.push('/profile/history');
      }).catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({ path: requestsRef.path, operation: 'create', requestResourceData: finalData }));
        setLoading(false);
      });
    } catch (error: any) {
      setLoading(false);
    }
  };

  const toggleSubCategory = (sub: any) => {
    if (tempSelection.sub === sub.name) {
      setTempSelection({ ...tempSelection, sub: "", fields: {} });
    } else {
      setTempSelection({ ...tempSelection, sub: sub.name, fields: {} });
    }
  };

  if (activeFlow === "category") {
    return (
      <div className="fixed inset-0 z-[100] bg-white animate-in slide-in-from-right duration-300 flex flex-col">
        <header className="px-6 pt-6 pb-4 border-b border-slate-50 flex items-center gap-4 sticky top-0 bg-white z-50">
          <button onClick={() => setActiveFlow(null)} className="p-1.5 bg-slate-50 rounded-lg"><ArrowLeft className="w-4 h-4" /></button>
          <h1 className="font-bold uppercase text-[10px] tracking-widest text-slate-900">Kategori ve Hizmet Seç</h1>
        </header>
        
        <div className="flex-1 overflow-y-auto p-6 pb-32">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {CATEGORIES.map((cat) => {
              const Icon = ICON_MAP[cat.iconName] || LayoutGrid;
              return (
                <AccordionItem key={cat.id} value={cat.id} className="border-none bg-slate-50/50 rounded-3xl px-4 overflow-hidden shadow-sm transition-all duration-300">
                  <AccordionTrigger className="hover:no-underline py-5 group">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center shadow-sm group-data-[state=open]:bg-primary transition-all">
                        <Icon className="w-5 h-5 text-primary group-data-[state=open]:text-white" />
                      </div>
                      <span className="font-black text-[13px] uppercase tracking-tight text-slate-800">{cat.name}</span>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-4 space-y-2 animate-in fade-in zoom-in-95">
                    {cat.subCategories.map((sub) => (
                      <div key={sub.id} className="space-y-2">
                        <button 
                          onClick={() => { setTempSelection({ ...tempSelection, main: cat.name }); toggleSubCategory(sub); }}
                          className={`w-full flex items-center justify-between p-4 rounded-2xl font-bold text-[11px] uppercase transition-all duration-300 ${
                            tempSelection.sub === sub.name ? 'bg-primary text-white shadow-lg' : 'bg-white text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {sub.name}
                          {tempSelection.sub === sub.name ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5 opacity-50" />}
                        </button>
                        
                        {tempSelection.sub === sub.name && (
                          <div className="p-5 bg-white rounded-2xl border border-slate-100 space-y-5 animate-in slide-in-from-top-2 duration-300">
                            {sub.fields ? (
                              <div className="space-y-4">
                                {sub.fields.map((field: CustomField) => {
                                  if (field.dependsOn && !tempSelection.fields[field.dependsOn]) return null;
                                  const options = field.conditionalOptions ? field.conditionalOptions[tempSelection.fields[field.dependsOn!]] || [] : field.options || [];
                                  return (
                                    <div key={field.key} className="space-y-1.5">
                                      <Label className="text-[9px] font-black uppercase text-slate-400 ml-1">{field.label}</Label>
                                      {field.type === 'select' ? (
                                        <div className="grid grid-cols-2 gap-2">
                                          {options.map(opt => (
                                            <button
                                              key={opt} type="button"
                                              onClick={() => {
                                                const newFields = { ...tempSelection.fields, [field.key]: opt };
                                                sub.fields?.forEach(f => { if (f.dependsOn === field.key) delete newFields[f.key]; });
                                                setTempSelection({ ...tempSelection, fields: newFields });
                                              }}
                                              className={`h-11 rounded-xl text-[10px] font-black border transition-all text-left px-3 ${
                                                tempSelection.fields[field.key] === opt ? 'bg-primary/10 text-primary border-primary' : 'bg-slate-50/50 text-slate-600 border-slate-100'
                                              }`}
                                            >
                                              <span className="truncate">{opt}</span>
                                            </button>
                                          ))}
                                        </div>
                                      ) : (
                                        <div className="relative">
                                          <Input 
                                            type={field.type} placeholder={field.placeholder}
                                            value={tempSelection.fields[field.key] || ""}
                                            onChange={(e) => setTempSelection({ ...tempSelection, fields: { ...tempSelection.fields, [field.key]: e.target.value } })}
                                            className="h-12 bg-slate-50/50 border-slate-100 rounded-xl font-bold text-sm"
                                          />
                                          {field.unit && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-slate-300 uppercase">{field.unit}</span>}
                                        </div>
                                      )}
                                    </div>
                                  );
                                })}
                                <Button 
                                  onClick={() => { setFormData({ ...formData, mainCategory: tempSelection.main, category: sub.name, customFields: tempSelection.fields }); setActiveFlow(null); }}
                                  className="w-full h-12 bg-primary rounded-xl font-black uppercase text-[10px] tracking-widest shadow-lg"
                                >
                                  SEÇİMİ TAMAMLA
                                </Button>
                              </div>
                            ) : (
                              <Button 
                                onClick={() => { setFormData({ ...formData, mainCategory: tempSelection.main, category: sub.name, customFields: {} }); setActiveFlow(null); }}
                                className="w-full h-12 bg-primary rounded-xl font-black uppercase text-[10px] tracking-widest"
                              >
                                BU KATEGORİYİ SEÇ
                              </Button>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        </div>
      </div>
    );
  }

  if (activeFlow === "location") {
    let list = flowStep === 1 ? TURKEY_PROVINCES : flowStep === 2 ? getDistricts(tempSelection.province) : getNeighborhoods(tempSelection.province, tempSelection.district);
    const handleSelect = (item: string) => {
      if (flowStep === 1) { setTempSelection({ ...tempSelection, province: item }); setFlowStep(2); }
      else if (flowStep === 2) { setTempSelection({ ...tempSelection, district: item }); setFlowStep(3); }
      else { 
        setFormData({ ...formData, location: `${tempSelection.province} / ${tempSelection.district} / ${item}` });
        setActiveFlow(null);
      }
      setSelectionSearch("");
    };
    return (
      <div className="fixed inset-0 z-[100] bg-white animate-in slide-in-from-right duration-300 flex flex-col">
        <header className="px-6 pt-6 pb-4 border-b border-slate-50 flex items-center gap-4 sticky top-0 bg-white z-50">
          <button onClick={() => flowStep > 1 ? setFlowStep(flowStep - 1) : setActiveFlow(null)} className="p-1.5 bg-slate-50 rounded-lg"><ArrowLeft className="w-4 h-4" /></button>
          <h1 className="font-bold uppercase text-[10px] tracking-widest text-slate-900">{flowStep === 1 ? "Şehir" : flowStep === 2 ? "İlçe" : "Mahalle"} Seçiniz</h1>
        </header>
        <div className="p-6 flex-1 overflow-y-auto">
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 w-3.5 h-3.5" />
            <Input 
              placeholder="Ara..." value={selectionSearch} onChange={(e) => setSelectionSearch(e.target.value)} autoFocus
              className="h-11 bg-slate-50 border-none rounded-xl pl-10 font-bold text-sm"
            />
          </div>
          <div className="space-y-px">
            {list.filter(i => i.toLowerCase().includes(selectionSearch.toLowerCase())).map(item => (
              <button key={item} type="button" onClick={() => handleSelect(item)} className="w-full flex items-center justify-between py-4 border-b border-slate-50 text-sm font-semibold text-slate-700">{item} <ChevronRight className="w-3.5 h-3.5 text-slate-200" /></button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 bg-white border-b border-slate-50 px-6 pt-6 pb-4">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full"><ArrowLeft className="w-4.5 h-4.5 text-slate-900" /></button>
          <h1 className="text-lg font-black tracking-tight uppercase text-slate-900">Talep Oluştur</h1>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="flex-1 px-6 py-6 space-y-6 pb-32 overflow-y-auto">
        <div className="space-y-1.5">
          <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">İLAN BAŞLIĞI</Label>
          <Input 
            placeholder="Örn: 2020 Model BMW 3 Serisi Arıyorum" 
            className="h-12 rounded-2xl bg-white border-slate-100 font-black focus:ring-primary shadow-none"
            required value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">KATEGORİ</Label>
            <button 
              type="button" onClick={() => setActiveFlow("category")}
              className="w-full h-12 px-4 bg-slate-50/50 border border-slate-100 rounded-2xl flex items-center justify-between text-left hover:border-primary/30 transition-all"
            >
              <span className={`text-[10px] font-black truncate pr-2 uppercase ${formData.category ? 'text-slate-900' : 'text-slate-300'}`}>
                {formData.category || "Seçiniz"}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-300" />
            </button>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">KONUM</Label>
            <button 
              type="button" onClick={() => { setTempSelection({ province: "", district: "", neighborhood: "" }); setFlowStep(1); setActiveFlow("location"); }}
              className="w-full h-12 px-4 bg-slate-50/50 border border-slate-100 rounded-2xl flex items-center justify-between text-left hover:border-primary/30 transition-all"
            >
              <span className={`text-[10px] font-black truncate pr-2 uppercase ${formData.location ? 'text-slate-900' : 'text-slate-300'}`}>
                {formData.location || "Seçiniz"}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-300" />
            </button>
          </div>
        </div>

        {Object.keys(formData.customFields).length > 0 && (
          <div className="p-5 bg-primary/5 rounded-[2rem] border border-primary/10 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black text-primary uppercase tracking-widest">Seçili Teknik Özellikler</span>
              <button type="button" onClick={() => setActiveFlow("category")} className="text-[9px] font-black text-primary underline">DÜZENLE</button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(formData.customFields).map(([key, val]: [string, any]) => (
                <div key={key} className="bg-white px-3 py-2.5 rounded-xl shadow-sm border border-slate-50">
                  <span className="text-slate-400 block uppercase text-[8px] font-black mb-0.5">{key.replace(/_/g, ' ')}</span>
                  <span className="font-black text-slate-800 truncate block text-[10px]">{val}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">AÇIKLAMA</Label>
            <button type="button" onClick={handleAiGenerate} disabled={aiLoading} className="flex items-center gap-1 px-3 py-1 bg-primary/5 text-primary rounded-lg active:scale-95 transition-all">
              {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
              <span className="text-[9px] font-black uppercase">AI SİHRİ</span>
            </button>
          </div>
          <Textarea 
            placeholder="İhtiyacınızı detaylandırın..." required value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})}
            className="min-h-[140px] rounded-2xl bg-white border-slate-100 font-medium p-4 text-xs resize-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">BÜTÇE (TL)</Label>
            <div className="relative">
              <Wallet className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
              <Input type="number" placeholder="Miktar girin" value={formData.budget} onChange={(e) => setFormData({...formData, budget: e.target.value})} className="h-12 pl-10 rounded-2xl font-black text-sm" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">GÖRSELLER (MAX 5)</Label>
            <label className="flex items-center justify-center h-12 bg-white rounded-2xl cursor-pointer border border-slate-100 hover:border-primary/30 transition-all">
              <Camera className="w-5 h-5 text-slate-400" />
              <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} multiple disabled={selectedImages.length >= 5} />
            </label>
          </div>
        </div>

        {selectedImages.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {selectedImages.map((img, i) => (
              <div key={i} className="relative w-20 h-20 rounded-2xl overflow-hidden border border-slate-100 shrink-0 shadow-sm">
                <img src={img.preview} className="w-full h-full object-cover" alt="" />
                <button type="button" onClick={() => removeImage(i)} className="absolute top-1 right-1 bg-black/50 text-white rounded-full p-1"><X className="w-3 h-3" /></button>
              </div>
            ))}
          </div>
        )}

        <Button type="submit" disabled={loading} className="w-full bg-primary h-14 rounded-2xl font-black text-white shadow-xl shadow-primary/20 mt-6 text-base border-none transition-all active:scale-95">
          {loading ? <div className="flex items-center gap-2"><Loader2 className="w-5 h-5 animate-spin" /><span>YÜKLENİYOR...</span></div> : "TALEBİ ŞİMDİ YAYINLA"}
        </Button>
      </form>
      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
    </div>
  );
}