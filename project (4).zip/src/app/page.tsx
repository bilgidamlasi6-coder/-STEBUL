
"use client";

import { useState, useEffect, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  MessageSquare,
  Bell,
  Loader2,
  ChevronRight,
  Star,
  Zap,
  LayoutGrid,
  SlidersHorizontal,
  MapPin,
  Heart,
  Clock,
  Inbox,
  Menu
} from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useFirestore } from "@/firebase";
import { collection, query, orderBy, limit, onSnapshot, where } from "firebase/firestore";

export default function Home() {
  const router = useRouter();
  const db = useFirestore();
  
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [data, setData] = useState<Record<string, any[]>>({
    vitrin: [],
    urgent: [],
    newest: [],
    all: []
  });

  useEffect(() => {
    if (!db) return;

    const safeOnSnapshot = (q: any, key: string) => {
      try {
        return onSnapshot(q, 
          (snap) => {
            const docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            setData(prev => ({ ...prev, [key]: docs }));
          },
          (err) => console.warn(`Index missing for ${key}:`, err.message)
        );
      } catch (e) { return () => {}; }
    };

    const qVitrin = query(collection(db, "requests"), where("status", "==", "active"), where("isShowcase", "==", true), orderBy("createdAt", "desc"), limit(10));
    const qUrgent = query(collection(db, "requests"), where("status", "==", "active"), where("urgent", "==", true), orderBy("createdAt", "desc"), limit(10));
    const qNewest = query(collection(db, "requests"), where("status", "==", "active"), orderBy("createdAt", "desc"), limit(10));
    const qAll = query(collection(db, "requests"), where("status", "==", "active"), orderBy("createdAt", "desc"), limit(60));

    const unsubs = [
      safeOnSnapshot(qVitrin, "vitrin"),
      safeOnSnapshot(qUrgent, "urgent"),
      safeOnSnapshot(qNewest, "newest"),
      safeOnSnapshot(qAll, "all")
    ];

    const timer = setTimeout(() => setLoading(false), 800);
    return () => {
      unsubs.forEach(unsub => typeof unsub === 'function' && unsub());
      clearTimeout(timer);
    };
  }, [db]);

  const displayData = useMemo(() => {
    const all = data.all;
    const uniqueAll = Array.from(
      new Map(all.map(item => [item.id, item])).values()
    );
    return { 
      vitrin: data.vitrin, 
      urgent: data.urgent, 
      newest: data.newest, 
      all: uniqueAll 
    };
  }, [data]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-50 shadow-sm">
        <div className="px-4 pt-4 pb-3">
          {/* Header Row: Menu (Left), Logo (Centered), Icons (Right) */}
          <div className="relative flex items-center h-10 mb-4">
            {/* Hamburger Menu (Left) */}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => router.push('/categories')} 
              className="h-10 w-10 rounded-full text-slate-700 shrink-0"
            >
              <Menu className="w-8 h-8" />
            </Button>

            {/* Logo Group (Centered - Optically adjusted with -3px left shift) */}
            <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2 -ml-[3px]">
              <div className="w-[30px] h-[30px] flex items-center justify-center shrink-0">
                <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
                  <path d="M50 2 L93 25 L93 75 L50 98 L7 75 L7 25 Z" fill="#0033CC"/>
                  <text x="50" y="72" fontFamily="Inter, sans-serif" fontWeight="900" fontSize="55" fill="white" textAnchor="middle" style={{ fontStyle: 'italic' }}>İ</text>
                </svg>
              </div>
              <h1 className="text-lg font-black text-slate-900 tracking-tighter uppercase whitespace-nowrap">İSTEBUL</h1>
            </div>
            
            {/* Icons Group (Far Right) */}
            <div className="ml-auto flex items-center gap-2">
              <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full text-slate-700">
                <Bell className="w-8 h-8" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => router.push('/chats')} className="h-10 w-10 rounded-full text-slate-700">
                <MessageSquare className="w-8 h-8" />
              </Button>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative max-w-[85%] mx-auto">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5 z-10" />
            <form onSubmit={(e) => { e.preventDefault(); router.push(`/requests?search=${searchTerm}`); }}>
              <Input 
                placeholder="Talepleri keşfet..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-10 h-11 bg-slate-50 border-none shadow-none rounded-[1.1rem] focus-visible:ring-primary text-[12px] font-medium w-full"
              />
            </form>
            <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-primary">
              <SlidersHorizontal className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </header>

      <main className="space-y-0 pb-32">
        <HomeSection 
          title="Vitrin Talepleri" 
          icon={Star} 
          headerBg="bg-[#FBBF24]" 
          titleColor="text-white"
          iconColor="text-white"
          items={displayData.vitrin} 
          link="/requests?vitrin=true" 
          badgeType="vitrin"
        />

        <HomeSection 
          title="Acil Talepler" 
          icon={Zap} 
          headerBg="bg-[#EF4444]" 
          titleColor="text-white"
          items={displayData.urgent} 
          link="/requests?urgent=true" 
          badgeType="urgent"
        />

        <HomeSection 
          title="Yeni Talepler" 
          icon={Clock} 
          headerBg="bg-[#10B981]" 
          titleColor="text-white"
          items={displayData.newest} 
          link="/requests?sort=new" 
          badgeType="newest"
        />

        <section className="bg-white">
          <div className={`flex items-center justify-between px-6 py-4 bg-[#0033CC] mb-4`}>
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-white/20 backdrop-blur-sm rounded-lg">
                <LayoutGrid className="w-4 h-4 text-white" />
              </div>
              <h2 className="text-[15px] font-black text-white uppercase tracking-tight">Tüm Talepler</h2>
            </div>
            <Link href="/requests" className="text-[9px] font-black text-[#0033CC] uppercase tracking-widest flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full shadow-sm active:scale-95 transition-all">
              Tümü <ChevronRight className="w-3 h-3" />
            </Link>
          </div>
          
          {displayData.all.length > 0 ? (
            <div className="grid grid-cols-2 gap-4 px-4 pb-12">
              {displayData.all.map((item: any) => (
                <CompactCard key={item.id} item={item} isGrid />
              ))}
            </div>
          ) : (
            <EmptyState message="Henüz bir talep bulunmuyor." />
          )}
        </section>
      </main>
    </div>
  );
}

function HomeSection({ title, icon: Icon, headerBg, titleColor, iconColor, items, link, badgeType }: any) {
  const finalIconColor = iconColor || titleColor;
  
  return (
    <section className="bg-white pb-6">
      <div className={`flex items-center justify-between px-6 py-4 ${headerBg} mb-4`}>
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-white/20 backdrop-blur-sm rounded-lg">
            <Icon className={`w-4 h-4 ${finalIconColor} fill-current`} />
          </div>
          <h2 className={`text-[15px] font-black ${titleColor} uppercase tracking-tight`}>{title}</h2>
        </div>
        <Link href={link} className={`text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full shadow-sm active:scale-95 transition-all ${headerBg.startsWith('bg-[') ? 'text-slate-900' : headerBg.replace('bg-', 'text-')}`}>
          Tümü <ChevronRight className="w-3 h-3" />
        </Link>
      </div>
      
      {items && items.length > 0 ? (
        <div className="flex gap-4 overflow-x-auto px-4 scrollbar-none snap-x snap-mandatory pb-2">
          {items.map((item: any) => (
            <CompactCard key={item.id} item={item} badgeType={badgeType} />
          ))}
        </div>
      ) : (
        <EmptyState message={`${title} bulunmuyor.`} />
      )}
    </section>
  );
}

function CompactCard({ item, isGrid, badgeType }: { item: any; isGrid?: boolean; badgeType?: 'vitrin' | 'urgent' | 'newest' }) {
  const [isFavorite, setIsFavorite] = useState(false);
  
  const badgeConfig = {
    vitrin: { label: 'VİTRİN', icon: Star, color: 'bg-[#FBBF24]/90' },
    urgent: { label: 'ACİL', icon: Zap, color: 'bg-[#EF4444]/90' },
    newest: { label: 'YENİ', icon: Clock, color: 'bg-[#10B981]/90' },
  };

  const badge = badgeType ? badgeConfig[badgeType] : null;
  const BadgeIcon = badge?.icon;

  return (
    <Link href={`/requests/${item.id}`} className={`block shrink-0 snap-start group ${isGrid ? 'w-full' : 'w-[160px]'}`}>
      <div className="bg-white rounded-[1.5rem] overflow-hidden shadow-sm border border-slate-100 p-1 h-full hover:border-primary transition-colors">
        <div className="relative aspect-[4/3] rounded-[1.2rem] overflow-hidden mb-3 bg-slate-50">
          <img 
            src={item.images?.[0] || `https://picsum.photos/seed/${item.id}/400/300`} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
            alt={item.title} 
          />
          
          {badge && (
            <div className={`absolute top-2 left-2 flex items-center gap-1 px-2 h-5 ${badge.color} backdrop-blur-md rounded-full text-white z-10 border border-white/20 shadow-sm shadow-black/5`}>
               {BadgeIcon && <BadgeIcon className="w-2.5 h-2.5 fill-white" />}
               <span className="text-[8px] font-black uppercase tracking-tight">{badge.label}</span>
            </div>
          )}

          <button 
            className="absolute top-2 right-2 p-2 bg-white/20 backdrop-blur-md rounded-full transition-colors" 
            onClick={(e) => { 
              e.preventDefault(); 
              setIsFavorite(!isFavorite);
            }}
          >
            <Heart className={`w-4 h-4 transition-colors ${isFavorite ? 'fill-[#0033CC] text-[#0033CC]' : 'text-slate-300'}`} />
          </button>
        </div>
        <div className="space-y-2 px-2 pb-3">
          <h3 className="text-[12px] font-black text-slate-800 leading-tight line-clamp-2 uppercase tracking-tight min-h-[30px]">{item.title}</h3>
          <p className="text-[13px] font-black text-[#0033CC] tracking-tight">{item.budget ? `${item.budget} TL` : 'Görüşülecek'}</p>
          <div className="flex flex-col gap-1 pt-1 border-t border-slate-50">
            <div className="flex items-center gap-1.5 text-[9px] font-black text-[#0033CC] uppercase">
               <MessageSquare className="w-3 h-3 text-[#0033CC] shrink-0" />
               <span>{item.offerCount || 0} Teklif</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="px-6 py-10 text-center">
      <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mx-auto mb-3">
        <Inbox className="w-6 h-6 text-slate-200" />
      </div>
      <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.1em]">{message}</p>
    </div>
  );
}
