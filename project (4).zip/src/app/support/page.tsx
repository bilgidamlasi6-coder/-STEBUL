"use client";

import { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";
import { ArrowLeft, Send, LifeBuoy, CheckCircle2, ShieldAlert, AlertTriangle, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const COMPLAINT_CATEGORIES = [
  "Dolandırıcılık",
  "Hakaret / Saygısızlık",
  "Hizmet Verilmedi",
  "Farklı Hizmet Verildi",
  "Ödeme Sorunu",
  "Diğer"
];

export default function SupportPage() {
  const { user, profile } = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const [formData, setFormData] = useState({
    category: "",
    subject: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!db || !user || loading) return;
    
    setLoading(true);
    const collectionName = formData.category ? "complaints" : "support_requests";
    const collRef = collection(db, collectionName);
    const postData = {
      userId: user.uid,
      userName: `${profile?.isim || ""} ${profile?.soyadı || ""}`.trim() || "Kullanıcı",
      email: user.email,
      category: formData.category,
      subject: formData.subject,
      message: formData.message,
      status: "open",
      createdAt: serverTimestamp()
    };

    addDoc(collRef, postData)
      .then(() => {
        setSubmitted(true);
        toast({ title: "Gönderildi", description: "Talebiniz moderasyon ekibimize iletildi." });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: collRef.path,
          operation: 'create',
          requestResourceData: postData
        }));
        setLoading(false);
      });
  };

  if (submitted) {
    return (
      <div className="max-w-md mx-auto bg-white min-h-screen flex flex-col items-center justify-center p-10 text-center">
        <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-[2rem] flex items-center justify-center mb-6">
          <CheckCircle2 className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 mb-2">Talebiniz Alındı</h2>
        <p className="text-slate-400 font-medium text-sm mb-8 leading-relaxed">İSTEBUL Güvenlik ekibi en kısa sürede dönüş sağlayacaktır.</p>
        <Button onClick={() => router.push('/profile')} className="w-full h-14 rounded-2xl bg-primary font-black uppercase tracking-widest text-xs border-none shadow-lg">Profile Dön</Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-50 shadow-sm">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight uppercase">Destek & Şikayet</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">İSTEBUL ÇÖZÜM MERKEZİ</p>
          </div>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="px-6 py-8 space-y-6">
        <div className="bg-primary/5 p-6 rounded-[2rem] border border-primary/10 flex items-start gap-4">
          <AlertTriangle className="w-6 h-6 text-primary shrink-0" />
          <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
            Sorunlu bir ticaret mi yaşadınız? <br />Şikayetinizi kategorize ederek detaylıca anlatın. Ekibimiz kayıtları inceleyecektir.
          </p>
        </div>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">KATEGORİ (ŞİKAYET İSE SEÇİN)</Label>
            <Select onValueChange={(val) => setFormData({...formData, category: val})}>
              <SelectTrigger className="h-12 rounded-2xl bg-slate-50 border-none font-bold">
                <SelectValue placeholder="Seçim yapınız" />
              </SelectTrigger>
              <SelectContent className="rounded-xl border-none shadow-xl">
                {COMPLAINT_CATEGORIES.map(c => <SelectItem key={c} value={c} className="font-bold text-xs">{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">KONU BAŞLIĞI</Label>
            <Input 
              placeholder="Örn: Hizmet Kusuru, İletişim Sorunu"
              value={formData.subject}
              onChange={(e) => setFormData({...formData, subject: e.target.value})}
              required
              className="h-12 rounded-2xl bg-slate-50 border-none font-bold"
            />
          </div>
          
          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase text-slate-400 ml-1">DETAYLI AÇIKLAMA</Label>
            <Textarea 
              placeholder="Sorununuzu dürüstçe ve detaylıca anlatın..."
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              required
              className="min-h-[150px] rounded-2xl bg-slate-50 border-none font-medium p-4 resize-none"
            />
          </div>
        </div>

        <Button type="submit" disabled={loading} className="w-full h-14 rounded-2xl bg-primary text-white font-black uppercase tracking-widest shadow-xl shadow-primary/20 transition-all active:scale-95 border-none">
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Send className="w-4 h-4 mr-2" /> TALEBİ GÖNDER</>}
        </Button>
      </form>
    </div>
  );
}
