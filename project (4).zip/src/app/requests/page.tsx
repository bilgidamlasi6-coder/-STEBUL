"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useMemo, useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  SlidersHorizontal, 
  ArrowLeft, 
  Loader2, 
  Trash2,
  PauseCircle,
  PlayCircle,
  Edit3,
  Database
} from "lucide-react";
import { RequestCard } from "@/components/RequestCard";
import { type Request } from "@/lib/sample-data";
import { Button } from "@/components/ui/button";
import { useFirestore } from "@/firebase";
import { collection, query, orderBy, onSnapshot, where, doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { errorEmitter, FirestorePermissionError } from "@/firebase";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";

function RequestsList() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const db = useFirestore();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const categoryFilter = searchParams.get("category");
  const userIdFilter = searchParams.get("userId");
  const vitrinFilter = searchParams.get("vitrin") === "true";
  const urgentFilter = searchParams.get("urgent") === "true";
  const sortFilter = searchParams.get("sort");
  const searchQuery = searchParams.get("search");
  
  const [firestoreRequests, setFirestoreRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState(searchQuery || "");
  const [error, setError] = useState<{ message: string; code: string } | null>(null);

  const baseQuery = useMemo(() => {
    if (!db) return null;
    
    try {
      let q;
      
      if (vitrinFilter) {
        q = query(
          collection(db, "requests"), 
          where("status", "==", "active"), 
          where("isShowcase", "==", true), 
          orderBy("createdAt", "desc")
        );
      } else if (urgentFilter) {
        q = query(
          collection(db, "requests"), 
          where("status", "==", "active"), 
          where("urgent", "==", true), 
          orderBy("createdAt", "desc")
        );
      } else if (userIdFilter) {
        q = query(
          collection(db, "requests"), 
          where("userId", "==", userIdFilter), 
          where("status", "!=", "deleted"), 
          orderBy("status", "asc"), 
          orderBy("createdAt", "desc")
        );
      } else if (categoryFilter) {
        q = query(
          collection(db, "requests"), 
          where("status", "==", "active"), 
          where("category", "==", categoryFilter), 
          orderBy("createdAt", "desc")
        );
      } else {
        q = query(
          collection(db, "requests"), 
          where("status", "==", "active"), 
          orderBy("createdAt", "desc")
        );
      }

      return q;
    } catch (e) {
      console.error("Query building error:", e);
      return null;
    }
  }, [db, userIdFilter, vitrinFilter, urgentFilter, categoryFilter]);

  useEffect(() => {
    if (!baseQuery) {
      setLoading(false);
      return;
    }
    
    const unsubscribe = onSnapshot(baseQuery, 
      (snapshot) => {
        const fetched = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Request[];
        setFirestoreRequests(fetched);
        setLoading(false);
        setError(null);
      }, 
      (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: 'requests',
          operation: 'list'
        }));
        setLoading(false);
        if (err.code === 'failed-precondition') {
          setError({ message: "Dizinler yapılandırılıyor. Lütfen 1-2 dakika sonra tekrar deneyin.", code: err.code });
        } else {
          setError({ message: "İlanlar şu an yüklenemiyor.", code: err.code });
        }
      }
    );

    return () => unsubscribe();
  }, [baseQuery]);

  const handleUpdateStatus = (id: string, status: string) => {
    if (!db || actionLoading) return;
    
    setActionLoading(true);
    const docRef = doc(db, "requests", id);
    const updateData = { status, updatedAt: serverTimestamp() };

    updateDoc(docRef, updateData)
      .then(() => {
        toast({ title: "Başarılı", description: "İlan durumu güncellendi." });
      })
      .catch(async (err) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      })
      .finally(() => setActionLoading(false));
  };

  const filteredRequests = useMemo(() => {
    if (!searchTerm) return firestoreRequests;
    const term = searchTerm.toLowerCase();
    return firestoreRequests.filter(req => 
      req.title.toLowerCase().includes(term) || 
      req.category?.toLowerCase().includes(term) ||
      req.location?.toLowerCase().includes(term)
    );
  }, [firestoreRequests, searchTerm]);

  const headerTitle = useMemo(() => {
    if (userIdFilter) return "İlanlarım";
    if (vitrinFilter) return "Vitrin İlanları";
    if (urgentFilter) return "Acil Talepler";
    if (sortFilter === "new") return "Yeni Talepler";
    if (categoryFilter) return categoryFilter;
    return "Tüm Talepler";
  }, [categoryFilter, userIdFilter, vitrinFilter, urgentFilter, sortFilter]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-6 pt-4 pb-2 border-b border-slate-50">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={() => router.back()} className="p-1.5 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </button>
          <div className="min-w-0">
            <h1 className="text-sm font-black text-slate-900 tracking-tight leading-none uppercase truncate">{headerTitle}</h1>
            <p className="text-slate-400 font-bold text-[8px] uppercase tracking-widest mt-1">İSTEBUL MARKETPLACE</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
            <Input 
              placeholder="Ara..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 h-10 bg-slate-50 border-none rounded-xl text-xs font-medium"
            />
          </div>
          <Button variant="outline" size="icon" className="h-10 w-10 rounded-xl bg-slate-50 border-none"><SlidersHorizontal className="w-4 h-4 text-slate-600" /></Button>
        </div>
      </header>

      <div className="px-6 py-4 space-y-4 pb-24">
        {error ? (
          <div className="py-20 text-center bg-slate-50 rounded-[2.5rem] border border-dashed border-slate-200 px-10">
            <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mx-auto mb-6"><Database className="w-8 h-8 text-amber-500" /></div>
            <p className="text-slate-900 font-black uppercase text-[10px] tracking-widest mb-2">Dizin Hazırlanıyor</p>
            <p className="text-slate-400 text-[9px] leading-relaxed font-bold">{error.message}</p>
            <Button onClick={() => window.location.reload()} className="mt-6 bg-primary h-10 rounded-xl text-[10px] font-black uppercase px-6 text-white border-none">Yenile</Button>
          </div>
        ) : filteredRequests.length > 0 ? (
          filteredRequests.map(request => {
            const isOwner = user?.uid === request.userId;
            return (
              <div key={request.id} className="relative group">
                <RequestCard request={request} />
                {isOwner && (
                  <div className="absolute top-2 right-2 z-[60] flex items-center gap-1.5 bg-white/90 backdrop-blur-sm p-1 rounded-2xl shadow-sm border border-slate-100">
                    <button disabled={actionLoading} onClick={(e) => { e.preventDefault(); router.push(`/requests/${request.id}?edit=true`); }} className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-600 disabled:opacity-50"><Edit3 className="w-3.5 h-3.5" /></button>
                    {request.status === 'active' ? (
                      <button disabled={actionLoading} onClick={(e) => { e.preventDefault(); handleUpdateStatus(request.id, 'inactive'); }} className="p-1.5 hover:bg-slate-100 rounded-lg text-amber-500 disabled:opacity-50"><PauseCircle className="w-3.5 h-3.5" /></button>
                    ) : (
                      <button disabled={actionLoading} onClick={(e) => { e.preventDefault(); handleUpdateStatus(request.id, 'active'); }} className="p-1.5 hover:bg-slate-100 rounded-lg text-emerald-500 disabled:opacity-50"><PlayCircle className="w-3.5 h-3.5" /></button>
                    )}
                    <button disabled={actionLoading} onClick={(e) => { e.preventDefault(); handleUpdateStatus(request.id, 'deleted'); }} className="p-1.5 hover:bg-red-50 rounded-lg text-red-500 disabled:opacity-50"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-20 text-center bg-white rounded-[2.5rem] border border-dashed border-slate-100">
             <p className="text-slate-400 font-black uppercase text-[10px]">Henüz sonuç bulunamadı.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function RequestsMarketplace() {
  return <Suspense fallback={<div className="p-10 text-center font-bold text-slate-400">Yükleniyor...</div>}><RequestsList /></Suspense>;
}
