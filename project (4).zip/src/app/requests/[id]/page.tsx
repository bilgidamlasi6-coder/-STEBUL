"use client";

import { useParams, useRouter } from "next/navigation";
import { useState, useEffect, useMemo, Suspense } from "react";
import { 
  ArrowLeft, 
  MapPin, 
  Loader2,
  Calendar,
  Wallet,
  Handshake,
  Phone,
  MessageCircle,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ExternalLink,
  ChevronRight,
  User as UserIcon,
  MessageSquare,
  ShieldAlert,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFirestore, errorEmitter, FirestorePermissionError } from "@/firebase";
import { doc, onSnapshot, collection, addDoc, serverTimestamp, query, where } from "firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { AuthPanel } from "@/components/AuthPanel";
import { useToast } from "@/hooks/use-toast";
import { RelativeTime } from "@/components/RelativeTime";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

function RequestDetailContent() {
  const { id } = useParams();
  const router = useRouter();
  const db = useFirestore();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  
  const [request, setRequest] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [offerActionLoading, setOfferActionLoading] = useState(false);
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);
  const [hasActiveOffer, setHasActiveOffer] = useState(false);

  useEffect(() => {
    if (!db || !id) return;
    const unsubReq = onSnapshot(doc(db, "requests", id as string), (snap) => {
      if (snap.exists()) setRequest({ id: snap.id, ...snap.data() });
      setLoading(false);
    });
    return () => unsubReq();
  }, [db, id]);

  useEffect(() => {
    if (!db || !id || !user) { setHasActiveOffer(false); return; }
    const q = query(collection(db, "requests", id as string, "offers"), where("businessId", "==", user.uid));
    const unsubOfferCheck = onSnapshot(q, (snap) => setHasActiveOffer(!snap.empty));
    return () => unsubOfferCheck();
  }, [db, id, user]);

  const handleGiveOffer = () => {
    if (!user) { setIsAuthPanelOpen(true); return; }
    if (!db || !id || offerActionLoading || !request) return;
    setOfferActionLoading(true);
    const offersRef = collection(db, "requests", id as string, "offers");
    const offerData = {
      amount: "Fiyat Görüşülecek",
      message: "Bu hizmet talebi ile ilgileniyorum.",
      businessId: user.uid,
      businessName: `${profile?.isim || ""} ${profile?.soyadı || ""}`.trim(),
      businessAvatar: profile?.avatar || `https://picsum.photos/seed/${user.uid}/160/160`,
      requestUserId: request.userId,
      requestTitle: request.title,
      status: 'pending',
      createdAt: serverTimestamp()
    };
    addDoc(offersRef, offerData).then(() => {
      toast({ title: "Teklif İletildi", description: "Süreci 'Teklifler' sayfasından takip edebilirsiniz." });
      router.push('/offers');
    }).catch(async (err) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({ path: offersRef.path, operation: 'create', requestResourceData: offerData }));
    }).finally(() => setOfferActionLoading(false));
  };

  const maskedName = useMemo(() => {
    if (!request?.user?.name) return "İstebul Üyesi";
    const parts = request.user.name.split(' ');
    return parts.length < 2 ? request.user.name : `${parts[0]} ${parts[parts.length - 1].charAt(0)}.`;
  }, [request]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;
  if (!request) return <div className="p-10 text-center font-black text-slate-300 uppercase text-xs">İlan bulunamadı.</div>;

  const [city, district] = (request.location || "").split(' / ');

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto relative flex flex-col">
      <section className="bg-slate-100 relative w-full aspect-[4/3]">
        {request.images && request.images.length > 0 ? (
          <img src={request.images[0]} className="w-full h-full object-cover" alt="" />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-slate-50 text-slate-200">
            <UserIcon className="w-20 h-20" />
          </div>
        )}
        <button onClick={() => router.back()} className="absolute top-4 left-4 p-2.5 bg-white/90 backdrop-blur-md rounded-full shadow-lg z-10 active:scale-95 transition-all">
          <ArrowLeft className="w-5 h-5 text-slate-900" />
        </button>
      </section>

      <main className="flex-1 px-6 py-6 pb-44">
        <div className="mb-6">
          <span className="text-[9px] font-black text-primary bg-primary/5 px-2.5 py-1 rounded-lg uppercase tracking-wider mb-2.5 inline-block">
            {request.category}
          </span>
          <h1 className="text-2xl font-black text-slate-900 leading-tight uppercase mb-2 tracking-tight">{request.title}</h1>
          <div className="flex items-center gap-3">
             <p className="text-2xl font-black text-primary tracking-tighter">
               {request.budget ? `${request.budget} TL` : "Fiyat Görüşülecek"}
             </p>
             <div className="h-4 w-px bg-slate-100" />
             <div className="flex items-center gap-1.5 text-[10px] font-black text-slate-400 uppercase">
                <Clock className="w-3 h-3" />
                <RelativeTime date={request.createdAt} />
             </div>
          </div>
        </div>

        <Tabs defaultValue="info" className="w-full">
          <TabsList className="w-full h-12 bg-slate-50 p-1 rounded-2xl mb-8">
            <TabsTrigger value="info" className="flex-1 rounded-xl text-[10px] font-black uppercase data-[state=active]:bg-white data-[state=active]:shadow-sm">İlan Bilgileri</TabsTrigger>
            <TabsTrigger value="desc" className="flex-1 rounded-xl text-[10px] font-black uppercase data-[state=active]:bg-white data-[state=active]:shadow-sm">Açıklama</TabsTrigger>
            <TabsTrigger value="location" className="flex-1 rounded-xl text-[10px] font-black uppercase data-[state=active]:bg-white data-[state=active]:shadow-sm">Konum</TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="bg-white rounded-[2rem] border border-slate-100 divide-y divide-slate-50 overflow-hidden shadow-sm">
               {request.customFields && Object.keys(request.customFields).length > 0 ? Object.entries(request.customFields).map(([key, val]: [string, any]) => (
                 <div key={key} className="flex justify-between items-center p-5 group hover:bg-slate-50/50 transition-colors">
                   <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{key.replace(/_/g, ' ')}</span>
                   <span className="text-xs font-black text-slate-800 uppercase text-right">{val}</span>
                 </div>
               )) : (
                 <div className="p-10 text-center space-y-2">
                    <Info className="w-8 h-8 text-slate-200 mx-auto" />
                    <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Ek teknik bilgi girilmemiş.</p>
                 </div>
               )}
            </div>
          </TabsContent>

          <TabsContent value="desc" className="animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="p-6 bg-slate-50/50 rounded-[2rem] border border-slate-100 text-[13px] text-slate-600 leading-relaxed whitespace-pre-wrap font-medium shadow-inner">
              {request.description}
            </div>
          </TabsContent>

          <TabsContent value="location" className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="p-5 bg-white border border-slate-100 rounded-[2rem] shadow-sm flex items-center gap-4">
              <div className="bg-primary/5 p-4 rounded-2xl shadow-inner"><MapPin className="w-6 h-6 text-primary" /></div>
              <div>
                <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{city}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{district}</p>
              </div>
            </div>
            <div onClick={() => router.push(`/profile?uid=${request.userId}`)} className="p-5 bg-white border border-slate-100 rounded-[2rem] shadow-sm flex items-center justify-between cursor-pointer active:scale-[0.98] transition-all group">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center border border-slate-100 text-slate-300 group-hover:bg-primary/5 group-hover:text-primary transition-all overflow-hidden">
                  {request.user?.avatar ? <img src={request.user.avatar} className="w-full h-full object-cover" /> : <UserIcon className="w-7 h-7" />}
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <p className="text-sm font-black text-slate-900 uppercase tracking-tight">{maskedName}</p>
                    <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  </div>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mt-1">İSTEBUL DOĞRULANMIŞ ÜYE</p>
                </div>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-200 group-hover:text-primary group-hover:translate-x-1 transition-all" />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white/95 backdrop-blur-md border-t border-slate-50 z-[100] max-w-md mx-auto shadow-[0_-15px_40px_rgba(0,0,0,0.05)] rounded-t-[2.5rem]">
        {request.status === 'active' && user?.uid !== request.userId ? (
          !hasActiveOffer ? (
            <Button 
              onClick={handleGiveOffer}
              disabled={offerActionLoading}
              className="w-full bg-primary h-14 rounded-2xl font-black text-white uppercase tracking-widest text-[11px] border-none shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all"
            >
              {offerActionLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Handshake className="w-5 h-5 mr-2" />}
              {offerActionLoading ? "İŞLENİYOR..." : "HEMEN TEKLİF VER"}
            </Button>
          ) : (
            <div className="flex gap-2.5 w-full animate-in zoom-in-95 duration-500">
              <Button 
                onClick={() => router.push('/chats')}
                className="flex-1 bg-[#0033CC] h-14 rounded-2xl font-black text-white uppercase tracking-widest text-[10px] border-none shadow-xl shadow-blue-500/20"
              >
                <MessageSquare className="w-4 h-4 mr-2" /> MESAJ GÖNDER
              </Button>
              <button 
                onClick={() => request?.user?.telefon && (window.location.href = `tel:${request.user.telefon}`)}
                className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg active:scale-90 transition-all hover:bg-emerald-700"
              >
                <Phone className="w-5 h-5" />
              </button>
              <button 
                onClick={() => request?.user?.telefon && window.open(`https://wa.me/${request.user.telefon.replace(/\s+/g, '')}`, '_blank')}
                className="w-14 h-14 bg-[#25D366] rounded-2xl flex items-center justify-center text-white shadow-lg active:scale-90 transition-all hover:bg-green-600"
              >
                <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.353-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.138 1.36.12 1.871.044.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.187-1.622c1.736.946 3.7 1.444 5.7 1.446h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </button>
            </div>
          )
        ) : (
           <div className="bg-slate-50 p-4 rounded-2xl flex items-center justify-center gap-3 border border-slate-100 animate-pulse">
              <ShieldAlert className="w-5 h-5 text-amber-500" />
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">BU İLANIN YÖNETİCİSİ SİZSİNİZ</span>
           </div>
        )}
      </div>

      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
    </div>
  );
}

export default function RequestDetail() {
  return <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>}><RequestDetailContent /></Suspense>;
}