export const TURKEY_PROVINCES = [
  "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin",
  "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale",
  "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum",
  "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta", "Mersin",
  "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir", "Kocaeli",
  "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla", "Muş",
  "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas",
  "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van", "Yozgat", "Zonguldak",
  "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan",
  "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"
].sort((a, b) => a.localeCompare(b, 'tr'));

export const TURKEY_DISTRICTS: Record<string, string[]> = {
  "Adana": ["Aladağ", "Ceyhan", "Çukurova", "Feke", "İmamoğlu", "Karaisalı", "Karataş", "Kozan", "Pozantı", "Saimbeyli", "Sarıçam", "Seyhan", "Tufanbeyli", "Yumurtalık", "Yüreğir"],
  "Ankara": ["Akyurt", "Altındağ", "Ayaş", "Bala", "Beypazarı", "Çamlıdere", "Çankaya", "Çubuk", "Elmadağ", "Etimesgut", "Evren", "Gölbaşı", "Güdül", "Haymana", "Kahramankazan", "Kalecik", "Keçiören", "Kızılcahamam", "Mamak", "Nallıhan", "Polatlı", "Pursaklar", "Sincan", "Yenimahalle"],
  "İstanbul": ["Adalar", "Arnavutköy", "Ataşehir", "Avcılar", "Bağcılar", "Bahçelievler", "Bakırköy", "Başakşehir", "Bayrampaşa", "Beşiktaş", "Beykoz", "Beylikdüzü", "Beyoğlu", "Büyükçekmece", "Çatalca", "Çekmeköy", "Esenler", "Esenyurt", "Eyüpsultan", "Fatih", "Gaziosmanpaşa", "Güngören", "Kadıköy", "Kağıthane", "Kartal", "Küçükçekmece", "Maltepe", "Pendik", "Sancaktepe", "Sarıyer", "Silivri", "Sultanbeyli", "Sultangazi", "Şile", "Şişli", "Tuzla", "Ümraniye", "Üsküdar", "Zeytinburnu"],
  "İzmir": ["Aliağa", "Balçova", "Bayındır", "Bayraklı", "Bergama", "Beydağ", "Bornova", "Buca", "Çeşme", "Çiğli", "Dikili", "Foça", "Gaziemir", "Güzelbahçe", "Karabağlar", "Karaburun", "Karşıyaka", "Kemalpaşa", "Kınık", "Kiraz", "Konak", "Menderes", "Menemen", "Narlıdere", "Ödemiş", "Seferihisar", "Selçuk", "Tire", "Torbalı", "Urla"],
  "Antalya": ["Akseki", "Aksu", "Alanya", "Demre", "Döşemealtı", "Elmalı", "Finike", "Gazipaşa", "Gündoğmuş", "İbradı", "Kaş", "Kemer", "Kepez", "Konyaaltı", "Korkuteli", "Kumluca", "Manavgat", "Muratpaşa", "Serik"],
  "Bursa": ["Büyükorhan", "Gemlik", "Gürsu", "Harmancık", "İnegöl", "İznik", "Karacabey", "Keles", "Kestel", "Mudanya", "Mustafakemalpaşa", "Nilüfer", "Orhaneli", "Orhangazi", "Osmangazi", "Yenişehir", "Yıldırım"],
  "Kocaeli": ["Başiskele", "Çayırova", "Darica", "Derince", "Dilovası", "Gebze", "Gölcük", "İzmit", "Kandira", "Karamürsel", "Kartepe", "Körfez"],
  "Muğla": ["Bodrum", "Dalaman", "Datça", "Fethiye", "Kavaklıdere", "Köyceğiz", "Marmaris", "Menteşe", "Milas", "Ortaca", "Seydikemer", "Ula", "Yatağan"]
};

export const TURKEY_NEIGHBORHOODS: Record<string, string[]> = {
  "İstanbul_Kadıköy": ["Acıbadem Mah.", "Bostancı Mah.", "Caddebostan Mah.", "Caferağa Mah.", "Dumlupınar Mah.", "Eğitim Mah.", "Erenköy Mah.", "Fenerbahçe Mah.", "Feneryolu Mah.", "Fikirtepe Mah.", "Göztepe Mah.", "Hasanpaşa Mah.", "Koşuyolu Mah.", "Kozyatağı Mah.", "Merdivenköy Mah.", "Osmanağa Mah.", "Rasimpaşa Mah.", "Sahrayıcedit Mah.", "Suadiye Mah.", "Zühtüpaşa Mah."],
  "İstanbul_Arnavutköy": ["Anadolu Mah.", "Arnavutköy Merkez Mah.", "Baklalı Mah.", "Boğazköy Mah.", "Bolluca Mah.", "Çilingir Mah.", "Dursunköy Mah.", "Hadımköy Mah.", "Haraççı Mah.", "İmrahor Mah.", "İslambey Mah.", "Karaburun Mah.", "Karlıbayır Mah.", "Mavigöl Mah.", "Nenehatun Mah.", "Taşoluk Mah.", "Yeniköy Mah."],
  "Ankara_Çankaya": ["Ahlatlıbel Mah.", "Anıttepe Mah.", "Ayrancı Mah.", "Bahçelievler Mah.", "Balgat Mah.", "Birlik Mah.", "Cebeci Mah.", "Çukurambar Mah.", "Dikmen Mah.", "Emek Mah.", "Esat Mah.", "Gaziosmanpaşa Mah.", "Huzur Mah.", "Kavaklıdere Mah.", "Kırkkonaklar Mah.", "Kızılay Mah.", "Maltepe Mah.", "Mebusevleri Mah.", "Mutlukent Mah.", "Oran Mah.", "Sancak Mah.", "Söğütözü Mah.", "Yıldız Mah."],
  "İzmir_Konak": ["Akdeniz Mah.", "Alsancak Mah.", "Altý Mah.", "Atilla Mah.", "Barbaros Mah.", "Boğaziçi Mah.", "Çankaya Mah.", "Ege Mah.", "Göztepe Mah.", "Gültepe Mah.", "Güneşli Mah.", "Huzur Mah.", "Kahramanlar Mah.", "Kültür Mah.", "Mehtap Mah.", "Mithatpaşa Mah.", "Murat Mah.", "Piri Reis Mah.", "Turgut Reis Mah.", "Yeni Mah."],
  "Antalya_Muratpaşa": ["Altındağ Mah.", "Bahçelievler Mah.", "Balbey Mah.", "Barbaros Mah.", "Bayındır Mah.", "Çağlayan Mah.", "Demircikara Mah.", "Deniz Mah.", "Doğu Garajı Mah.", "Emeç Mah.", "Fener Mah.", "Gebizli Mah.", "Güvenlik Mah.", "Güzeloba Mah.", "Haşimişcan Mah.", "Kılınçarslan Mah.", "Kırcami Mah.", "Konuksever Mah.", "Lara Mah.", "Meltem Mah.", "Meydankavağı Mah.", "Özgürlük Mah.", "Şirinyalı Mah.", "Yüksekalan Mah."],
  "Bursa_Nilüfer": ["23 Nisan Mah.", "Alaaddinbey Mah.", "Altınşehir Mah.", "Beşevler Mah.", "Cumhuriyet Mah.", "Çamlıca Mah.", "Demirci Mah.", "Ertuğrul Mah.", "Fethiye Mah.", "Görükle Mah.", "İhsaniye Mah.", "Işıktepe Mah.", "Karaman Mah.", "Konak Mah.", "Küçük Sanayi Mah.", "Odunluk Mah.", "Özlüce Mah.", "Üçevler Mah."],
  "Kocaeli_Gebze": ["Adem Yavuz Mah.", "Arapçeşme Mah.", "Barış Mah.", "Beylikbağı Mah.", "Cumhuriyet Mah.", "Gaziler Mah.", "Güzeller Mah.", "Hacıhalil Mah.", "Hürriyet Mah.", "İnönü Mah.", "İstasyon Mah.", "Kirazpınar Mah.", "Köşklüçeşme Mah.", "Mevlana Mah.", "Mimar Sinan Mah.", "Mustafa Paşa Mah.", "Osman Yılmaz Mah.", "Sultan Orhan Mah.", "Tatlıkuyu Mah.", "Ulus Mah.", "Yavuz Selim Mah.", "Yenikent Mah."]
};

export function getDistricts(province: string): string[] {
  return TURKEY_DISTRICTS[province] || [];
}

export function getNeighborhoods(province: string, district: string): string[] {
  const key = `${province}_${district}`;
  return TURKEY_NEIGHBORHOODS[key] || ["Merkez Mah."];
}
