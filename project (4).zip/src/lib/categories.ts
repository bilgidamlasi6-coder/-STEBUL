export interface CustomField {
  key: string;
  label: string;
  type: 'text' | 'number' | 'select' | 'boolean' | 'date';
  options?: string[];
  unit?: string;
  placeholder?: string;
  dependsOn?: string;
  conditionalOptions?: Record<string, string[]>;
}

export interface SubCategory {
  id: string;
  name: string;
  fields?: CustomField[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  subCategories: SubCategory[];
}

export const CATEGORIES: Category[] = [
  {
    id: 'cat_emlak',
    name: 'Emlak & Yaşam',
    slug: 'emlak-ve-yasam',
    iconName: 'House',
    subCategories: [
      { 
        id: 'sub_satilik_daire', 
        name: 'Satılık Daire Arıyorum', 
        fields: [
          { key: 'oda_sayisi', label: 'Oda Sayısı', type: 'select', options: ['1+0 (Stüdyo)', '1+1', '2+1', '3+1', '4+1', '4+2 Duplex', '5+1', 'Müstakil/Villa'] },
          { key: 'metrekare', label: 'Metrekare (Net)', type: 'number', unit: 'm²' },
          { key: 'kat', label: 'Bulunduğu Kat', type: 'select', options: ['Giriş Katı', '1. Kat', '2. Kat', '3. Kat', '4. Kat ve Üzeri', 'Ara Kat', 'En Üst Kat'] },
          { key: 'bina_yasi', label: 'Bina Yaşı', type: 'select', options: ['0 (Yeni)', '1-5 Yıl', '6-10 Yıl', '11-15 Yıl', '16-20 Yıl', '21+ Yıl'] },
          { key: 'isitma', label: 'Isıtma Tipi', type: 'select', options: ['Doğalgaz Kombi', 'Merkezi Sistem', 'Yerden Isıtma', 'Klima', 'Isıtma Yok'] }
        ]
      },
      { 
        id: 'sub_kiralik_daire', 
        name: 'Kiralık Daire Arıyorum',
        fields: [
          { key: 'oda_sayisi', label: 'Oda Sayısı', type: 'select', options: ['1+0', '1+1', '2+1', '3+1', '4+1', '5+1'] },
          { key: 'metrekare', label: 'Metrekare (Net)', type: 'number', unit: 'm²' },
          { key: 'esya_durumu', label: 'Eşya Durumu', type: 'select', options: ['Eşyalı', 'Eşyasız'] },
          { key: 'bina_yasi', label: 'Bina Yaşı', type: 'select', options: ['0 (Yeni)', '1-5 Yıl', '6-10 Yıl', '11-20 Yıl', '21+ Yıl'] }
        ]
      },
      { 
        id: 'sub_arsa', 
        name: 'Satılık Arsa Arıyorum', 
        fields: [
          { key: 'metrekare', label: 'Metrekare', type: 'number', unit: 'm²' },
          { key: 'imar_durumu', label: 'İmar Durumu', type: 'select', options: ['Konut İmarlı', 'Ticari İmarlı', 'Sanayi İmarlı', 'Bağ / Bahçe', 'İmarsız Tarla'] }
        ] 
      },
      { id: 'sub_isyeri', name: 'Kiralık İşyeri Arıyorum', fields: [{ key: 'kullanim_alani', label: 'Kullanım Alanı', type: 'number', unit: 'm²' }, { key: 'tip', label: 'İşyeri Tipi', type: 'select', options: ['Dükkan/Mağaza', 'Ofis', 'Depo', 'Fabrika', 'Atölye'] }] },
      { id: 'sub_ofis', name: 'Ofis Arıyorum' },
      { id: 'sub_devren', name: 'Devren İşyeri' },
      { id: 'sub_yazlik', name: 'Yazlık' },
      { id: 'sub_gunluk', name: 'Günlük Kiralık' },
      { id: 'sub_oda_arkadasi', name: 'Oda Arkadaşı' },
      { id: 'sub_depo', name: 'Depo Arıyorum' },
      { id: 'sub_bahce', name: 'Bahçe' },
      { id: 'sub_emlak_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_arac',
    name: 'Araç & Otomotiv',
    slug: 'arac-ve-otomotiv',
    iconName: 'CarFront',
    subCategories: [
      { 
        id: 'sub_arac_arama', 
        name: 'Araç Arıyorum', 
        fields: [
          { key: 'marka', label: 'Marka Tercihi', type: 'select', options: ['Fiat', 'Renault', 'Volkswagen', 'Ford', 'Hyundai', 'Toyota', 'Mercedes-Benz', 'Audi', 'BMW', 'Peugeot', 'Citroen', 'Opel', 'Skoda', 'Nissan', 'Honda', 'Seat / Cupra', 'Dacia', 'Togg', 'Diğer'] },
          { 
            key: 'model', 
            label: 'Model/Seri', 
            type: 'select', 
            dependsOn: 'marka',
            conditionalOptions: {
              'Fiat': ['Egea Sedan', 'Egea Hatchback', 'Egea Cross', 'Doblo Combi', 'Fiorino', 'Linea', '500', 'Ducato'],
              'Renault': ['Clio', 'Megane Sedan', 'Megane E-Tech', 'Fluence', 'Symbol', 'Kangoo', 'Master', 'Austral'],
              'Volkswagen': ['Golf', 'Passat', 'Polo', 'Jetta', 'Tiguan', 'T-Roc', 'Caddy', 'Transporter', 'Crafter'],
              'Ford': ['Focus', 'Fiesta', 'Tourneo Courier', 'Transit', 'Ranger', 'Kuga', 'Puma'],
              'Hyundai': ['i10', 'i20', 'i30', 'Accent Blue', 'Elantra', 'Tucson', 'Bayon', 'Kona', 'H100'],
              'Toyota': ['Corolla', 'Yaris', 'Auris', 'CH-R', 'Hilux', 'Proace City', 'Rav4'],
              'Mercedes-Benz': ['C-Serisi', 'E-Serisi', 'A-Serisi', 'CLA', 'GLA', 'Vito', 'Sprinter', 'Actros (Kamyon)'],
              'Audi': ['A3 Sedan', 'A4', 'A5', 'A6', 'Q2', 'Q3', 'Q5', 'e-tron'],
              'BMW': ['1 Serisi', '2 Serisi', '3 Serisi', '4 Serisi', '5 Serisi', 'X1', 'X3', 'X5', 'i4'],
              'Peugeot': ['208', '301', '308', '508', '2008', '3008', '5008', 'Rifter', 'Partner'],
              'Citroen': ['C3', 'C3 Aircross', 'C4', 'C5 Aircross', 'Berlingo', 'Jumpy', 'Jumper', 'Ami'],
              'Opel': ['Corsa', 'Astra', 'Insignia', 'Mokka', 'Grandland', 'Combo', 'Vivaro'],
              'Skoda': ['Fabia', 'Scala', 'Octavia', 'Superb', 'Kamiq', 'Karoq', 'Kodiaq'],
              'Nissan': ['Micra', 'Qashqai', 'X-Trail', 'Juke', 'Navara'],
              'Honda': ['Civic Sedan', 'City', 'Jazz', 'HR-V', 'CR-V', 'Accord'],
              'Dacia': ['Duster', 'Sandero Stepway', 'Jogger', 'Lodgy', 'Spring'],
              'Togg': ['T10X']
            }
          },
          { key: 'yil', label: 'Yıl Aralığı', type: 'select', options: ['2026', '2025', '2024', '2023', '2022', '2021', '2020', '2019-2015', '2014-2010', '2009 ve altı'] },
          { key: 'yakit', label: 'Yakıt Tipi', type: 'select', options: ['Benzin', 'Dizel', 'Benzin & LPG', 'Hibrit', 'Elektrik'] },
          { key: 'vites', label: 'Vites Tipi', type: 'select', options: ['Manuel', 'Otomatik (DSG/EDC/EAT8)', 'Yarı Otomatik'] },
          { key: 'km', label: 'Kilometre (Maks)', type: 'number', unit: 'km' },
          { key: 'kasa', label: 'Kasa Tipi', type: 'select', options: ['Sedan', 'Hatchback', 'SUV', 'Station Wagon', 'Coupe', 'Panelvan', 'Minibüs', 'Kamyonet'] },
          { key: 'ekspertiz', label: 'Hasar/Ekspertiz', type: 'select', options: ['Hatasız / Boyasız', 'Lokal Boyalı', 'Bel Altı Boyalı', 'Değişen Parçalı', 'Ağır Hasar Kayıtlı'] }
        ]
      },
      { id: 'sub_kiralik_arac', name: 'Kiralık Araç Arıyorum', fields: [{ key: 'kiralama_suresi', label: 'Kiralama Süresi', type: 'select', options: ['Günlük', 'Haftalık', 'Aylık', 'Yıllık / Operasyonel'] }] },
      { id: 'sub_ticari_arac', name: 'Ticari Araç Arıyorum' },
      { id: 'sub_kamyon', name: 'Kamyon Arıyorum' },
      { id: 'sub_motosiklet', name: 'Motosiklet Arıyorum' },
      { id: 'sub_oto_tamir', name: 'Oto Tamir' },
      { id: 'sub_oto_elektrik', name: 'Oto Elektrik' },
      { id: 'sub_ekspertiz', name: 'Ekspertiz' },
      { id: 'sub_lastik', name: 'Lastik' },
      { id: 'sub_yedek_parca', name: 'Yedek Parça' },
      { id: 'sub_cekici', name: 'Çekici' },
      { id: 'sub_oto_kurtarma', name: 'Oto Kurtarma' },
      { id: 'sub_arac_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_nakliye',
    name: 'Nakliye & Lojistik',
    slug: 'nakliye-ve-lojistik',
    iconName: 'Truck',
    subCategories: [
      { 
        id: 'sub_sehir_ici', 
        name: 'Şehir İçi Nakliye', 
        fields: [
          { key: 'nereden', label: 'Nereden (İlçe)', type: 'text' },
          { key: 'nereye', label: 'Nereye (İlçe)', type: 'text' },
          { key: 'esya_tipi', label: 'Eşya Tipi / Hacmi', type: 'select', options: ['1+1 Ev Eşyası', '2+1 Ev Eşyası', '3+1 Ev Eşyası', 'Ofis Malzemesi', 'Parça Eşya', 'Paletli Ürün'] },
          { key: 'tarih', label: 'Taşıma Tarihi', type: 'date' },
          { key: 'asansor', label: 'Asansörlü Taşıma', type: 'select', options: ['Gerekli', 'Gerekli Değil'] }
        ]
      },
      { id: 'sub_sehirler_arasi', name: 'Şehirler Arası Nakliye' },
      { id: 'sub_parsiyel', name: 'Parsiyel Taşıma' },
      { id: 'sub_komple', name: 'Komple Taşıma' },
      { id: 'sub_ev_tasima', name: 'Ev Taşıma' },
      { id: 'sub_ofis_tasima', name: 'Ofis Taşıma' },
      { id: 'sub_depolama', name: 'Depolama' },
      { id: 'sub_kurye', name: 'Kurye' },
      { id: 'sub_soguk_zincir', name: 'Soğuk Zincir', fields: [{ key: 'derece', label: 'Isı Derecesi', type: 'select', options: ['+4 Derece (Taze)', '-18 Derece (Donuk)', 'Standart'] }] },
      { id: 'sub_lojistik', name: 'Lojistik Hizmeti' },
      { id: 'sub_nakliye_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_gida',
    name: 'Gıda & Tarım',
    slug: 'gida-ve-tarim',
    iconName: 'Wheat',
    subCategories: [
      { 
        id: 'sub_kuruyemis', 
        name: 'Kuruyemiş Alımı', 
        fields: [
          { 
            key: 'urun_tipi', 
            label: 'Ürün Tipi', 
            type: 'select', 
            options: [
              'Kabuklu Ceviz (Yerli)', 'Kabuklu Ceviz (İthal Chandler)', 'İç Ceviz (Kelebek Beyaz)', 'İç Ceviz (Kırık/Pasta Tipi)',
              'Kabuklu Fındık', 'Kavrulmuş İç Fındık (11-13 mm)', 'Kavrulmuş İç Fındık (13-15 mm)', 'Çiğ İç Fındık',
              'Kabuklu Antep Fıstığı (Ana Çatlak)', 'Kavrulmuş Duble Antep Fıstığı', 'Çiğ İç Fıstık (Kuşboku Yeşil)',
              'Siirt Fıstığı', 'Tuzlu Duble Kaju (W180)', 'Tuzlu Kaju (W240/W320)', 'Beyaz Leblebi', 'Sarı Leblebi',
              'Tuzlu Kabak Çekirdeği', 'Tuzlu Ay Çekirdeği (Dakota)', 'Badem İçi (Datça)', 'Badem İçi (İthal)', 'Lüks Kokteyl Karışım'
            ] 
          },
          { key: 'kalibre', label: 'Kalibre / Boyut', type: 'select', options: ['W180 (En İri)', 'W240 (İri)', 'W320 (Standart)', '9-11 mm', '11-13 mm', '13-15 mm', '28-30 Kalibre', 'Elek Altı / Pasta Tipi'] },
          { key: 'isleme_tipi', label: 'İşleme Tipi', type: 'select', options: ['Kabuklu %100 Doğal', 'İç (Kabuğu Soyulmuş)', 'Çiğ', 'Kavrulmuş (Düşük Isı)', 'Kavrulmuş (Duble)', 'Tuzlu', 'Soslu'] },
          { key: 'kalite_analizi', label: 'Kalite Analizi', type: 'select', options: ['Aflatoksin Analizli (İhracat)', 'Rutubet %4.5 Altı (Lüks)', 'Elek/Süzme Garantili', 'Standart Ticari'] },
          { key: 'miktar', label: 'Miktar (KG/Ton)', type: 'number' },
          { key: 'ambalaj', label: 'Ambalaj Tipi', type: 'select', options: ['Karton Kutu + Vakum (10 Kg)', 'Karton Kutu (5 Kg)', 'Jüt Çuval (25 Kg)', 'Jüt Çuval (50 Kg)', 'Vakumlu Paket (1 Kg)', 'Big Bag (500 Kg)'] },
          { key: 'teslimat', label: 'Teslimat Şekli', type: 'select', options: ['Fabrika Teslim (EXW)', 'Depo Teslim (FOB)', 'Alıcı Depo Teslim (DDP)', 'Kargo/Ambar'] }
        ]
      },
      { 
        id: 'sub_kuru_meyve', 
        name: 'Kuru Meyve Alımı', 
        fields: [
          { 
            key: 'urun_tipi', 
            label: 'Ürün Tipi', 
            type: 'select', 
            options: [
              'Malatya Sarı Kayısı (Kükürtlü)', 'Doğal Gün Kurusu Kayısı', 'Organik Gün Kurusu', 'Kuru İncir (A Kalite Dağ İnciri)', 'Kuru İncir (Endüstriyel)',
              'Kuru Üzüm (Tip 9-10-11)', 'Siyah Kuru Üzüm', 'Medjool Hurma (Lüks)', 'İran Hurması', 'Kuru Dut', 'Kuru Erik', 'Kuru Mango/Ananas', 'Kuru Domates'
            ] 
          },
          { key: 'kalibre', label: 'Kalibre / Boyut', type: 'select', options: ['0 Numara (Jumbo)', '1 Numara (Dublex)', '2 Numara', '3 Numara', '4 Numara', '5 Numara', 'Endüstriyel / Elek Altı', 'Küp Kesim (5x5mm)'] },
          { key: 'rutubet', label: 'Nem / Rutubet Oranı', type: 'select', options: ['Standart (%20 - %24)', 'Yüksek Nemli (%25 - %28)', 'Kuru (%16 - %19)', 'Fırınlanmış Nem Kararlı'] },
          { key: 'kimyasal', label: 'Koruma / Kimyasal', type: 'select', options: ['Kükürtlü (AB Standardı)', 'Kükürtlü (İç Piyasa)', 'Natürel / Organik (Sıfır Kükürt)', 'Lazer Seçimli'] },
          { key: 'miktar', label: 'Miktar (KG/Ton)', type: 'number' },
          { key: 'ambalaj', label: 'Ambalaj Tipi', type: 'select', options: ['Karton Kutu (5kg)', 'Karton Kutu (10kg)', 'Jüt Çuval', 'Plastik Kasa', 'Doypack Kilitli'] }
        ]
      },
      { id: 'sub_meyve', name: 'Meyve Alımı' },
      { id: 'sub_sebze', name: 'Sebze Alımı' },
      { id: 'sub_bakliyat', name: 'Bakliyat Alımı' },
      { id: 'sub_baharat', name: 'Baharat Alımı' },
      { id: 'sub_et', name: 'Et Ürünleri' },
      { id: 'sub_unlu', name: 'Unlu Mamuller' },
      { id: 'sub_organik', name: 'Organik Ürün' },
      { id: 'sub_gida_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_saglik',
    name: 'Sağlık & Bakım',
    slug: 'saglik-ve-bakim',
    iconName: 'HeartPulse',
    subCategories: [
      { 
        id: 'sub_hasta_bakici', 
        name: 'Hasta Bakıcı', 
        fields: [
          { key: 'calisma_sekli', label: 'Çalışma Şekli', type: 'select', options: ['Yatılı (7/24)', 'Gündüzlü (Tam Zamanlı)', 'Gündüzlü (Yarı Zamanlı)', 'Saatlik / Günlük'] },
          { key: 'deneyim', label: 'Aranan Deneyim', type: 'select', options: ['0-2 Yıl Deneyimli', '3-5 Yıl Deneyimli', '5+ Yıl Uzman / Referanslı'] },
          { key: 'sertifika', label: 'Sertifika / Belge', type: 'select', options: ['İlk Yardım Sertifikalı', 'Hemşirelik / Hasta Bakım Mezunu', 'Belgeli Değil / Deneyimli'] }
        ]
      },
      { id: 'sub_yasli_bakimi', name: 'Yaşlı Bakımı' },
      { id: 'sub_cocuk_bakici', name: 'Çocuk Bakıcısı', fields: [{ key: 'dil', label: 'Yabancı Dil Tercihi', type: 'select', options: ['İngilizce', 'Rusça', 'Arapça', 'Sadece Türkçe'] }] },
      { id: 'sub_hemsire', name: 'Hemşire Hizmeti' },
      { id: 'sub_evde_saglik', name: 'Evde Sağlık Hizmeti' },
      { id: 'sub_fizyoterapi', name: 'Fizyoterapi' },
      { id: 'sub_psikolog', name: 'Psikolog' },
      { id: 'sub_veteriner', name: 'Veteriner' },
      { id: 'sub_saglik_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_insaat',
    name: 'İnşaat & Usta',
    slug: 'insaat-ve-usta',
    iconName: 'Hammer',
    subCategories: [
      { 
        id: 'sub_boya', 
        name: 'Boya Badana', 
        fields: [
          { key: 'm2', label: 'Hizmet Alanı (m²)', type: 'number' },
          { key: 'malzeme', label: 'Malzeme Durumu', type: 'select', options: ['Malzeme Dahil (Anahtar Teslim)', 'Sadece İşçilik (Malzeme Benden)'] },
          { key: 'yapi_turu', label: 'Yapı Türü', type: 'select', options: ['Daire / Ev', 'Ofis / İşyeri', 'Bina Geneli', 'Müstakil / Villa', 'İnşaat Şantiyesi'] }
        ]
      },
      { id: 'sub_elektrik', name: 'Elektrik' },
      { id: 'sub_tesisat', name: 'Su Tesisatı' },
      { id: 'sub_fayans', name: 'Fayans' },
      { id: 'sub_cati', name: 'Çatı' },
      { id: 'sub_marangoz', name: 'Marangoz' },
      { id: 'sub_cam_balkon', name: 'Cam Balkon' },
      { id: 'sub_bahce_duzen', name: 'Bahçe Düzenleme' },
      { id: 'sub_temizlik', name: 'Temizlik' },
      { id: 'sub_insaat_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_personel',
    name: 'İş & Personel',
    slug: 'is-ve-personel',
    iconName: 'Briefcase',
    subCategories: [
      { 
        id: 'sub_eleman', 
        name: 'Eleman Arıyorum', 
        fields: [
          { key: 'calisma_modeli', label: 'Çalışma Modeli', type: 'select', options: ['Tam Zamanlı (Full-Time)', 'Yarı Zamanlı (Part-Time)', 'Freelance / Proje', 'Dönemsel / Mevsimlik'] },
          { key: 'egitim', label: 'Eğitim Durumu', type: 'select', options: ['İlkokul/Ortaokul', 'Lise', 'Ön Lisans', 'Lisans / Üniversite Mezunu'] }
        ]
      },
      { id: 'sub_is_arama', name: 'İş Arıyorum' },
      { id: 'sub_muhasebe', name: 'Muhasebe' },
      { id: 'sub_yazilim_p', name: 'Yazılım' },
      { id: 'sub_satis', name: 'Satış' },
      { id: 'sub_sofor', name: 'Şoför', fields: [{ key: 'ehliyet', label: 'Sürücü Belgesi', type: 'select', options: ['A1/A2 (Motosiklet)', 'B Sınıfı', 'C/D (Kamyon/Otobüs)', 'SRC / Psikoteknik Belgeli'] }] },
      { id: 'sub_sekreter', name: 'Sekreter' },
      { id: 'sub_guvenlik_p', name: 'Güvenlik' },
      { id: 'sub_asci', name: 'Aşçı' },
      { id: 'sub_operator', name: 'Operatör' },
      { id: 'sub_personel_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_market',
    name: 'Market & Toptan Tedarik',
    slug: 'market-ve-toptan',
    iconName: 'ClipboardList',
    subCategories: [
      { id: 'sub_toptan_gida', name: 'Toptan Gıda', fields: [{ key: 'hacim', label: 'Alım Hacmi', type: 'select', options: ['Koli Bazlı', 'Palet Bazlı', 'Tır / Kamyon Bazlı', 'Düzenli Tedarik'] }] },
      { id: 'sub_ambalaj_t', name: 'Ambalaj' },
      { id: 'sub_kagit', name: 'Kağıt Ürünleri' },
      { id: 'sub_kuruyemis_t', name: 'Kuruyemiş' },
      { id: 'sub_sarkuteri', name: 'Şarküteri' },
      { id: 'sub_donuk', name: 'Donuk Ürün' },
      { id: 'sub_market_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_restoran',
    name: 'Restoran & Kafe',
    slug: 'restoran-ve-kafe',
    iconName: 'ClipboardList',
    subCategories: [
      { id: 'sub_rest_tedarik', name: 'Restoran Tedarik', fields: [{ key: 'belge', label: 'Ürün Belgesi', type: 'select', options: ['ISO 22000 Belgeli', 'Helal Sertifikalı', 'Tarım Bakanlığı Onaylı', 'Standart Ticari'] }] },
      { id: 'sub_endustriyel_m', name: 'Endüstriyel Mutfak' },
      { id: 'sub_pastane', name: 'Pastane' },
      { id: 'sub_kahve_t', name: 'Kahve' },
      { id: 'sub_fast_food', name: 'Fast Food' },
      { id: 'sub_restoran_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_teknoloji',
    name: 'Yazılım & Teknoloji',
    slug: 'yazilim-ve-teknoloji',
    iconName: 'Laptop',
    subCategories: [
      { 
        id: 'sub_web', 
        name: 'Web Sitesi', 
        fields: [
          { key: 'kapsam', label: 'Proje Kapsamı', type: 'select', options: ['Sıfırdan Özel Tasarım', 'Hazır Altyapı Kurulumu', 'Mevcut Sisteme Destek', 'E-Ticaret Dönüşümü'] },
          { key: 'platform', label: 'Geliştirme Platformu', type: 'select', options: ['React / Next.js', 'PHP / Laravel', 'WordPress', 'Python / Django'] }
        ]
      },
      { id: 'sub_mobil', name: 'Mobil Uygulama', fields: [{ key: 'platform', label: 'Platform', type: 'select', options: ['iOS & Android (Flutter/RN)', 'Native iOS (Swift)', 'Native Android (Kotlin)'] }] },
      { id: 'sub_eticaret', name: 'E-Ticaret' },
      { id: 'sub_ai', name: 'Yapay Zeka' },
      { id: 'sub_grafik', name: 'Grafik Tasarım' },
      { id: 'sub_seo', name: 'SEO' },
      { id: 'sub_siber', name: 'Siber Güvenlik' },
      { id: 'sub_teknik', name: 'Teknik Destek' },
      { id: 'sub_teknoloji_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_egitim',
    name: 'Eğitim & Danışmanlık',
    slug: 'egitim-ve-danismanlik',
    iconName: 'LayoutGrid',
    subCategories: [
      { 
        id: 'sub_ozel_ders', 
        name: 'Özel Ders', 
        fields: [
          { key: 'ders_sekli', label: 'Ders Şekli', type: 'select', options: ['Online (Uzaktan)', 'Yüz Yüze (Öğrenci Evi)', 'Yüz Yüze (Öğretmen Yeri)'] },
          { key: 'kapsam', label: 'Eğitim Kapsamı', type: 'select', options: ['Tek Seferlik Takviye', 'Sınava Hazırlık (LGS/YKS)', 'Düzenli Haftalık Ders'] }
        ]
      },
      { id: 'sub_yabanci_dil', name: 'Yabancı Dil' },
      { id: 'sub_kocluk', name: 'Koçluk' },
      { id: 'sub_finans', name: 'Finans Danışmanlığı' },
      { id: 'sub_hukuk_d', name: 'Hukuk Danışmanlığı' },
      { id: 'sub_egitim_diger', name: 'Diğer' }
    ]
  },
  {
    id: 'cat_diger',
    name: 'Diğer Talepler',
    slug: 'diger-talepler',
    iconName: 'LayoutGrid',
    subCategories: [
      { id: 'sub_genel_talep', name: 'Genel İhtiyaç Talebi', fields: [{ key: 'sure', label: 'İhtiyaç Süresi', type: 'select', options: ['Acil (Hemen)', '1 Hafta İçinde', '1 Ay İçinde', 'Zamanı Fark Etmez'] }] }
    ]
  }
];
