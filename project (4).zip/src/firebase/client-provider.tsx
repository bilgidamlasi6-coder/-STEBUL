'use client';

import React, { useMemo } from 'react';
import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import { firebaseConfig } from './config';
import { FirebaseProvider } from './provider';

// Singleton variables outside the component to persist across hot reloads
let firebaseApp: FirebaseApp | undefined;
let firestoreDb: Firestore | undefined;
let firebaseAuth: Auth | undefined;
let firebaseStorage: FirebaseStorage | undefined;

function initializeServices() {
  if (typeof window === 'undefined') return { app: null, firestore: null, auth: null, storage: null };

  try {
    if (!firebaseApp) {
      const apps = getApps();
      firebaseApp = apps.length > 0 ? apps[0] : initializeApp(firebaseConfig);
    }

    if (!firestoreDb) {
      firestoreDb = getFirestore(firebaseApp);
    }

    if (!firebaseAuth) {
      firebaseAuth = getAuth(firebaseApp);
    }

    if (!firebaseStorage) {
      firebaseStorage = getStorage(firebaseApp);
    }
  } catch (error) {
    console.error("Firebase initialization error:", error);
  }

  return { app: firebaseApp, firestore: firestoreDb, auth: firebaseAuth, storage: firebaseStorage };
}

export const FirebaseClientProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Use useMemo to ensure services are only initialized once on the client
  const services = useMemo(() => initializeServices(), []);

  if (!services.app || !services.firestore || !services.auth || !services.storage) {
    return <>{children}</>;
  }

  return (
    <FirebaseProvider
      firebaseApp={services.app}
      firestore={services.firestore}
      auth={services.auth}
      storage={services.storage}
    >
      {children}
    </FirebaseProvider>
  );
};
