# **App Name**: BULA: Connect & Offer

## Core Features:

- User Account Management: Secure login and profile management for both individual request creators and service-providing businesses.
- Request Creation: Form-based request submission allowing users to specify title, description, budget, location, and category.
- Marketplace Feed: A browsing interface for businesses to find trending and recent requests with built-in search functionality.
- Offer Submission and Management: Enables businesses to send tailored offers to specific requests and allows creators to review all received offers.
- Mobile Bottom Navigation: Quick-access navigation bar providing instant switching between Home, Requests, Create, Offers, and Profile pages.

## Style Guidelines:

- Primary Color: A professional deep blue (#246BB8) for branding and trust.
- Background Color: Pure white (#FFFFFF) for a clean, high-contrast, and modern look.
- Accent Color: Vibrant orange (#F88F17) exclusively for action buttons and primary CTAs.
- Main Font: 'Inter' sans-serif for optimal readability and a sleek, mobile-first aesthetic.
- Clean, modern line icons for standard navigation and filled icons for active states.
- Card-based layout with rounded corners and generous padding to separate content blocks effectively on mobile screens.
- Smooth, subtle page transitions and micro-interactions when interacting with buttons and cards.