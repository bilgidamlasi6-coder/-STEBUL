'use server';
/**
 * @fileOverview Gemini destekli ilan açıklaması oluşturma akışı.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const GenerateDescriptionInputSchema = z.object({
  title: z.string().describe('İlan başlığı'),
});

export async function generateDescription(input: { title: string }): Promise<string> {
  const { text } = await ai.generate({
    model: 'googleai/gemini-2.0-flash',
    prompt: `Sen profesyonel bir hizmet pazaryeri asistanısın. 
    Aşağıdaki başlığa sahip bir hizmet talebi için detaylı, güven verici, profesyonel ve ikna edici bir ilan metni yaz. 
    Başlık: "${input.title}"
    Metin, yapılacak işin detaylarını, beklenen kalite standartlarını ve hizmet verecek kişiden beklentileri içermelidir. 
    Cevabı doğrudan ilan metni olarak ver, giriş veya çıkış cümleleri ekleme.`,
  });
  return text;
}
