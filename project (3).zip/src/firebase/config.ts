/**
 * ISTEBUL Firebase Yapılandırması
 */
export const firebaseConfig = {
  apiKey: "AIzaSyDQdipf9MOfnQ9mzjqDzRHZgDc8dPy2Aks",
  authDomain: "istebul-6c5cf.firebaseapp.com",
  projectId: "istebul-6c5cf",
  storageBucket: "istebul-6c5cf.firebasestorage.app",
  messagingSenderId: "844761483623",
  appId: "1:844761483623:web:5057b6fa6980c87e2847c2",
  measurementId: "G-91NKTCSP6F"
};
