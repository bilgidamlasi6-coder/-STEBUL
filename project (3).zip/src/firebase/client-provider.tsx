'use client';

import React, { useMemo } from 'react';
import { initializeApp, getApps, FirebaseApp, getApp } from 'firebase/app';
import { getFirestore, Firestore } from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { firebaseConfig } from './config';
import { FirebaseProvider } from './provider';

// Singleton variables outside the component to persist across hot reloads
let firebaseApp: FirebaseApp | undefined;
let firestoreDb: Firestore | undefined;
let firebaseAuth: Auth | undefined;

function initializeServices() {
  if (typeof window === 'undefined') return { app: null, firestore: null, auth: null };

  try {
    if (!firebaseApp) {
      const apps = getApps();
      firebaseApp = apps.length > 0 ? apps[0] : initializeApp(firebaseConfig);
    }

    if (!firestoreDb) {
      firestoreDb = getFirestore(firebaseApp);
    }

    if (!firebaseAuth) {
      firebaseAuth = getAuth(firebaseApp);
    }
  } catch (error) {
    console.error("Firebase initialization error:", error);
  }

  return { app: firebaseApp, firestore: firestoreDb, auth: firebaseAuth };
}

export const FirebaseClientProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Use useMemo to ensure services are only initialized once on the client
  const services = useMemo(() => initializeServices(), []);

  if (!services.app || !services.firestore || !services.auth) {
    return <>{children}</>;
  }

  return (
    <FirebaseProvider
      firebaseApp={services.app}
      firestore={services.firestore}
      auth={services.auth}
    >
      {children}
    </FirebaseProvider>
  );
};
