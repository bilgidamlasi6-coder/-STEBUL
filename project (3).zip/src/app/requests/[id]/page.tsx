"use client";

import { useParams, useRouter } from "next/navigation";
import { useState, useEffect, useMemo, Suspense } from "react";
import { 
  ArrowLeft, 
  MapPin, 
  Share2, 
  Loader2,
  Calendar,
  Hash,
  LayoutGrid,
  Info,
  ChevronRight,
  Wallet,
  Handshake,
  MessageSquare,
  X,
  User as UserIcon,
  Shield
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useFirestore } from "@/firebase";
import { doc, collection, onSnapshot } from "firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { AuthPanel } from "@/components/AuthPanel";
import { ProfileCompletionDialog } from "@/components/ProfileCompletionDialog";
import { useToast } from "@/hooks/use-toast";
import { RelativeTime } from "@/components/RelativeTime";

function RequestDetailContent() {
  const { id } = useParams();
  const router = useRouter();
  const db = useFirestore();
  const { user, profile, isProfileComplete } = useAuth();
  const { toast } = useToast();
  
  const [request, setRequest] = useState<any>(null);
  const [offersCount, setOffersCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);

  useEffect(() => {
    if (!db || !id) return;
    
    const unsubReq = onSnapshot(doc(db, "requests", id as string), (snap) => {
      if (snap.exists()) {
        setRequest({ id: snap.id, ...snap.data() });
      }
      setLoading(false);
    });

    const unsubOffers = onSnapshot(collection(db, "requests", id as string, "offers"), (snap) => {
      setOffersCount(snap.size);
    });

    return () => { unsubReq(); unsubOffers(); };
  }, [db, id]);

  const maskedName = useMemo(() => {
    if (!request?.user?.name) return "Kullanıcı";
    const parts = request.user.name.split(' ');
    if (parts.length < 2) return request.user.name;
    return `${parts[0]} ${parts[parts.length - 1].charAt(0)}.`;
  }, [request]);

  const locationParts = useMemo(() => {
    if (!request?.location) return { city: "-", district: "-" };
    const parts = request.location.split('/');
    return { city: parts[0]?.trim() || "-", district: parts[1]?.trim() || "-" };
  }, [request]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>;
  if (!request) return <div className="p-10 text-center font-bold text-slate-400 uppercase text-xs">İlan bulunamadı.</div>;

  return (
    <div className="min-h-screen bg-slate-50 max-w-md mx-auto relative flex flex-col">
      {/* 1. FIXED HEADER */}
      <header className="sticky top-0 z-[60] bg-white border-b border-slate-100 px-6 py-4 shadow-sm shrink-0">
        <div className="flex items-center justify-between gap-4">
          <button onClick={() => router.back()} className="p-2 -ml-2 hover:bg-slate-50 rounded-full transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-900" />
          </button>
          <h1 className="flex-1 text-sm font-black text-slate-900 leading-tight uppercase tracking-tight line-clamp-1">
            {request.title}
          </h1>
          <button className="p-2 -mr-2 hover:bg-slate-50 rounded-full transition-colors">
            <Share2 className="w-5 h-5 text-slate-400" />
          </button>
        </div>
      </header>

      {/* 2. SCROLLABLE AREA */}
      <main className="flex-1 overflow-y-auto pb-40">
        {/* GALLERY */}
        {request.images && request.images.length > 0 && (
          <section className="bg-white border-b border-slate-100 overflow-hidden">
            <div className="flex overflow-x-auto snap-x snap-mandatory scrollbar-none">
              {request.images.map((img: string, idx: number) => (
                <div key={idx} className="relative shrink-0 w-full aspect-[4/3] snap-center cursor-zoom-in" onClick={() => setSelectedImage(img)}>
                  <img src={img} className="w-full h-full object-cover" alt="" />
                  <div className="absolute bottom-4 right-4 bg-black/40 backdrop-blur-md px-3 py-1 rounded-full text-[9px] font-black text-white uppercase border border-white/10">
                    {idx + 1} / {request.images.length}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* TABS & CONTENT */}
        <Tabs defaultValue="info" className="w-full">
          <div className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100">
            <TabsList className="w-full h-14 bg-transparent p-0 rounded-none flex">
              <TabsTrigger value="info" className="flex-1 h-full rounded-none data-[state=active]:bg-white data-[state=active]:border-b-4 data-[state=active]:border-primary data-[state=active]:text-primary font-black text-[10px] uppercase tracking-widest text-slate-400">İlan Bilgileri</TabsTrigger>
              <TabsTrigger value="desc" className="flex-1 h-full rounded-none data-[state=active]:bg-white data-[state=active]:border-b-4 data-[state=active]:border-primary data-[state=active]:text-primary font-black text-[10px] uppercase tracking-widest text-slate-400">Açıklama</TabsTrigger>
              <TabsTrigger value="loc" className="flex-1 h-full rounded-none data-[state=active]:bg-white data-[state=active]:border-b-4 data-[state=active]:border-primary data-[state=active]:text-primary font-black text-[10px] uppercase tracking-widest text-slate-400">Konum</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="info" className="m-0 bg-white">
            <div className="divide-y divide-slate-50">
              <InfoRow icon={Calendar} label="Yayın Tarihi" value={<RelativeTime date={request.createdAt} />} />
              <InfoRow icon={Info} label="İlan Durumu" value={<span className={`font-black uppercase text-[10px] ${request.status === 'active' ? 'text-emerald-500' : 'text-amber-500'}`}>{request.status === 'active' ? 'YAYINDA' : 'PASİF'}</span>} />
              <InfoRow icon={Hash} label="İlan No" value={request.id.slice(0, 8).toUpperCase()} />
              <InfoRow icon={LayoutGrid} label="Kategori" value={request.category || "Genel"} />
              <InfoRow icon={Wallet} label="Bütçe" value={request.budget ? `${request.budget} TL` : "Bütçe Belirtilmemiş"} />
            </div>
            {/* OFFER COUNTER */}
            <div className="px-6 py-6 border-t border-slate-50">
               <div className="bg-slate-50/50 p-4 rounded-2xl flex items-center justify-between">
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center"><MessageSquare className="w-5 h-5 text-primary" /></div>
                   <p className="text-xs font-black text-slate-700 uppercase tracking-tight">Gelen Teklif Sayısı</p>
                 </div>
                 <span className="text-xl font-black text-primary">{offersCount}</span>
               </div>
            </div>
          </TabsContent>

          <TabsContent value="desc" className="m-0 bg-white px-6 py-8 min-h-[300px]">
            <p className="text-[14px] text-slate-600 font-medium leading-relaxed whitespace-pre-wrap tracking-tight">
              {request.description}
            </p>
          </TabsContent>

          <TabsContent value="loc" className="m-0 bg-white p-8 text-center min-h-[300px]">
            <div className="bg-slate-50/50 p-10 rounded-[3rem] border-2 border-dashed border-slate-100">
              <div className="w-16 h-16 bg-primary/10 rounded-[2rem] flex items-center justify-center mx-auto mb-6"><MapPin className="w-8 h-8 text-primary" /></div>
              <div className="space-y-1">
                <p className="text-xl font-black text-slate-900 uppercase tracking-tight">{locationParts.city}</p>
                <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">{locationParts.district}</p>
              </div>
              <div className="mt-8 pt-8 border-t border-slate-200/50">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{request.location}</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* FOOTER PROFILE CARD */}
        <section className="px-6 py-12">
          <div 
            onClick={() => router.push(`/profile?uid=${request.userId}`)}
            className="flex items-center justify-between p-5 bg-white border border-slate-100 rounded-[2.5rem] shadow-sm active:scale-[0.98] transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 relative">
                <img src={request.user?.avatar || "https://picsum.photos/seed/istanbul-user/100/100"} className="w-full h-full object-cover rounded-2xl border border-slate-100" alt="" />
                <div className="absolute -bottom-1 -right-1 bg-primary w-5 h-5 rounded-full border-2 border-white flex items-center justify-center"><Shield className="w-2.5 h-2.5 text-white" /></div>
              </div>
              <div>
                <p className="text-sm font-black text-slate-900 uppercase leading-none group-hover:text-primary transition-colors">{maskedName}</p>
                <div className="flex items-center gap-1.5 mt-1.5 text-[9px] font-bold text-slate-300 uppercase tracking-widest">
                   <span>ÜYE</span>
                   <span>•</span>
                   <RelativeTime date={request.user?.createdAt || request.createdAt} />
                </div>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-primary transition-colors" />
          </div>
        </section>
      </main>

      {/* 3. FIXED COMPACT FOOTER ACTION */}
      {request.status === 'active' && (
        <div className="fixed bottom-20 left-0 right-0 p-4 bg-white/80 backdrop-blur-xl border-t border-slate-100 z-[100] max-w-md mx-auto shadow-2xl">
          <Button 
            onClick={() => { if (!user) setIsAuthPanelOpen(true); else if (!isProfileComplete()) setIsProfileDialogOpen(true); else { toast({ title: "Hazırlanıyor", description: "Teklif verme özelliği yakında aktif!" }); } }} 
            className="w-full bg-primary hover:bg-primary/90 text-white font-black h-14 rounded-2xl uppercase text-[11px] tracking-[0.2em] border-none shadow-xl shadow-primary/20 transition-all flex items-center justify-center gap-3"
          >
            <Handshake className="w-4 h-4" />
            HEMEN TEKLİF VER
          </Button>
        </div>
      )}

      {/* LIGHTBOX */}
      <Dialog open={!!selectedImage} onOpenChange={(open) => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-[95vw] h-fit p-0 border-none bg-transparent shadow-none">
          {selectedImage && (
            <div className="relative w-full h-full flex items-center justify-center animate-in zoom-in-95 duration-200">
              <img src={selectedImage} className="max-w-full max-h-[85vh] object-contain rounded-[2rem] shadow-2xl" alt="Preview" />
              <button onClick={() => setSelectedImage(null)} className="absolute top-4 right-4 bg-white/20 backdrop-blur-xl p-3 rounded-full text-white border border-white/20"><X className="w-5 h-5" /></button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
      <ProfileCompletionDialog isOpen={isProfileDialogOpen} onClose={() => setIsProfileDialogOpen(false)} />
    </div>
  );
}

function InfoRow({ icon: Icon, label, value }: { icon: any, label: string, value: any }) {
  return (
    <div className="flex items-center justify-between px-6 py-5 hover:bg-slate-50/50 transition-colors">
      <div className="flex items-center gap-3.5">
        <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100 shadow-sm"><Icon className="w-4 h-4 text-slate-400" /></div>
        <span className="text-[11px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
      </div>
      <div className="text-[11px] font-black text-slate-900 uppercase tracking-tight">{value}</div>
    </div>
  );
}

export default function RequestDetail() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary w-8 h-8" /></div>}><RequestDetailContent /></Suspense>;
}
