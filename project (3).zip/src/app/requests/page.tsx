
"use client";

import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useMemo, useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  SlidersHorizontal, 
  ArrowLeft, 
  Loader2, 
  Trash2,
  PauseCircle,
  PlayCircle,
  Edit3,
  ExternalLink
} from "lucide-react";
import { RequestCard } from "@/components/RequestCard";
import { type Request } from "@/lib/sample-data";
import { Button } from "@/components/ui/button";
import { useFirestore } from "@/firebase";
import { collection, query, orderBy, onSnapshot, where, doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";

function RequestsList() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const db = useFirestore();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const categoryFilter = searchParams.get("category");
  const userIdFilter = searchParams.get("userId");
  
  const [firestoreRequests, setFirestoreRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState<string | null>(null);

  const baseQuery = useMemo(() => {
    if (!db) return null;
    
    if (userIdFilter) {
      return query(
        collection(db, "requests"), 
        where("userId", "==", userIdFilter),
        where("status", "!=", "deleted"),
        orderBy("status", "asc"),
        orderBy("createdAt", "desc")
      );
    }
    
    return query(
      collection(db, "requests"), 
      where("status", "==", "active"),
      orderBy("createdAt", "desc")
    );
  }, [db, userIdFilter]);

  useEffect(() => {
    if (!baseQuery) return;
    
    const unsubscribe = onSnapshot(baseQuery, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Request[];
      setFirestoreRequests(fetched);
      setLoading(false);
      setError(null);
    }, (err) => {
      console.error("Firestore error:", err);
      setLoading(false);
      if (err.code === 'failed-precondition') {
        setError("Lütfen Firebase Console üzerinden gerekli Index (Dizin) oluşturun.");
      } else {
        setError("Talepler alınırken bir hata oluştu.");
      }
    });

    return () => unsubscribe();
  }, [baseQuery]);

  const handleUpdateStatus = async (id: string, status: string) => {
    if (!db) return;
    try {
      const requestRef = doc(db, "requests", id);
      await updateDoc(requestRef, { 
        status, 
        updatedAt: serverTimestamp() 
      });
      toast({ title: "Başarılı", description: `İlan durumu '${status}' olarak güncellendi.` });
    } catch (e) {
      toast({ variant: "destructive", title: "Hata", description: "İşlem başarısız." });
    }
  };

  const filteredRequests = useMemo(() => {
    let result = firestoreRequests;
    
    if (categoryFilter) {
      result = result.filter(
        (req) => req.category?.toLowerCase() === categoryFilter.toLowerCase()
      );
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (req) => 
          req.title.toLowerCase().includes(term) || 
          (req.category && req.category.toLowerCase().includes(term)) ||
          (req.location && req.location.toLowerCase().includes(term))
      );
    }

    return result;
  }, [categoryFilter, firestoreRequests, searchTerm]);

  const headerTitle = useMemo(() => {
    if (userIdFilter) return "İlanlar";
    return categoryFilter ? categoryFilter : "Buluşma Noktası";
  }, [categoryFilter, userIdFilter]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-6 pt-4 pb-2 border-b border-slate-50">
        <div className="flex items-center gap-3 mb-3">
          <button onClick={() => router.back()} className="p-1.5 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </button>
          <div>
            <h1 className="text-lg font-black text-slate-900 tracking-tight leading-none uppercase">{headerTitle}</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">
              {userIdFilter ? "YAYINLANAN TALEPLER" : "GÜNCEL İŞ FIRSATLARI"}
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5" />
            <Input 
              placeholder="Talep veya hizmet ara..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 h-10 bg-slate-50 border-none rounded-xl focus-visible:ring-primary text-xs font-medium"
            />
          </div>
          <Button variant="outline" size="icon" className="h-10 w-10 rounded-xl bg-slate-50 border-none">
            <SlidersHorizontal className="w-4 h-4 text-slate-600" />
          </Button>
        </div>
      </header>

      <div className="px-6 py-4 space-y-4 pb-24">
        {filteredRequests.length > 0 ? (
          filteredRequests.map(request => {
            const isOwner = user?.uid === request.userId;
            return (
              <div key={request.id} className="relative group">
                <RequestCard request={request} />
                {isOwner && (
                  <div className="absolute top-2 right-2 z-[60] flex items-center gap-1.5 bg-white/90 backdrop-blur-sm p-1 rounded-2xl shadow-sm border border-slate-100 pointer-events-auto">
                    <button 
                      type="button"
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); router.push(`/requests/${request.id}`); }}
                      className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-blue-500"
                      title="Görüntüle"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      type="button"
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); router.push(`/requests/${request.id}?edit=true`); }}
                      className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-slate-600"
                      title="Düzenle"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    {request.status === 'active' ? (
                      <button 
                        type="button"
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleUpdateStatus(request.id, 'inactive'); }}
                        className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-amber-500"
                        title="Yayından Kaldır"
                      >
                        <PauseCircle className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <button 
                        type="button"
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleUpdateStatus(request.id, 'active'); }}
                        className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors text-emerald-500"
                        title="Yayınla"
                      >
                        <PlayCircle className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button 
                      type="button"
                      onClick={(e) => { 
                        e.preventDefault(); 
                        e.stopPropagation(); 
                        handleUpdateStatus(request.id, 'deleted'); 
                      }}
                      className="p-1.5 hover:bg-red-50 rounded-lg transition-colors text-red-500 active:scale-95"
                      title="Kalıcı Sil"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-20 text-center bg-white rounded-[2.5rem] border border-dashed border-slate-100">
            {error ? (
              <div className="p-6">
                 <p className="text-amber-600 font-bold text-xs uppercase mb-2">Hata Oluştu</p>
                 <p className="text-slate-400 text-[10px] leading-relaxed">{error}</p>
              </div>
            ) : (
              <p className="text-slate-400 font-black uppercase text-[10px]">İlan bulunamadı.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default function RequestsMarketplace() {
  return (
    <Suspense fallback={<div className="p-10 text-center font-bold text-slate-400">Yükleniyor...</div>}>
      <RequestsList />
    </Suspense>
  );
}
