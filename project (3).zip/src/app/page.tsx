
"use client";

import { useState, useEffect, useMemo } from "react";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Sparkles, 
  ChevronRight,
  MessageSquare,
  Bell,
  LayoutGrid,
  AlertCircle
} from "lucide-react";
import { RequestCard } from "@/components/RequestCard";
import { type Request } from "@/lib/sample-data";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";
import { useFirestore } from "@/firebase";
import { collection, query, orderBy, limit, onSnapshot, where } from "firebase/firestore";

export default function Home() {
  const router = useRouter();
  const db = useFirestore();
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState<string | null>(null);

  const requestsQuery = useMemo(() => {
    if (!db) return null;
    return query(
      collection(db, "requests"), 
      where("status", "==", "active"),
      orderBy("createdAt", "desc"), 
      limit(20)
    );
  }, [db]);

  useEffect(() => {
    if (!requestsQuery) return;
    
    const timeoutId = setTimeout(() => {
      if (loading) {
        setLoading(false);
        setError("Talepler yüklenirken zaman aşımı oluştu.");
      }
    }, 10000);

    const unsubscribe = onSnapshot(
      requestsQuery, 
      (snapshot) => {
        const fetched = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        } as Request));
        setRequests(fetched);
        setLoading(false);
        setError(null);
        clearTimeout(timeoutId);
      },
      (err) => {
        // DIAGNOSTIC LOG: Ana sayfa sorgu hatası
        console.error("[DIAGNOSTIC] Error in src/app/page.tsx (Home Query):", err);
        setLoading(false);
        if (err.code === 'failed-precondition') {
          setError("Veritabanı yapılandırması bekleniyor (Index)... Lütfen konsolu kontrol edin.");
        } else {
          setError("Talepler şu an alınamıyor.");
        }
        clearTimeout(timeoutId);
      }
    );

    return () => {
      unsubscribe();
      clearTimeout(timeoutId);
    };
  }, [requestsQuery]);

  const filteredRequests = useMemo(() => {
    if (!searchTerm) return requests;
    const term = searchTerm.toLowerCase();
    return requests.filter(r => 
      r.title.toLowerCase().includes(term) || 
      (r.category && r.category.toLowerCase().includes(term)) ||
      (r.location && r.location.toLowerCase().includes(term))
    );
  }, [requests, searchTerm]);

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-50">
        <div className="px-6 pt-4 pb-2">
          <div className="flex items-center justify-between mb-3 relative">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => router.push('/categories')}
              className="h-8 w-8 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors absolute left-0"
            >
              <LayoutGrid className="w-4 h-4" />
            </Button>

            <div className="flex items-center justify-center gap-1.5 flex-1">
              <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center shadow-md shadow-primary/10">
                <span className="text-white font-black text-xs italic">İ</span>
              </div>
              <h1 className="text-lg font-black text-slate-900 tracking-tighter uppercase">İSTEBUL</h1>
            </div>
          </div>
          
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-3.5 h-3.5 z-10" />
            <Input 
              placeholder="İhtiyacın olan her şey için..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-24 h-10 bg-slate-50/50 border-none shadow-none rounded-xl focus-visible:ring-primary text-[11px] font-medium w-full"
            />
            <div className="absolute right-1 top-1/2 -translate-y-1/2 flex items-center gap-0.5">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => router.push('/chats')}
                className="h-8 w-8 rounded-lg text-slate-400 hover:text-primary transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-lg text-slate-400 relative">
                <Bell className="w-4 h-4" />
                <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-red-500 rounded-full border border-white"></span>
              </Button>
            </div>
          </div>
        </div>

        <div className="px-6 py-2 bg-white/50 border-t border-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-primary animate-pulse" />
            <h2 className="text-[11px] font-black text-slate-900 uppercase tracking-tight">Güncel Talepler</h2>
          </div>
          <Link href="/requests" className="text-[9px] font-black text-primary uppercase tracking-widest bg-primary/5 px-2.5 py-1 rounded-full">Tümü</Link>
        </div>
      </header>

      <div className="px-6 py-4 space-y-3 pb-24">
        {loading ? (
          <div className="py-20 text-center text-slate-300 font-bold uppercase tracking-widest text-[10px]">Talepler Yükleniyor...</div>
        ) : error ? (
          <div className="py-12 text-center bg-slate-50 rounded-[2.5rem] border border-dashed border-slate-200">
            <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-3" />
            <p className="text-slate-500 font-bold text-xs px-10">{error}</p>
            <Button 
              variant="ghost" 
              onClick={() => window.location.reload()} 
              className="mt-4 text-primary font-black text-[10px] uppercase"
            >
              Tekrar Dene
            </Button>
          </div>
        ) : filteredRequests.length > 0 ? (
          filteredRequests.map(request => (
            <RequestCard key={request.id} request={request} />
          ))
        ) : (
          <div className="py-20 text-center bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-100">
            <p className="text-slate-400 font-black uppercase tracking-widest text-[9px]">Henüz talep bulunmuyor.</p>
          </div>
        )}

        {requests.length > 0 && !error && (
          <Link href="/requests" className="block mt-4">
            <Button variant="outline" className="w-full h-11 rounded-2xl border-slate-100 font-bold text-slate-400 hover:text-primary hover:border-primary hover:bg-primary/5 transition-all text-[10px] uppercase">
              Daha Fazla İlan Gör
              <ChevronRight className="w-3 h-3 ml-1" />
            </Button>
          </Link>
        )}
      </div>
    </div>
  );
}
