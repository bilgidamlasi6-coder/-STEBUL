
"use client";

import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Handshake, ChevronRight, Loader2, ArrowLeft, CheckCircle2, MessageSquare, AlertCircle, Trash2 } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collectionGroup, query, where, onSnapshot, orderBy, deleteDoc, doc, updateDoc, increment } from "firebase/firestore";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { RelativeTime } from "@/components/RelativeTime";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function OffersPage() {
  const { user } = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  const [sentOffers, setSentOffers] = useState<any[]>([]);
  const [receivedOffers, setReceivedOffers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const sentOffersQuery = useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(collectionGroup(db, "offers"), where("businessId", "==", user.uid), orderBy("createdAt", "desc"));
  }, [db, user?.uid]);

  const receivedOffersQuery = useMemo(() => {
    if (!db || !user?.uid) return null;
    return query(collectionGroup(db, "offers"), where("requestUserId", "==", user.uid), orderBy("createdAt", "desc"));
  }, [db, user?.uid]);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    const timeoutId = setTimeout(() => { if (loading) { setLoading(false); setError("Zaman aşımı"); } }, 8000);

    let unsubSent: any;
    let unsubReceived: any;

    if (sentOffersQuery) {
      unsubSent = onSnapshot(sentOffersQuery, (snap) => {
        setSentOffers(snap.docs.map(d => ({ id: d.id, requestId: d.ref.parent.parent?.id, ...d.data() })));
        setLoading(false); setError(null);
      }, (err) => { setLoading(false); setError("Hata oluştu"); });
    }

    if (receivedOffersQuery) {
      unsubReceived = onSnapshot(receivedOffersQuery, (snap) => {
        setReceivedOffers(snap.docs.map(d => ({ id: d.id, requestId: d.ref.parent.parent?.id, ...d.data() })));
        setLoading(false);
      }, (err) => { setLoading(false); });
    }

    return () => { clearTimeout(timeoutId); if (unsubSent) unsubSent(); if (unsubReceived) unsubReceived(); };
  }, [sentOffersQuery, receivedOffersQuery, user, loading]);

  if (loading) return <div className="flex items-center justify-center min-h-screen bg-white"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <Tabs defaultValue="received" className="w-full">
        <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-6 pt-4 pb-2 border-b border-slate-50">
          <div className="flex items-center gap-3 mb-3">
             <button onClick={() => router.back()} className="p-1.5 bg-slate-50 rounded-lg"><ArrowLeft className="w-4 h-4 text-slate-600" /></button>
             <div>
               <h1 className="text-lg font-black text-slate-900 tracking-tight uppercase">Tekliflerim</h1>
               <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">İş Yönetim Merkezi</p>
             </div>
          </div>
          <TabsList className="w-full h-10 bg-slate-50 p-1 rounded-xl">
            <TabsTrigger value="received" className="flex-1 rounded-lg font-black text-[10px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">Gelenler</TabsTrigger>
            <TabsTrigger value="sent" className="flex-1 rounded-lg font-black text-[10px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">Gidenler</TabsTrigger>
          </TabsList>
        </header>

        <div className="px-6 py-4 pb-24">
          <TabsContent value="sent" className="space-y-3 m-0">
            {sentOffers.map((offer) => (
              <Card key={offer.id} className={`border-none shadow-sm rounded-2xl overflow-hidden ${offer.status === 'accepted' ? 'ring-2 ring-primary bg-primary/5' : 'bg-white border border-slate-100'}`}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div className="bg-primary/5 px-2.5 py-1 rounded-lg"><span className="text-[11px] font-black text-primary">{offer.amount}</span></div>
                    <div className="text-[8px] font-bold text-slate-300 uppercase"><RelativeTime date={offer.createdAt} /></div>
                  </div>
                  <Link href={`/requests/${offer.requestId}`} className="text-xs text-slate-700 font-black mb-1 line-clamp-1 hover:text-primary uppercase">{offer.requestTitle || "Talebe Git"}</Link>
                  <div className="mt-3">
                    {offer.status === 'accepted' ? (
                      <Link href={`/chats/${offer.requestId}_${user?.uid}`}>
                        <Button size="sm" className="w-full h-8 text-[9px] font-black bg-primary text-white rounded-xl border-none">SOHBETİ AÇ</Button>
                      </Link>
                    ) : <span className="text-[8px] font-black text-slate-400 uppercase">TEKLİF BEKLENİYOR</span>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="received" className="space-y-3 m-0">
            {receivedOffers.map((offer) => (
              <Card key={offer.id} className={`border-none shadow-sm rounded-2xl overflow-hidden ${offer.status === 'accepted' ? 'ring-2 ring-primary bg-primary/5' : 'bg-white border border-slate-100'}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <Link href={`/profile?uid=${offer.businessId}`} className="flex items-center group">
                      <img src={offer.businessAvatar} className="w-8 h-8 rounded-lg mr-2 object-cover border border-slate-100 group-hover:ring-2 group-hover:ring-primary/20 transition-all" alt="" />
                      <p className="text-[11px] font-black text-slate-900 group-hover:text-primary transition-colors">{offer.businessName}</p>
                    </Link>
                    <div className="bg-primary px-3 py-1 rounded-lg text-white font-black text-xs">{offer.amount}</div>
                  </div>
                  <Link href={`/requests/${offer.requestId}`} className="block bg-slate-50 p-2.5 rounded-xl text-[10px] font-black text-slate-600 uppercase mb-3 text-center">TALEBİ GÖRÜNTÜLE</Link>
                  {offer.status === 'accepted' && (
                    <Link href={`/chats/${offer.requestId}_${offer.businessId}`}>
                      <Button size="sm" className="w-full h-8 text-[9px] font-black bg-primary text-white rounded-xl border-none">SOHBETİ AÇ</Button>
                    </Link>
                  )}
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
