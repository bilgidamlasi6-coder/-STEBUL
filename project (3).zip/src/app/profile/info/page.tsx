
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Camera, Save, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { doc, updateDoc } from "firebase/firestore";

export default function PersonalInfoPage() {
  const router = useRouter();
  const db = useFirestore();
  const { toast } = useToast();
  const { profile, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    isim: "",
    soyadı: "",
    telefon: "",
    şehir: "",
    bio: ""
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        isim: profile.isim || "",
        soyadı: profile.soyadı || "",
        telefon: profile.telefon || "",
        şehir: profile.şehir || "",
        bio: (profile as any).bio || ""
      });
    }
  }, [profile]);

  const handleSave = async () => {
    if (!profile || !db) return;
    
    setLoading(true);
    try {
      const userRef = doc(db, "kullanıcılar", profile.uid);
      await updateDoc(userRef, formData);
      toast({
        title: "Başarılı",
        description: "Bilgileriniz güncellendi.",
      });
      router.back();
    } catch (error) {
      console.error("Update Error:", error);
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Bilgiler güncellenirken bir sorun oluştu.",
      });
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Kişisel Bilgiler</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">PROFİL DÜZENLEME</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-6 pb-24">
        <div className="flex flex-col items-center">
          <div className="relative">
            <img 
              src={profile?.avatar || "https://picsum.photos/seed/istanbul-user/160/160"} 
              className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md" 
              alt="Profil" 
            />
            <button className="absolute bottom-0 right-0 bg-primary p-2 rounded-full text-white shadow-lg border-2 border-white">
              <Camera className="w-4 h-4" />
            </button>
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-3">Fotoğrafı Değiştir</p>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">AD</Label>
              <Input 
                value={formData.isim} 
                onChange={(e) => setFormData({...formData, isim: e.target.value})}
                className="rounded-2xl bg-white border-slate-100 font-bold h-12"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">SOYAD</Label>
              <Input 
                value={formData.soyadı} 
                onChange={(e) => setFormData({...formData, soyadı: e.target.value})}
                className="rounded-2xl bg-white border-slate-100 font-bold h-12"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">TELEFON</Label>
              <Input 
                value={formData.telefon} 
                onChange={(e) => setFormData({...formData, telefon: e.target.value})}
                className="rounded-2xl bg-white border-slate-100 font-bold h-12"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">ŞEHİR</Label>
              <Input 
                value={formData.şehir} 
                onChange={(e) => setFormData({...formData, şehir: e.target.value})}
                className="rounded-2xl bg-white border-slate-100 font-bold h-12"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">E-POSTA</Label>
            <Input 
              value={profile?.["e-posta"] || ""} 
              disabled
              className="rounded-2xl bg-slate-50 border-slate-100 font-bold h-12 text-slate-400"
            />
          </div>

          <div className="space-y-1.5">
            <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">HAKKIMDA</Label>
            <Textarea 
              value={formData.bio} 
              onChange={(e) => setFormData({...formData, bio: e.target.value})}
              placeholder="Kendinden bahset..."
              className="rounded-2xl bg-white border-slate-100 font-medium min-h-[100px] p-4"
            />
          </div>
        </div>

        <Button 
          onClick={handleSave}
          disabled={loading}
          className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin" /> Kaydediliyor...
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Save className="w-5 h-5" /> Değişiklikleri Kaydet
            </span>
          )}
        </Button>
      </div>
    </div>
  );
}
