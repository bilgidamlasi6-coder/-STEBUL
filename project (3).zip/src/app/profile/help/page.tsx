"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, HelpCircle, MessageCircle, Phone, FileText, ChevronRight } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export default function HelpPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Yardım & Destek</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">SİZE NASIL YARDIMCI OLABİLİRİZ?</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-8 pb-24">
        {/* QUICK ACTIONS */}
        <div className="grid grid-cols-2 gap-4">
          <SupportCard icon={MessageCircle} title="Destek Talebi" desc="Form Oluştur" />
          <SupportCard icon={Phone} title="Bizi Arayın" desc="0850 123 45 67" />
        </div>

        {/* FAQ */}
        <div className="space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest px-2">Sık Sorulan Sorular</h3>
          <Accordion type="single" collapsible className="space-y-3">
            <FaqItem value="item-1" question="Nasıl talep oluşturabilirim?" answer="Ana sayfadaki 'Talep Oluştur' butonuna basarak kategorinizi seçebilir ve ihtiyacınızı detaylandırabilirsiniz." />
            <FaqItem value="item-2" question="Teklifleri nasıl değerlendiririm?" answer="Gelen teklifleri 'Teklifler' sayfasından inceleyebilir, işletme ile sohbet başlatabilirsiniz." />
            <FaqItem value="item-3" question="Ödeme sistemi güvenli mi?" answer="İSTEBUL, iyzico altyapısı ile %100 güvenli ödeme ve koruma sağlar." />
          </Accordion>
        </div>

        {/* DOCUMENTS */}
        <div className="space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest px-2">Dokümanlar</h3>
          <div className="bg-white rounded-[1.5rem] border border-slate-100 overflow-hidden shadow-sm">
            <DocLink title="Kullanım Koşulları" />
            <div className="h-px bg-slate-50 mx-4" />
            <DocLink title="Gizlilik Politikası" />
            <div className="h-px bg-slate-50 mx-4" />
            <DocLink title="İptal ve İade Koşulları" />
          </div>
        </div>
      </div>
    </div>
  );
}

function SupportCard({ icon: Icon, title, desc }: any) {
  return (
    <button className="bg-white p-6 rounded-[2rem] border border-slate-100 text-center space-y-2 shadow-sm hover:border-primary transition-all active:scale-95">
      <div className="bg-primary/5 w-12 h-12 rounded-2xl flex items-center justify-center mx-auto">
        <Icon className="w-6 h-6 text-primary" />
      </div>
      <h4 className="text-sm font-black text-slate-900">{title}</h4>
      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">{desc}</p>
    </button>
  );
}

function FaqItem({ value, question, answer }: any) {
  return (
    <AccordionItem value={value} className="bg-white border border-slate-100 rounded-[1.5rem] px-5 overflow-hidden shadow-sm">
      <AccordionTrigger className="text-sm font-black text-slate-700 hover:no-underline py-4">{question}</AccordionTrigger>
      <AccordionContent className="text-xs text-slate-500 font-medium leading-relaxed pb-4">{answer}</AccordionContent>
    </AccordionItem>
  );
}

function DocLink({ title }: any) {
  return (
    <button className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors">
      <div className="flex items-center gap-3">
        <FileText className="w-4 h-4 text-slate-400" />
        <span className="text-xs font-bold text-slate-700">{title}</span>
      </div>
      <ChevronRight className="w-3 h-3 text-slate-300" />
    </button>
  );
}
