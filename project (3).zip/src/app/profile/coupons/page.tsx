"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Ticket, AlertCircle } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function CouponsPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Kuponlarım</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">İNDİRİM VE AVANTAJLAR</p>
          </div>
        </div>
      </header>

      <Tabs defaultValue="active" className="w-full">
        <div className="px-6 pt-6">
          <TabsList className="w-full h-12 bg-white p-1 rounded-2xl shadow-sm border border-slate-100">
            <TabsTrigger value="active" className="flex-1 rounded-xl font-black text-xs data-[state=active]:bg-primary data-[state=active]:text-white">Aktif</TabsTrigger>
            <TabsTrigger value="used" className="flex-1 rounded-xl font-black text-xs data-[state=active]:bg-primary data-[state=active]:text-white">Kullanılmış</TabsTrigger>
            <TabsTrigger value="expired" className="flex-1 rounded-xl font-black text-xs data-[state=active]:bg-primary data-[state=active]:text-white">Geçmiş</TabsTrigger>
          </TabsList>
        </div>

        <div className="px-6 py-16">
          <TabsContent value="active" className="m-0 text-center space-y-4">
            <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-sm border border-slate-50">
              <Ticket className="w-10 h-10 text-slate-300" />
            </div>
            <p className="text-slate-500 font-black uppercase text-[10px] tracking-widest">Aktif kuponunuz bulunmuyor.</p>
          </TabsContent>
          <TabsContent value="used" className="m-0 text-center space-y-4">
             <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-sm border border-slate-50">
              <AlertCircle className="w-10 h-10 text-slate-300" />
            </div>
            <p className="text-slate-500 font-black uppercase text-[10px] tracking-widest">Kullanılmış kupon bulunmuyor.</p>
          </TabsContent>
          <TabsContent value="expired" className="m-0 text-center space-y-4">
             <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-sm border border-slate-50">
              <AlertCircle className="w-10 h-10 text-slate-300" />
            </div>
            <p className="text-slate-500 font-black uppercase text-[10px] tracking-widest">Süresi dolmuş kupon bulunmuyor.</p>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
