"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Bell, Mail, Smartphone, Save } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function NotificationsPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    app: true,
    email: false,
    sms: true
  });

  const handleSave = () => {
    toast({
      title: "Ayarlar Kaydedildi",
      description: "Bildirim tercihleriniz güncellendi.",
    });
    router.back();
  };

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Bildirim Ayarları</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">TERCİHLERİNİZ</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-4">
        <NotificationToggle 
          icon={Bell} 
          label="Uygulama Bildirimleri" 
          description="Yeni teklif ve mesaj geldiğinde anlık bildirim al."
          checked={settings.app}
          onChange={(val) => setSettings({...settings, app: val})}
        />
        <NotificationToggle 
          icon={Mail} 
          label="E-Posta Bildirimleri" 
          description="Önemli güncellemeleri e-posta ile al."
          checked={settings.email}
          onChange={(val) => setSettings({...settings, email: val})}
        />
        <NotificationToggle 
          icon={Smartphone} 
          label="SMS Bildirimleri" 
          description="Önemli işlemler hakkında SMS ile bilgilendiril."
          checked={settings.sms}
          onChange={(val) => setSettings({...settings, sms: val})}
        />

        <div className="pt-6">
          <Button 
            onClick={handleSave}
            className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20"
          >
            <Save className="w-5 h-5 mr-2" /> Ayarları Kaydet
          </Button>
        </div>
      </div>
    </div>
  );
}

function NotificationToggle({ icon: Icon, label, description, checked, onChange }: any) {
  return (
    <div className="bg-white p-5 rounded-[1.5rem] border border-slate-100 flex items-center justify-between shadow-sm">
      <div className="flex items-start gap-4 pr-4">
        <div className="bg-slate-50 p-2.5 rounded-xl mt-0.5">
          <Icon className="w-5 h-5 text-slate-500" />
        </div>
        <div>
          <h3 className="text-sm font-black text-slate-900">{label}</h3>
          <p className="text-[10px] text-slate-400 font-medium leading-relaxed">{description}</p>
        </div>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}
