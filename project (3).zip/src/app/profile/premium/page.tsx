"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Star, CheckCircle2, Zap, Shield, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PremiumPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Premium Üyelik</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">AYRICALIKLI DENEYİM</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-6 pb-24">
        {/* ACTIVE PLAN CARD */}
        <div className="bg-gradient-to-br from-primary to-emerald-700 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-primary/30 relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <Crown className="w-6 h-6 text-yellow-400 fill-yellow-400" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em]">AKTİF PAKET</span>
            </div>
            <h2 className="text-3xl font-black mb-6">PREMIUM PRO</h2>
            <div className="space-y-2 opacity-90">
              <div className="flex justify-between text-[11px] font-bold">
                <span>BAŞLANGIÇ</span>
                <span>12 Ocak 2026</span>
              </div>
              <div className="flex justify-between text-[11px] font-bold text-yellow-200">
                <span>YENİLENME</span>
                <span>12 Ocak 2027</span>
              </div>
            </div>
          </div>
          <Star className="absolute -right-4 -bottom-4 w-40 h-40 opacity-10 rotate-12" />
        </div>

        {/* ADVANTAGES */}
        <div className="space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest px-2">Avantajlarınız</h3>
          <div className="grid grid-cols-1 gap-3">
            <AdvantageItem icon={Zap} title="Öncelikli Talepler" desc="Talepleriniz en üstte listelenir." />
            <AdvantageItem icon={Shield} title="Güven Rozeti" desc="Profilinizde Premium rozeti gösterilir." />
            <AdvantageItem icon={Crown} title="Sınırsız Teklif" desc="Aylık teklif verme limitiniz kaldırılır." />
            <AdvantageItem icon={Star} title="Özel Destek" desc="7/24 öncelikli müşteri desteği." />
          </div>
        </div>

        <Button className="w-full bg-white text-primary border-2 border-primary hover:bg-primary/5 h-14 rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg">
          Üyeliği Yönet
        </Button>
      </div>
    </div>
  );
}

function AdvantageItem({ icon: Icon, title, desc }: any) {
  return (
    <div className="bg-white p-5 rounded-[1.5rem] border border-slate-100 flex items-center gap-4 shadow-sm">
      <div className="bg-primary/5 p-3 rounded-2xl">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <div>
        <h4 className="text-sm font-black text-slate-900 leading-none">{title}</h4>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1.5">{desc}</p>
      </div>
      <CheckCircle2 className="w-5 h-5 text-emerald-500 ml-auto opacity-50" />
    </div>
  );
}
