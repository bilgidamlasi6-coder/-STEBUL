
"use client";

import { useState, useMemo, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Search, MapPin, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { getDistricts } from "@/lib/turkey-data";

function SelectDistrictContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [searchTerm, setSearchTerm] = useState("");
  
  const mode = searchParams.get("mode");
  const id = searchParams.get("id");
  const province = searchParams.get("province") || "";

  const districts = useMemo(() => getDistricts(province), [province]);

  const filteredDistricts = districts.filter(d => 
    d.toLocaleLowerCase("tr").includes(searchTerm.toLocaleLowerCase("tr"))
  );

  const handleSelect = (district: string) => {
    // Determine the base URL and proper query separator
    const isEdit = mode === "edit";
    const baseUrl = isEdit ? `/profile/addresses/edit?id=${id}` : "/profile/addresses/new";
    const separator = baseUrl.includes("?") ? "&" : "?";
    
    router.push(`${baseUrl}${separator}province=${encodeURIComponent(province)}&district=${encodeURIComponent(district)}`);
  };

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden max-w-md mx-auto">
      <header className="flex-shrink-0 bg-white px-6 pt-8 pb-4 border-b border-slate-100 z-10">
        <div className="flex items-center gap-4 mb-5">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">{province} - İlçe Seç</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">KONUM BELİRLEME</p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input 
            placeholder="İlçe Ara..." 
            className="pl-11 h-12 bg-slate-50 border-none rounded-2xl font-bold focus-visible:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2">
        {filteredDistricts.map((district) => (
          <button
            key={district}
            onClick={() => handleSelect(district)}
            className="w-full flex items-center justify-between p-4 bg-white border border-slate-50 rounded-2xl hover:bg-slate-50 transition-all active:scale-[0.98] group"
          >
            <div className="flex items-center gap-3">
              <div className="bg-slate-50 p-2 rounded-xl group-hover:bg-primary/10 transition-colors">
                <MapPin className="w-4 h-4 text-slate-400 group-hover:text-primary" />
              </div>
              <span className="font-bold text-slate-700">{district}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-200" />
          </button>
        ))}

        {filteredDistricts.length === 0 && (
          <div className="py-10 text-center">
            <p className="text-sm font-bold text-slate-300 uppercase tracking-widest">Sonuç Bulunamadı</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SelectDistrictPage() {
  return (
    <Suspense fallback={<div className="p-10 text-center font-bold">Yükleniyor...</div>}>
      <SelectDistrictContent />
    </Suspense>
  );
}
