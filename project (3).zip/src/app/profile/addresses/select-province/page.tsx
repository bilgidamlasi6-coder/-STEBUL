
"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Search, MapPin, ChevronRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { TURKEY_PROVINCES } from "@/lib/turkey-data";

function SelectProvinceContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [searchTerm, setSearchTerm] = useState("");
  
  const mode = searchParams.get("mode");
  const id = searchParams.get("id");

  const filteredProvinces = TURKEY_PROVINCES.filter(p => 
    p.toLocaleLowerCase("tr").includes(searchTerm.toLocaleLowerCase("tr"))
  );

  const handleSelect = (province: string) => {
    const baseUrl = mode === "edit" ? `/profile/addresses/edit?id=${id}` : "/profile/addresses/new";
    // First navigate to province selection to ensure cascading
    router.push(`/profile/addresses/select-district?mode=${mode}&id=${id || ""}&province=${province}`);
  };

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden max-w-md mx-auto">
      <header className="flex-shrink-0 bg-white px-6 pt-8 pb-4 border-b border-slate-100 z-10">
        <div className="flex items-center gap-4 mb-5">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">İl Seçiniz</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">KONUM BELİRLEME</p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input 
            placeholder="İl Ara..." 
            className="pl-11 h-12 bg-slate-50 border-none rounded-2xl font-bold focus-visible:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2">
        {filteredProvinces.map((province) => (
          <button
            key={province}
            onClick={() => handleSelect(province)}
            className="w-full flex items-center justify-between p-4 bg-white border border-slate-50 rounded-2xl hover:bg-slate-50 transition-all active:scale-[0.98] group"
          >
            <div className="flex items-center gap-3">
              <div className="bg-slate-50 p-2 rounded-xl group-hover:bg-primary/10 transition-colors">
                <MapPin className="w-4 h-4 text-slate-400 group-hover:text-primary" />
              </div>
              <span className="font-bold text-slate-700">{province}</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-200" />
          </button>
        ))}

        {filteredProvinces.length === 0 && (
          <div className="py-10 text-center">
            <p className="text-sm font-bold text-slate-300 uppercase tracking-widest">Sonuç Bulunamadı</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SelectProvincePage() {
  return (
    <Suspense fallback={<div className="p-10 text-center font-bold">Yükleniyor...</div>}>
      <SelectProvinceContent />
    </Suspense>
  );
}
