
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, MapPin, Plus, Trash2, Edit2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collection, query, onSnapshot, doc, deleteDoc, updateDoc } from "firebase/firestore";

interface Address {
  id: string;
  title: string;
  detail: string;
  isDefault: boolean;
  province?: string;
  district?: string;
}

export default function AddressesPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user } = useAuth();
  const db = useFirestore();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !db) {
      if (!user) setLoading(false);
      return;
    }

    const q = query(collection(db, "kullanıcılar", user.uid, "addresses"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetched = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Address[];
      setAddresses(fetched);
      setLoading(false);
    }, (error) => {
      console.error("Addresses error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, db]);

  const handleDelete = async (id: string) => {
    if (!user || !db) return;
    try {
      await deleteDoc(doc(db, "kullanıcılar", user.uid, "addresses", id));
      toast({ title: "Adres Silindi", description: "Adres başarıyla listeden kaldırıldı." });
    } catch (error) {
      toast({ variant: "destructive", title: "Hata", description: "Adres silinemedi." });
    }
  };

  const setDefault = async (id: string) => {
    if (!user || !db) return;
    try {
      const promises = addresses.map(addr => 
        updateDoc(doc(db, "kullanıcılar", user.uid, "addresses", addr.id), { isDefault: addr.id === id })
      );
      await Promise.all(promises);
      toast({ title: "Varsayılan Güncellendi", description: "Seçili adres varsayılan olarak ayarlandı." });
    } catch (error) {
      toast({ variant: "destructive", title: "Hata", description: "Güncelleme başarısız." });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Adreslerim</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">TESLİMAT VE HİZMET NOKTALARI</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-4 pb-24">
        {addresses.map((address) => (
          <div key={address.id} className="bg-white p-5 rounded-[1.5rem] border border-slate-100 shadow-sm space-y-4 relative group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-primary/10 p-2.5 rounded-xl">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900">{address.title}</h3>
                  {address.isDefault && (
                    <span className="text-[8px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full uppercase tracking-widest mt-1 inline-block">Varsayılan</span>
                  )}
                </div>
              </div>
              <div className="flex gap-1">
                <button 
                  onClick={() => router.push(`/profile/addresses/edit?id=${address.id}`)}
                  className="p-2.5 text-slate-400 hover:text-primary transition-colors bg-slate-50 rounded-xl"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => handleDelete(address.id)} 
                  className="p-2.5 text-slate-400 hover:text-red-500 transition-colors bg-slate-50 rounded-xl"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
            <p className="text-[13px] text-slate-500 font-medium leading-relaxed">{address.detail}</p>
            {!address.isDefault && (
              <button 
                onClick={() => setDefault(address.id)}
                className="w-full py-3 bg-slate-50 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest hover:bg-primary/5 hover:text-primary transition-all active:scale-95"
              >
                Varsayılan Olarak Ayarla
              </button>
            )}
          </div>
        ))}

        {addresses.length === 0 && (
          <div className="py-16 text-center bg-white rounded-[2rem] border-2 border-dashed border-slate-100">
            <MapPin className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p className="text-sm font-black text-slate-400 uppercase tracking-widest">Kayıtlı adresiniz yok.</p>
          </div>
        )}

        <Button 
          onClick={() => router.push("/profile/addresses/new")}
          className="w-full bg-white text-primary border-2 border-dashed border-primary/30 hover:bg-primary/5 hover:border-primary h-16 rounded-[1.5rem] font-black text-sm uppercase tracking-widest transition-all"
        >
          <Plus className="w-5 h-5 mr-2" /> Yeni Adres Ekle
        </Button>
      </div>
    </div>
  );
}
