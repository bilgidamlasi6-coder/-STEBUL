
"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, MapPin, ChevronRight, FileText, Tag } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function NewAddressPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    province: "",
    district: "",
    detail: ""
  });

  // Load state from sessionStorage or URL on mount
  useEffect(() => {
    const savedData = sessionStorage.getItem("pending_address_form");
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setFormData(prev => ({ ...prev, ...parsed }));
    }

    // Overwrite with URL params if they exist (coming back from selection)
    const urlProvince = searchParams.get("province");
    const urlDistrict = searchParams.get("district");
    
    if (urlProvince || urlDistrict) {
      setFormData(prev => {
        const newData = {
          ...prev,
          province: urlProvince || prev.province,
          district: urlDistrict || prev.district
        };
        sessionStorage.setItem("pending_address_form", JSON.stringify(newData));
        return newData;
      });
    }
  }, [searchParams]);

  const updateField = (field: string, value: string) => {
    const newData = { ...formData, [field]: value };
    setFormData(newData);
    sessionStorage.setItem("pending_address_form", JSON.stringify(newData));
  };

  const handleSelectProvince = () => {
    sessionStorage.setItem("pending_address_form", JSON.stringify(formData));
    router.push("/profile/addresses/select-province?mode=new");
  };

  const handleSelectDistrict = () => {
    if (!formData.province) {
      toast({ title: "Uyarı", description: "Lütfen önce bir il seçiniz." });
      return;
    }
    sessionStorage.setItem("pending_address_form", JSON.stringify(formData));
    router.push(`/profile/addresses/select-district?mode=new&province=${formData.province}`);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.province || !formData.district || !formData.detail) {
      toast({ title: "Hata", description: "Lütfen tüm alanları doldurunuz.", variant: "destructive" });
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      sessionStorage.removeItem("pending_address_form");
      toast({ 
        title: "Adres Eklendi", 
        description: `${formData.title} başarıyla kaydedildi.` 
      });
      router.push("/profile/addresses");
    }, 1000);
  };

  return (
    <div className="flex flex-col h-screen bg-white overflow-hidden max-w-md mx-auto">
      {/* HEADER */}
      <header className="flex-shrink-0 bg-white px-6 pt-8 pb-4 border-b border-slate-100 shadow-sm z-10">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => {
              sessionStorage.removeItem("pending_address_form");
              router.back();
            }} 
            className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Yeni Adres Ekle</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">TESLİMAT NOKTASI</p>
          </div>
        </div>
      </header>

      {/* SCROLLABLE CONTENT AREA */}
      <div className="flex-1 overflow-y-auto px-6 pt-6">
        <form onSubmit={handleSave} className="space-y-6 pb-32">
          {/* Adres Başlığı */}
          <div className="space-y-2">
            <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
              <Tag className="w-3 h-3 text-primary" /> ADRES BAŞLIĞI
            </Label>
            <Input 
              placeholder="Örn: Evim, İş Yerim" 
              className="rounded-2xl h-12 bg-slate-50 border-none font-bold focus-visible:ring-primary"
              required
              value={formData.title}
              onChange={(e) => updateField("title", e.target.value)}
            />
          </div>

          {/* İl Seçimi */}
          <div className="space-y-2">
            <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
              <MapPin className="w-3 h-3 text-primary" /> ŞEHİR
            </Label>
            <button
              type="button"
              onClick={handleSelectProvince}
              className="w-full flex items-center justify-between px-5 h-12 bg-slate-50 rounded-2xl text-left transition-all active:scale-[0.98]"
            >
              <span className={formData.province ? "font-bold text-slate-900" : "text-slate-400 font-medium"}>
                {formData.province || "İl Seçiniz"}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-300" />
            </button>
          </div>

          {/* İlçe Seçimi */}
          <div className="space-y-2">
            <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
              <MapPin className="w-3 h-3 text-primary" /> İLÇE
            </Label>
            <button
              type="button"
              disabled={!formData.province}
              onClick={handleSelectDistrict}
              className={`w-full flex items-center justify-between px-5 h-12 bg-slate-50 rounded-2xl text-left transition-all ${!formData.province ? 'opacity-50 grayscale cursor-not-allowed' : 'active:scale-[0.98]'}`}
            >
              <span className={formData.district ? "font-bold text-slate-900" : "text-slate-400 font-medium"}>
                {formData.district || (formData.province ? "İlçe Seçiniz" : "Önce İl Seçiniz")}
              </span>
              <ChevronRight className="w-4 h-4 text-slate-300" />
            </button>
          </div>

          {/* Açık Adres */}
          <div className="space-y-2">
            <Label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-2">
              <FileText className="w-3 h-3 text-primary" /> AÇIK ADRES
            </Label>
            <Textarea 
              placeholder="Mahalle, cadde, sokak, bina no, daire no ve adres tarifi..." 
              className="rounded-2xl min-h-[120px] bg-slate-50 border-none font-medium p-4 focus-visible:ring-primary resize-none"
              required
              value={formData.detail}
              onChange={(e) => updateField("detail", e.target.value)}
            />
          </div>

          <div className="pt-4 pb-12">
            <Button 
              type="submit" 
              disabled={loading}
              className="w-full bg-primary h-14 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-primary/20 transition-all active:scale-95 border-none"
            >
              {loading ? "Kaydediliyor..." : "Adresi Kaydet"}
            </Button>
            <Button 
              type="button"
              variant="ghost"
              onClick={() => {
                sessionStorage.removeItem("pending_address_form");
                router.back();
              }}
              className="w-full mt-3 h-12 text-slate-400 font-black text-[10px] uppercase tracking-widest"
            >
              Vazgeç
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
