
"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collection, query, where, onSnapshot, orderBy, doc, updateDoc, serverTimestamp } from "firebase/firestore";
import { 
  ChevronRight, 
  Loader2, 
  ArrowLeft, 
  Star, 
  Trash2,
  PauseCircle,
  PlayCircle,
  Edit3
} from "lucide-react";
import { useRouter } from "next/navigation";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { RelativeTime } from "@/components/RelativeTime";
import Link from "next/link";
import { useToast } from "@/hooks/use-toast";

export default function JobHistoryPage() {
  const { user, loading: authLoading } = useAuth();
  const db = useFirestore();
  const router = useRouter();
  const { toast } = useToast();
  
  const [data, setData] = useState({ requests: [] as any[], reviews: [] as any[] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!db || !user?.uid) {
      if (user === null) setLoading(false);
      return;
    }

    setLoading(true);

    const unsubReq = onSnapshot(
      query(
        collection(db, "requests"), 
        where("userId", "==", user.uid), 
        where("status", "!=", "deleted"),
        orderBy("status", "asc"), 
        orderBy("createdAt", "desc")
      ), 
      (snap) => {
        setData(prev => ({ ...prev, requests: snap.docs.map(d => ({ id: d.id, ...d.data() })) }));
        setLoading(false);
      },
      (err) => {
        console.error("History query error:", err);
        setLoading(false);
      }
    );

    const unsubRev = onSnapshot(
      query(collection(db, "reviews"), where("targetId", "==", user.uid), orderBy("createdAt", "desc")), 
      (snap) => {
        setData(prev => ({ ...prev, reviews: snap.docs.map(d => ({ id: d.id, ...d.data() })) }));
      }
    );

    return () => { unsubReq(); unsubRev(); };
  }, [db, user?.uid, authLoading]);

  const handleUpdateStatus = async (id: string, status: string) => {
    if (!db) return;
    try {
      const requestRef = doc(db, "requests", id);
      await updateDoc(requestRef, { 
        status, 
        updatedAt: serverTimestamp() 
      });
      toast({ title: "Başarılı", description: `Talep durumu '${status}' olarak güncellendi.` });
    } catch (e) {
      toast({ variant: "destructive", title: "Hata" });
    }
  };

  if (loading || authLoading) return <div className="flex items-center justify-center min-h-screen bg-white"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  function JobGrid({ items }: { items: any[] }) {
    if (items.length === 0) return <div className="py-20 text-center text-slate-300 font-black uppercase text-[9px]">Kayıt bulunmuyor.</div>;
    return items.map(item => (
      <div key={item.id} className="relative group">
        <Link href={`/requests/${item.id}`}>
          <div className="p-4 bg-white border border-slate-100 rounded-3xl hover:shadow-sm transition-all shadow-sm">
             <div className="flex justify-between mb-2">
                <span className="text-[8px] font-black text-primary bg-primary/5 px-2 py-0.5 rounded uppercase">{item.category}</span>
                <span className={`text-[8px] font-black uppercase ${item.status === 'active' ? 'text-emerald-500' : 'text-amber-500'}`}>
                  {item.status === 'active' ? 'TEKLİFLER BEKLENİYOR' : 
                   item.status === 'in_progress' ? 'İŞLEMDE' : 
                   item.status === 'completed' ? 'TAMAMLANDI' : 'PASİF'}
                </span>
             </div>
             <p className="text-sm font-black text-slate-900 truncate mb-2 pr-10">{item.title}</p>
             <div className="flex items-center justify-between text-[9px] font-bold text-slate-300 uppercase">
                <RelativeTime date={item.createdAt} />
                <ChevronRight className="w-3.5 h-3.5" />
             </div>
          </div>
        </Link>
        <div className="absolute top-4 right-4 z-[60] flex items-center gap-1 bg-slate-50/80 backdrop-blur-sm p-1 rounded-xl border border-slate-100 shadow-sm pointer-events-auto">
            <button 
              type="button"
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); router.push(`/requests/${item.id}?edit=true`); }}
              className="p-1.5 hover:bg-white rounded-lg transition-colors text-slate-600"
              title="Düzenle"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
            {item.status === 'active' ? (
              <button 
                type="button"
                onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleUpdateStatus(item.id, 'inactive'); }}
                className="p-1.5 hover:bg-white rounded-lg transition-colors text-amber-500"
                title="Yayından Kaldır"
              >
                <PauseCircle className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button 
                type="button"
                onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleUpdateStatus(item.id, 'active'); }}
                className="p-1.5 hover:bg-white rounded-lg transition-colors text-emerald-500"
                title="Yayınla"
              >
                <PlayCircle className="w-3.5 h-3.5" />
              </button>
            )}
            <button 
              type="button"
              onClick={(e) => { 
                e.preventDefault(); 
                e.stopPropagation(); 
                handleUpdateStatus(item.id, 'deleted'); 
              }}
              className="p-1.5 hover:bg-white rounded-lg transition-colors text-red-500 active:scale-90"
              title="Sil"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
        </div>
      </div>
    ));
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-50 shadow-sm">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full"><ArrowLeft className="w-5 h-5 text-slate-600" /></button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight uppercase">İş Geçmişi</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">HESAP ÖZETİ</p>
          </div>
        </div>
      </header>

      <Tabs defaultValue="ongoing" className="w-full">
        <div className="px-6 pt-6">
          <TabsList className="h-11 bg-slate-50 p-1 rounded-xl w-full">
            <TabsTrigger value="ongoing" className="flex-1 rounded-lg font-black text-[9px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">Devam Eden</TabsTrigger>
            <TabsTrigger value="completed" className="flex-1 rounded-lg font-black text-[9px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">Tamamlanan</TabsTrigger>
            <TabsTrigger value="cancelled" className="flex-1 rounded-lg font-black text-[9px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">İptal / Pasif</TabsTrigger>
            <TabsTrigger value="reviews" className="flex-1 rounded-lg font-black text-[9px] uppercase data-[state=active]:bg-white data-[state=active]:text-primary">Puanlar</TabsTrigger>
          </TabsList>
        </div>

        <div className="px-6 py-6 pb-24 space-y-4">
          <TabsContent value="ongoing" className="space-y-3 m-0">
            <JobGrid items={data.requests.filter(r => r.status === 'in_progress' || r.status === 'active' || r.status === 'inactive')} />
          </TabsContent>
          <TabsContent value="completed" className="space-y-3 m-0">
            <JobGrid items={data.requests.filter(r => r.status === 'completed' || r.status === 'reviewed')} />
          </TabsContent>
          <TabsContent value="cancelled" className="space-y-3 m-0">
            <JobGrid items={data.requests.filter(r => r.status === 'cancelled' || r.status === 'paused')} />
          </TabsContent>
          <TabsContent value="reviews" className="space-y-3 m-0">
            {data.reviews.length > 0 ? data.reviews.map(rev => (
              <div key={rev.id} className="p-4 bg-white border border-slate-100 rounded-3xl shadow-sm">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-[10px] font-black text-slate-900 uppercase">{rev.reviewerName}</p>
                  <div className="flex gap-0.5">
                    {[1,2,3,4,5].map(s => <Star key={s} className={`w-3 h-3 ${rev.rating >= s ? 'fill-[#F5C542] text-[#F5C542]' : 'text-slate-100'}`} />)}
                  </div>
                </div>
                <p className="text-xs text-slate-500 font-medium italic">"{rev.comment}"</p>
              </div>
            )) : <div className="py-20 text-center text-slate-300 font-black uppercase text-[9px]">Henüz puanlama yok.</div>}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
