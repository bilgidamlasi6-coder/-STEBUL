
"use client";

import { useState, useEffect, Suspense, useMemo } from "react";
import { 
  User as UserIcon, 
  Shield, 
  HelpCircle, 
  LogOut, 
  ChevronRight, 
  MapPin, 
  Star, 
  Heart, 
  Settings2, 
  Bell, 
  Wallet, 
  History, 
  CreditCard,
  LayoutDashboard,
  Loader2,
  Languages,
  ShieldCheck,
  MessageSquare,
  Phone,
  Send
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { Button } from "@/components/ui/button";
import { AuthPanel } from "@/components/AuthPanel";
import { collection, query, where, doc, getDoc, collectionGroup, onSnapshot, limit } from "firebase/firestore";

function ProfileContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { user, profile: currentUserProfile, loading, logout } = useAuth();
  
  const targetUid = searchParams.get("uid");
  const [targetProfile, setTargetProfile] = useState<any>(null);
  const [isSelf, setIsSelf] = useState(true);
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);
  
  const [requestCount, setRequestCount] = useState(0);
  const [offerCount, setOfferCount] = useState(0);
  const [reviewCount, setReviewCount] = useState(0);
  const [avgRating, setAvgRating] = useState("0.0");
  const [hasInteraction, setHasInteraction] = useState(false);

  const uidToFetch = useMemo(() => targetUid || user?.uid, [targetUid, user?.uid]);
  const isAdmin = currentUserProfile?.rol === 'SUPER_ADMIN';

  useEffect(() => {
    if (!db || !uidToFetch) return;
    const selfMode = !targetUid || targetUid === user?.uid;
    setIsSelf(selfMode);

    // Profile Data Fetching
    if (!selfMode) {
      getDoc(doc(db, "kullanıcılar", uidToFetch)).then(snap => { 
        if (snap.exists()) setTargetProfile(snap.data()); 
      });
      
      // Interaction Check for Contact Buttons (Only if logged in)
      if (user?.uid) {
        const q1 = query(collectionGroup(db, "offers"), 
          where("businessId", "==", user.uid), 
          where("requestUserId", "==", uidToFetch),
          limit(1)
        );
        const q2 = query(collectionGroup(db, "offers"), 
          where("businessId", "==", uidToFetch), 
          where("requestUserId", "==", user.uid),
          limit(1)
        );
        
        const unsub1 = onSnapshot(q1, (snap) => { if (!snap.empty) setHasInteraction(true); }, (err) => console.log("Index check..."));
        const unsub2 = onSnapshot(q2, (snap) => { if (!snap.empty) setHasInteraction(true); }, (err) => console.log("Index check..."));
      }
    }

    // Real-time Counters - Filtering deleted requests from count
    const unsubReq = onSnapshot(query(collection(db, "requests"), where("userId", "==", uidToFetch)), (snap) => {
      const activeDocs = snap.docs.filter(d => d.data().status !== 'deleted');
      setRequestCount(activeDocs.length);
    });

    const unsubOff = onSnapshot(query(collectionGroup(db, "offers"), where("businessId", "==", uidToFetch)), (snap) => setOfferCount(snap.size), (err) => console.log("Offer count index pending..."));
    
    const unsubRev = onSnapshot(query(collection(db, "reviews"), where("targetId", "==", uidToFetch)), (snap) => {
      setReviewCount(snap.size);
      if (snap.size > 0) {
        const sum = snap.docs.reduce((acc, curr) => acc + curr.data().rating, 0);
        setAvgRating((sum / snap.size).toFixed(1));
      }
    });

    return () => { 
      unsubReq(); 
      unsubOff(); 
      unsubRev(); 
    };
  }, [uidToFetch, db, user?.uid, targetUid]);

  const handleAction = (path: string) => {
    if (!user) { setIsAuthPanelOpen(true); return; }
    // If it's a subpage (History, Info, etc.) and we are admin viewing someone else, pass the UID
    const targetPath = (targetUid && !isSelf && isAdmin) ? `${path}?uid=${targetUid}` : path;
    router.push(targetPath);
  };

  const handleContact = (type: 'message' | 'call') => {
    if (!user) { setIsAuthPanelOpen(true); return; }
    const activeProfile = isSelf ? currentUserProfile : targetProfile;
    if (type === 'call' && activeProfile?.telefon) {
      window.location.href = `tel:${activeProfile.telefon}`;
    } else {
      router.push('/chats');
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;

  const isGuest = !user && !targetUid;
  const activeProfile = isSelf ? currentUserProfile : targetProfile;
  const showFullMenu = isSelf || (isAdmin && targetUid);

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      {(!isGuest || targetUid) && (
        <header className="sticky top-0 z-40 bg-white px-6 pt-6 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <div className="relative">
                <img src={activeProfile?.avatar || "https://picsum.photos/seed/istanbul-user/160/160"} className="w-14 h-14 rounded-2xl object-cover border-2 border-slate-50" alt="" />
                {activeProfile?.rol === 'SUPER_ADMIN' && <div className="absolute -bottom-1 -right-1 bg-primary w-5 h-5 rounded-full border-2 border-white flex items-center justify-center"><Shield className="w-2.5 h-2.5 text-white" /></div>}
              </div>
              <div className="ml-4">
                <h2 className="text-lg font-black text-slate-900 leading-tight">
                  {activeProfile ? `${activeProfile.isim} ${activeProfile.soyadı}` : 'Kullanıcı'}
                  {!isSelf && isAdmin && <span className="text-[10px] text-primary ml-2">(Yönetiliyor)</span>}
                </h2>
                <p className="text-[9px] font-bold text-slate-400 uppercase mt-1">{activeProfile?.şehir || 'Konum belirtilmemiş'}</p>
              </div>
            </div>
            {isSelf ? (
              user && <button onClick={() => router.push('/profile/info')} className="p-2.5 bg-slate-50 rounded-xl"><Settings2 className="w-4 h-4 text-slate-500" /></button>
            ) : (
              <div className="flex gap-2">
                 {activeProfile?.telefon && (
                   <button onClick={() => handleContact('call')} className="p-2.5 bg-primary/5 text-primary rounded-xl"><Phone className="w-4 h-4" /></button>
                 )}
                 {(hasInteraction || isAdmin) && (
                   <button onClick={() => handleContact('message')} className="p-2.5 bg-primary/5 text-primary rounded-xl"><MessageSquare className="w-4 h-4" /></button>
                 )}
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2">
            <StatCard 
              label="TALEPLER" 
              value={requestCount} 
              onClick={() => router.push(`/requests?userId=${uidToFetch}`)}
            />
            <StatCard 
              label="TEKLİFLER" 
              value={offerCount} 
              onClick={isSelf || isAdmin ? () => handleAction('/offers') : null}
            />
            <StatCard 
              label="PUAN" 
              value={avgRating} 
              hasStar 
              onClick={() => router.push(`/profile/reviews?uid=${uidToFetch}`)}
            />
          </div>

          {!isSelf && (hasInteraction || isAdmin) && (
            <div className="mt-4 flex gap-2">
               <Button onClick={() => handleContact('message')} className="flex-1 bg-primary h-10 rounded-xl font-black text-[10px] uppercase shadow-md border-none">
                 <Send className="w-3 h-3 mr-2" /> MESAJ GÖNDER
               </Button>
            </div>
          )}
        </header>
      )}

      <div className="px-6 pt-4 pb-24 space-y-3">
        {isGuest && (
          <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 text-center space-y-6">
            <div className="w-20 h-20 bg-primary/5 rounded-3xl flex items-center justify-center mx-auto"><UserIcon className="w-10 h-10 text-primary" /></div>
            <div>
              <h3 className="text-xl font-black text-slate-900 uppercase">Hoş Geldiniz</h3>
              <p className="text-xs text-slate-400 font-bold uppercase mt-2">İşlemlerinizi yönetmek için giriş yapın.</p>
            </div>
            <Button onClick={() => setIsAuthPanelOpen(true)} className="w-full bg-primary h-14 rounded-2xl font-black uppercase text-sm border-none shadow-lg">GİRİŞ YAP / ÜYE OL</Button>
          </div>
        )}

        {isAdmin && isSelf && <MenuLink icon={LayoutDashboard} label="Yönetim Paneli" onClick={() => router.push('/admin')} className="bg-primary/5 border-primary/10 mb-2" />}

        {showFullMenu && (
          <>
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
              <MenuLink icon={Heart} label="Favorilerim" onClick={() => handleAction('/profile/favorites')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={History} label="İş Geçmişi" onClick={() => handleAction('/profile/history')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={UserIcon} label="Kişisel Bilgiler" onClick={() => handleAction('/profile/info')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={Bell} label="Bildirimler" onClick={() => handleAction('/profile/notifications')} />
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
              <MenuLink icon={ShieldCheck} label="Güvenlik & Gizlilik" onClick={() => handleAction('/profile/security')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={MapPin} label="Adreslerim" onClick={() => handleAction('/profile/addresses')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={Wallet} label="Cüzdanım" onClick={() => handleAction('/profile/wallet')} />
              <Separator className="bg-slate-50" />
              <MenuLink icon={CreditCard} label="Premium" onClick={() => handleAction('/profile/premium')} />
            </div>

            {isSelf && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <MenuLink icon={Languages} label="Dil Seçimi" onClick={() => router.push('/profile/language')} />
                <Separator className="bg-slate-50" />
                <MenuLink icon={HelpCircle} label="Yardım & Destek" onClick={() => router.push('/profile/help')} />
              </div>
            )}

            {isSelf && user && (
              <button onClick={async () => { await logout(); router.push('/'); }} className="w-full p-4 bg-white rounded-2xl border border-slate-100 text-red-500 font-black flex items-center justify-center gap-2 mt-4">
                <LogOut className="w-4 h-4" /> GÜVENLİ ÇIKIŞ
              </button>
            )}
          </>
        )}

        {!isSelf && activeProfile?.bio && (
          <div className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">HAKKINDA</h3>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">{activeProfile.bio}</p>
          </div>
        )}
      </div>
      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
    </div>
  );
}

function StatCard({ label, value, hasStar, onClick }: any) {
  return (
    <button 
      onClick={onClick}
      disabled={!onClick}
      className={`bg-slate-50/70 py-2.5 rounded-2xl text-center border border-slate-100 transition-all ${onClick ? 'active:scale-95 hover:bg-slate-100' : 'cursor-default opacity-80'}`}
    >
      <div className="flex items-center justify-center gap-1">
        {hasStar && <Star className="w-3 h-3 text-[#F5C542] fill-[#F5C542]" />}
        <p className="text-sm font-black text-slate-900">{value}</p>
      </div>
      <p className="text-[8px] font-black text-slate-400 uppercase mt-1">{label}</p>
    </button>
  );
}

function MenuLink({ icon: Icon, label, onClick, className }: any) {
  return (
    <button onClick={onClick} className={`w-full flex items-center justify-between py-4 px-5 hover:bg-slate-50 transition-colors ${className}`}>
      <div className="flex items-center">
        <div className="bg-slate-50 p-2 rounded-xl mr-4"><Icon className="w-4 h-4 text-slate-500" /></div>
        <span className="font-bold text-slate-700 text-sm">{label}</span>
      </div>
      <ChevronRight className="w-4 h-4 text-slate-300" />
    </button>
  );
}

export default function ProfilePage() {
  return <Suspense fallback={<div className="p-10 text-center font-bold">Yükleniyor...</div>}><ProfileContent /></Suspense>;
}
