"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, CheckCircle2 } from "lucide-react";

const LANGUAGES = [
  { id: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { id: 'en', name: 'English', flag: '🇺🇸' },
  { id: 'ar', name: 'العربية', flag: '🇸🇦' }
];

export default function LanguagePage() {
  const router = useRouter();
  const [selectedLang, setSelectedLang] = useState('tr');

  useEffect(() => {
    const saved = localStorage.getItem('app_language');
    if (saved) setSelectedLang(saved);
  }, []);

  const handleSelect = (id: string) => {
    setSelectedLang(id);
    localStorage.setItem('app_language', id);
    // In a real app, you would trigger a re-translation here
  };

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Dil Seçimi</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">UYGULAMA DİLİ</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-3">
        {LANGUAGES.map((lang) => (
          <button
            key={lang.id}
            onClick={() => handleSelect(lang.id)}
            className={`w-full flex items-center justify-between p-5 rounded-[1.5rem] border transition-all ${
              selectedLang === lang.id 
                ? 'bg-primary/5 border-primary shadow-sm' 
                : 'bg-white border-slate-100'
            }`}
          >
            <div className="flex items-center gap-4">
              <span className="text-2xl">{lang.flag}</span>
              <span className={`font-black text-sm ${selectedLang === lang.id ? 'text-primary' : 'text-slate-700'}`}>
                {lang.name}
              </span>
            </div>
            {selectedLang === lang.id && <CheckCircle2 className="w-5 h-5 text-primary" />}
          </button>
        ))}
      </div>
    </div>
  );
}
