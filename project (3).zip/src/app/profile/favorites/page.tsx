"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Heart, Search, User } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function FavoritesPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Favorilerim</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">KAYDETTİKLERİNİZ</p>
          </div>
        </div>
      </header>

      <Tabs defaultValue="requests" className="w-full">
        <div className="px-6 pt-6">
          <TabsList className="w-full h-12 bg-white p-1 rounded-2xl shadow-sm border border-slate-100">
            <TabsTrigger value="requests" className="flex-1 rounded-xl font-black text-xs data-[state=active]:bg-primary data-[state=active]:text-white">Talepler</TabsTrigger>
            <TabsTrigger value="users" className="flex-1 rounded-xl font-black text-xs data-[state=active]:bg-primary data-[state=active]:text-white">Kullanıcılar</TabsTrigger>
          </TabsList>
        </div>

        <div className="px-6 py-12">
          <TabsContent value="requests" className="m-0">
            <EmptyState icon={Search} label="Henüz favori talebiniz yok." />
          </TabsContent>
          <TabsContent value="users" className="m-0">
            <EmptyState icon={User} label="Henüz favori kullanıcınız yok." />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

function EmptyState({ icon: Icon, label }: any) {
  return (
    <div className="text-center space-y-4">
      <div className="bg-white w-20 h-20 rounded-full flex items-center justify-center mx-auto shadow-sm border border-slate-50">
        <Icon className="w-10 h-10 text-slate-300" />
      </div>
      <div>
        <h3 className="text-base font-black text-slate-900">{label}</h3>
        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1 leading-relaxed">Keşfetmeye başlayın ve <br />beğendiklerinizi kalp ikonuna <br />basarak buraya ekleyin.</p>
      </div>
    </div>
  );
}
