"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Star, Loader2, MessageCircle, History, AlertCircle } from "lucide-react";
import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { doc, getDoc, collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { RelativeTime } from "@/components/RelativeTime";
import { Button } from "@/components/ui/button";

export default function ReviewsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const db = useFirestore();
  const { user } = useAuth();
  
  const targetUid = searchParams.get("uid") || user?.uid;
  const isSelf = !searchParams.get("uid") || searchParams.get("uid") === user?.uid;

  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState("Kullanıcı");
  const [reviews, setReviews] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchProfileData() {
      if (!db || !targetUid) return;
      try {
        const docSnap = await getDoc(doc(db, "kullanıcılar", targetUid));
        if (docSnap.exists()) {
          const d = docSnap.data();
          setProfileName(`${d.isim} ${d.soyadı}`);
        }
      } catch (e) { console.error(e); }
    }
    fetchProfileData();
  }, [db, targetUid]);

  useEffect(() => {
    if (!db || !targetUid) {
      if (user === null && !searchParams.get("uid")) setLoading(false);
      return;
    }

    const timeoutId = setTimeout(() => {
      if (loading) {
        setLoading(false);
        setError("Yorumlar yüklenirken zaman aşımı oluştu.");
      }
    }, 8000);

    const q = query(
      collection(db, "reviews"), 
      where("targetId", "==", targetUid),
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(q, (snap) => {
      setReviews(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    }, (err) => {
      console.error("Reviews listener error:", err);
      setLoading(false);
    });

    return () => {
      clearTimeout(timeoutId);
      unsub();
    };
  }, [db, targetUid, user]);

  const averageRating = useMemo(() => {
    if (reviews.length === 0) return "0.0";
    const sum = reviews.reduce((acc, curr) => acc + (curr.rating || 0), 0);
    return (sum / reviews.length).toFixed(1);
  }, [reviews]);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary w-6 h-6" /></div>;

  if (error && reviews.length === 0) {
    return (
      <div className="max-w-md mx-auto min-h-screen flex flex-col items-center justify-center p-10 text-center">
        <AlertCircle className="w-12 h-12 text-amber-500 mb-4" />
        <p className="text-slate-500 font-bold mb-6">{error}</p>
        <Button onClick={() => window.location.reload()} className="bg-primary text-white rounded-xl">Tekrar Dene</Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()} className="p-1.5 bg-slate-50 rounded-lg">
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </button>
          <div>
            <h1 className="text-lg font-black text-slate-900 tracking-tight leading-none uppercase">Değerlendirmeler</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">
              {isSelf ? "HESABINIZIN" : profileName.toUpperCase()} • GÜVEN SKORU
            </p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 pb-24">
        <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm text-center mb-6 relative overflow-hidden">
           <div className="flex justify-center gap-1 mb-2">
             {[1,2,3,4,5].map((i) => (
               <Star key={i} className={`w-4 h-4 ${parseFloat(averageRating) >= i ? 'fill-[#F5C542] text-[#F5C542]' : 'text-slate-200'}`} />
             ))}
           </div>
           <h2 className="text-3xl font-black tracking-tighter text-slate-900">{averageRating}</h2>
           <p className="text-[8px] font-black uppercase tracking-[0.2em] mt-1 text-slate-400">{reviews.length} GERÇEK DEĞERLENDİRME</p>
        </div>

        <div className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-900 uppercase tracking-widest px-2 flex items-center gap-2">
            <MessageCircle className="w-3.5 h-3.5 text-primary" /> Üye Yorumları
          </h3>

          <div className="space-y-3">
            {reviews.length > 0 ? reviews.map((rev) => (
              <div key={rev.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-primary/5 rounded-full flex items-center justify-center mr-2.5 border border-primary/10 text-primary font-black text-[10px] uppercase">
                      {rev.reviewerName?.charAt(0)}
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-900 uppercase leading-none">{rev.reviewerName}</p>
                      <div className="flex gap-0.5 mt-1">
                        {[1,2,3,4,5].map((i) => (
                          <Star key={i} className={`w-2 h-2 ${rev.rating >= i ? 'fill-[#F5C542] text-[#F5C542]' : 'text-slate-200'}`} />
                        ))}
                      </div>
                    </div>
                  </div>
                  <span className="text-[7px] font-black text-slate-300 uppercase">
                    <RelativeTime date={rev.createdAt} />
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 font-medium leading-relaxed bg-slate-50/50 p-3 rounded-xl italic">
                  "{rev.comment || "Hizmetten memnun kalındı."}"
                </p>
              </div>
            )) : (
              <div className="py-16 text-center bg-white rounded-3xl border-2 border-dashed border-slate-100">
                <div className="bg-slate-50 w-10 h-10 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <History className="w-4 h-4 text-slate-200" />
                </div>
                <p className="text-slate-400 font-black uppercase text-[8px] tracking-widest px-10 leading-relaxed">
                  Henüz bir değerlendirme <br />yapılmamış.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}