"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Wallet, TrendingUp, Clock, AlertCircle } from "lucide-react";

export default function WalletPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Cüzdanım</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">FİNANSAL ÖZET</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-6">
        {/* MAIN BALANCE CARD */}
        <div className="bg-primary p-8 rounded-[2rem] text-white shadow-xl shadow-primary/20 relative overflow-hidden">
          <div className="relative z-10">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-80 mb-2">GÜNCEL BAKİYE</p>
            <h2 className="text-4xl font-black tracking-tighter">0,00 TL</h2>
          </div>
          <Wallet className="absolute -right-4 -bottom-4 w-32 h-32 opacity-10 rotate-12" />
        </div>

        {/* STATS GRID */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-[1.5rem] border border-slate-100 shadow-sm">
            <Clock className="w-5 h-5 text-yellow-500 mb-2" />
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">BEKLEYEN</p>
            <p className="text-lg font-black text-slate-900">0,00 TL</p>
          </div>
          <div className="bg-white p-5 rounded-[1.5rem] border border-slate-100 shadow-sm">
            <TrendingUp className="w-5 h-5 text-emerald-500 mb-2" />
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">TOPLAM KAZANÇ</p>
            <p className="text-lg font-black text-slate-900">0,00 TL</p>
          </div>
        </div>

        {/* TRANSACTION HISTORY EMPTY STATE */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest">İşlem Geçmişi</h3>
          </div>
          <div className="bg-white py-16 px-8 rounded-[2rem] border-2 border-dashed border-slate-200 text-center">
            <div className="bg-slate-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-slate-300" />
            </div>
            <p className="text-slate-500 font-bold text-sm">Henüz bir işlem bulunmuyor.</p>
            <p className="text-[9px] text-slate-400 font-black uppercase mt-1 tracking-widest">ÖDEME ALTYAPISI YAKINDA AKTİF OLACAKTIR</p>
          </div>
        </div>
      </div>
    </div>
  );
}
