
"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Smartphone, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function PhoneVerificationPage() {
  const router = useRouter();
  const { toast } = useToast();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Kod Gönderildi", description: "Doğrulama kodu telefonunuza iletildi." });
    router.back();
  };

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Telefon Doğrulama</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">GÜVENLİ ERİŞİM</p>
          </div>
        </div>
      </header>

      <div className="px-8 py-8 space-y-8">
        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 text-center space-y-4 shadow-sm">
          <div className="bg-primary/5 w-16 h-16 rounded-full flex items-center justify-center mx-auto">
            <Smartphone className="w-8 h-8 text-primary" />
          </div>
          <p className="text-sm text-slate-500 font-medium">Telefon numaranızı doğrulamak için bir SMS kodu gönderilecektir.</p>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">TELEFON NUMARASI</label>
            <Input type="tel" placeholder="05XX XXX XX XX" className="rounded-2xl h-12 bg-white border-slate-100 font-bold" required />
          </div>
          <Button type="submit" className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20">
            <CheckCircle2 className="w-5 h-5 mr-2" /> Kod Gönder
          </Button>
        </form>
      </div>
    </div>
  );
}
