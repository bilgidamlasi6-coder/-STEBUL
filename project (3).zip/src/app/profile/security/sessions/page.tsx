
"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Monitor, SmartphoneNfc, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function SessionsPage() {
  const router = useRouter();
  const { toast } = useToast();

  const handleLogoutOthers = () => {
    toast({ title: "Oturumlar Kapatıldı", description: "Diğer cihazlardaki tüm oturumlar sonlandırıldı." });
  };

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Oturumlarım</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">AKTİF CİHAZLAR</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-4">
        <div className="p-5 bg-primary/5 rounded-[1.5rem] border border-primary/10 shadow-sm">
          <div className="flex items-center gap-4 mb-3">
            <div className="bg-white p-2.5 rounded-xl">
              <SmartphoneNfc className="w-5 h-5 text-primary" />
            </div>
            <div>
              <span className="text-sm font-black text-slate-900">Bu Cihaz (iPhone 15 Pro)</span>
              <p className="text-[10px] text-primary font-black uppercase tracking-widest mt-0.5">Şu an aktif</p>
            </div>
          </div>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest ml-12">Son Giriş: Şimdi • İstanbul, TR</p>
        </div>
        
        <div className="p-5 bg-white rounded-[1.5rem] border border-slate-100 shadow-sm">
          <div className="flex items-center gap-4 mb-3">
            <div className="bg-slate-50 p-2.5 rounded-xl">
              <Monitor className="w-5 h-5 text-slate-400" />
            </div>
            <div>
              <span className="text-sm font-black text-slate-700">Windows PC - Chrome</span>
            </div>
          </div>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest ml-12">Son Giriş: 2 saat önce • Ankara, TR</p>
        </div>

        <div className="pt-8">
          <Button 
            onClick={handleLogoutOthers}
            className="w-full bg-white text-red-500 border-2 border-red-100 hover:bg-red-50 h-14 rounded-2xl font-black text-sm uppercase tracking-widest transition-all"
          >
            <LogOut className="w-5 h-5 mr-2" /> Diğer Oturumları Kapat
          </Button>
          <p className="text-center text-[9px] text-slate-400 font-bold uppercase tracking-widest mt-4 px-8 leading-relaxed">Güvenliğiniz için tanımadığınız cihazlardaki oturumları kapatmanızı öneririz.</p>
        </div>
      </div>
    </div>
  );
}
