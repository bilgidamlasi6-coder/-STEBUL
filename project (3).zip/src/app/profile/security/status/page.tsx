
"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, ShieldCheck, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function SecurityStatusPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Hesap Güvenliği</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">DURUM ÖZETİ</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <SecurityStat label="Şifre Gücü" value="Yüksek" color="text-emerald-500" />
          <SecurityStat label="2FA Durumu" value="Aktif Değil" color="text-amber-500" />
        </div>

        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-start gap-4">
            <div className="bg-amber-50 p-3 rounded-2xl">
              <AlertTriangle className="w-6 h-6 text-amber-500" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">İki Faktörlü Doğrulama (2FA)</h4>
              <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed">Hesabınızı daha güvenli hale getirmek için 2FA özelliğini aktif etmeniz önerilir.</p>
            </div>
          </div>
          
          <div className="h-px bg-slate-50" />

          <div className="flex items-start gap-4">
            <div className="bg-emerald-50 p-3 rounded-2xl">
              <CheckCircle2 className="w-6 h-6 text-emerald-500" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">E-Posta Güvenliği</h4>
              <p className="text-xs text-slate-500 mt-1 font-medium">kad***@example.com adresi doğrulandı ve aktif durumda.</p>
            </div>
          </div>

          <div className="h-px bg-slate-50" />

          <div className="flex items-start gap-4">
            <div className="bg-primary/5 p-3 rounded-2xl">
              <ShieldCheck className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">Hesap Koruması</h4>
              <p className="text-xs text-slate-500 mt-1 font-medium">Hesabınız en son güvenlik yamalarıyla korunmaktadır.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SecurityStat({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="bg-white p-5 rounded-[1.5rem] text-center border border-slate-100 shadow-sm">
      <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className={`text-sm font-black ${color}`}>{value}</p>
    </div>
  );
}
