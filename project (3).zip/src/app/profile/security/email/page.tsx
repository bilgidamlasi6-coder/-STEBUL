
"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Save, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";

export default function ChangeEmailPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { user, profile } = useAuth();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Başarılı", description: "E-posta adresiniz güncellendi." });
    router.back();
  };

  const currentEmail = profile?.["e-posta"] || user?.email || "Yükleniyor...";

  if (!user && !profile) {
     return <div className="min-h-screen flex items-center justify-center bg-white"><Loader2 className="animate-spin text-primary" /></div>;
  }

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">E-Posta Değiştir</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">GÜVENLİ GÜNCELLEME</p>
          </div>
        </div>
      </header>

      <div className="px-8 py-8 space-y-6">
        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">YENİ E-POSTA ADRESİ</label>
            <p className="text-xs text-slate-400 font-medium ml-1">Mevcut: <span className="text-slate-900 font-bold">{currentEmail}</span></p>
            <Input 
              type="email" 
              placeholder="Yeni e-posta adresinizi girin" 
              className="rounded-2xl h-12 bg-white border-slate-100 font-bold" 
              required 
            />
          </div>
          <Button type="submit" className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20">
            <Save className="w-5 h-5 mr-2" /> Onayla ve Kaydet
          </Button>
        </form>
      </div>
    </div>
  );
}
