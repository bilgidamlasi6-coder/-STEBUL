
"use client";

import { useRouter } from "next/navigation";
import { 
  ArrowLeft, 
  Mail, 
  Lock, 
  Smartphone, 
  Monitor, 
  ShieldCheck, 
  CheckCircle2, 
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function SecurityPage() {
  const router = useRouter();

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Güvenlik & Gizlilik</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">HESAP KORUMASI</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-6 space-y-6">
        <div className="grid grid-cols-1 gap-3">
          <StatusItem label="E-Posta Doğrulandı" icon={CheckCircle2} color="text-emerald-500" />
          <StatusItem label="Telefon Doğrulandı" icon={CheckCircle2} color="text-emerald-500" />
          <StatusItem label="Hesap Aktif" icon={ShieldCheck} color="text-emerald-500" />
        </div>

        <div className="bg-white rounded-[1.5rem] shadow-sm border border-slate-100 overflow-hidden">
          <SecurityAction icon={Mail} label="E-Posta Değiştir" onClick={() => router.push("/profile/security/email")} />
          <Separator className="bg-slate-50" />
          <SecurityAction icon={Lock} label="Şifre Değiştir" onClick={() => router.push("/profile/security/password")} />
          <Separator className="bg-slate-50" />
          <SecurityAction icon={Smartphone} label="Telefon Doğrulama" onClick={() => router.push("/profile/security/phone")} />
          <Separator className="bg-slate-50" />
          <SecurityAction icon={Monitor} label="Oturumlarım" onClick={() => router.push("/profile/security/sessions")} />
          <Separator className="bg-slate-50" />
          <SecurityAction icon={ShieldCheck} label="Hesap Güvenliği" onClick={() => router.push("/profile/security/status")} />
        </div>
      </div>
    </div>
  );
}

function StatusItem({ label, icon: Icon, color }: { label: string, icon: any, color: string }) {
  return (
    <div className="flex items-center justify-between p-4 bg-white rounded-[1.2rem] border border-slate-100 shadow-sm">
      <span className="text-[11px] font-black text-slate-600 uppercase tracking-widest">{label}</span>
      <Icon className={`w-4 h-4 ${color}`} />
    </div>
  );
}

function SecurityAction({ icon: Icon, label, onClick }: { icon: any, label: string, onClick?: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors group text-left">
      <div className="flex items-center">
        <div className="bg-slate-50 p-2 rounded-lg mr-3 shadow-sm">
          <Icon className="w-3.5 h-3.5 text-slate-500 group-hover:text-primary transition-colors" />
        </div>
        <span className="font-bold text-slate-700 text-[13px] tracking-tight">{label}</span>
      </div>
      <ArrowLeft className="w-3.5 h-3.5 text-slate-300 rotate-180" />
    </button>
  );
}
