
"use client";

import { useRouter } from "next/navigation";
import { ArrowLeft, Save, Lock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function ChangePasswordPage() {
  const router = useRouter();
  const { toast } = useToast();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Başarılı", description: "Şifreniz güncellendi." });
    router.back();
  };

  return (
    <div className="max-w-md mx-auto bg-slate-50 min-h-screen">
      <header className="sticky top-0 z-40 bg-white px-6 pt-8 pb-4 border-b border-slate-100 rounded-b-[2rem] shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight leading-none">Şifre Değiştir</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-[0.2em] mt-1">HESAP GÜVENLİĞİ</p>
          </div>
        </div>
      </header>

      <div className="px-8 py-8">
        <form onSubmit={handleSave} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">MEVCUT ŞİFRE</label>
              <Input type="password" placeholder="••••••••" className="rounded-2xl h-12 bg-white border-slate-100 font-bold" required />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">YENİ ŞİFRE</label>
              <Input type="password" placeholder="Yeni şifrenizi girin" className="rounded-2xl h-12 bg-white border-slate-100 font-bold" required />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">YENİ ŞİFRE (TEKRAR)</label>
              <Input type="password" placeholder="Yeni şifrenizi tekrar girin" className="rounded-2xl h-12 bg-white border-slate-100 font-bold" required />
            </div>
          </div>
          <Button type="submit" className="w-full bg-primary h-14 rounded-2xl font-black text-lg shadow-xl shadow-primary/20">
            <Lock className="w-5 h-5 mr-2" /> Şifreyi Güncelle
          </Button>
        </form>
      </div>
    </div>
  );
}
