"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  ArrowLeft, 
  Loader2, 
  MapPin, 
  Camera, 
  X, 
  CheckCircle2, 
  Sparkles,
  ChevronRight,
  Wallet,
  LayoutGrid,
  Wand2
} from "lucide-react";
import { CATEGORIES } from "@/lib/categories";
import { useFirestore } from "@/firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/context/AuthContext";
import { AuthPanel } from "@/components/AuthPanel";
import { ProfileCompletionDialog } from "@/components/ProfileCompletionDialog";
import { TURKEY_PROVINCES, getDistricts } from "@/lib/turkey-data";
import { generateDescription } from "@/ai/flows/generate-description";

export default function CreateRequest() {
  const router = useRouter();
  const db = useFirestore();
  const { toast } = useToast();
  const { user, profile, isProfileComplete, loading: authLoading } = useAuth();
  
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [isAuthPanelOpen, setIsAuthPanelOpen] = useState(false);
  const [isProfileDialogOpen, setIsProfileDialogOpen] = useState(false);
  
  const [formData, setFormData] = useState({ 
    title: "", 
    description: "", 
    budget: "", 
    mainCategory: "",
    category: "", 
    location: "" 
  });

  const [images, setImages] = useState<string[]>([]);
  const [locationMode, setLocationMode] = useState<"profile" | "manual" | null>(null);
  const [showProvinceList, setShowProvinceList] = useState(false);
  const [showDistrictList, setShowDistrictList] = useState(false);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (!authLoading && !user) setIsAuthPanelOpen(true);
  }, [user, authLoading]);

  const subCategories = useMemo(() => {
    if (!formData.mainCategory) return [];
    return CATEGORIES.find(cat => cat.name === formData.mainCategory)?.subCategories || [];
  }, [formData.mainCategory]);

  const handleAiGenerate = async () => {
    if (!formData.title) {
      toast({ variant: "destructive", title: "Başlık Gereklidir", description: "AI yardımı için önce bir başlık girmelisiniz." });
      return;
    }
    setAiLoading(true);
    try {
      const suggestedText = await generateDescription({ title: formData.title });
      setFormData(prev => ({ ...prev, description: suggestedText }));
      toast({ title: "AI Hazırladı!", description: "Açıklama metni otomatik oluşturuldu." });
    } catch (e) {
      toast({ variant: "destructive", title: "Hata", description: "AI şu an yanıt vermiyor." });
    } finally {
      setAiLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    if (images.length + files.length > 3) {
      toast({ variant: "destructive", title: "Sınır Aşıldı", description: "En fazla 3 görsel yükleyebilirsiniz." });
      return;
    }
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) { setIsAuthPanelOpen(true); return; }
    if (!isProfileComplete()) { setIsProfileDialogOpen(true); return; }
    if (!formData.title || !formData.category || !formData.location || !formData.description) {
      toast({ variant: "destructive", title: "Eksik Bilgi", description: "Lütfen tüm zorunlu alanları doldurun." });
      return;
    }

    setLoading(true);
    try {
      const finalData = {
        ...formData,
        images: images,
        offerCount: 0,
        createdAt: serverTimestamp(),
        status: "pending",
        userId: user.uid,
        user: {
          uid: user.uid,
          name: `${profile?.isim} ${profile?.soyadı}`,
          avatar: profile?.avatar || `https://picsum.photos/seed/${user.uid}/100/100`,
          createdAt: profile?.["oluşturulma tarihi"] || new Date().toISOString()
        }
      };
      await addDoc(collection(db!, "requests"), finalData);
      toast({ title: "Talebiniz Alındı!", description: "Güvenlik kontrolünden sonra yayına alınacaktır." });
      router.push('/profile/history');
    } catch (error) { 
      toast({ variant: "destructive", title: "Hata!", description: "Sistemde bir sorun oluştu." }); 
    } finally { 
      setLoading(false); 
    }
  };

  if (showProvinceList || showDistrictList) {
    const list = showProvinceList ? TURKEY_PROVINCES : getDistricts(selectedProvince);
    return (
      <div className="max-w-md mx-auto bg-white min-h-screen p-6">
        <header className="flex items-center gap-4 mb-6">
          <button onClick={() => { setShowProvinceList(false); setShowDistrictList(false); }} className="p-2 bg-slate-50 rounded-xl"><ArrowLeft className="w-5 h-5" /></button>
          <h1 className="font-black uppercase text-sm">{showProvinceList ? "Şehir Seç" : "İlçe Seç"}</h1>
        </header>
        <Input 
          placeholder="Ara..." 
          className="h-12 bg-slate-50 border-none rounded-2xl mb-4 font-bold"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-2 custom-scrollbar">
          {list.filter(i => i.toLowerCase().includes(searchTerm.toLowerCase())).map(item => (
            <button key={item} onClick={() => showProvinceList ? (setSelectedProvince(item), setShowProvinceList(false), setShowDistrictList(true)) : (setFormData({ ...formData, location: `${selectedProvince} / ${item}` }), setLocationMode("manual"), setShowDistrictList(false))} className="w-full p-5 bg-slate-50 hover:bg-primary/5 rounded-2xl text-left font-bold transition-all">{item}</button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-6 pt-8 pb-4 border-b border-slate-50">
        <div className="flex items-center gap-4">
          <button onClick={() => router.back()} className="p-2.5 bg-slate-50 rounded-full"><ArrowLeft className="w-5 h-5" /></button>
          <div>
            <h1 className="text-2xl font-black tracking-tighter uppercase">Talep Oluştur</h1>
            <p className="text-[10px] font-black text-primary uppercase tracking-[0.2em] mt-1">GÜVENLİ TİCARET ADIMI</p>
          </div>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="px-6 py-8 space-y-10 pb-32">
        <section className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">1</div>
            <Label className="text-xs font-black uppercase tracking-widest text-slate-400">İLAN BAŞLIĞI</Label>
          </div>
          <Input 
            placeholder="Örn: Ev boyama işi arıyorum" 
            className="h-14 rounded-2xl bg-slate-50 border-none font-bold text-lg focus-visible:ring-primary"
            required
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
          />
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">2</div>
              <Label className="text-xs font-black uppercase tracking-widest text-slate-400">GÖRSELLER (OPSİYONEL)</Label>
            </div>
            <span className="text-[10px] font-bold text-slate-300">{images.length}/3</span>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {images.map((img, idx) => (
              <div key={idx} className="relative aspect-square rounded-2xl overflow-hidden group">
                <img src={img} className="w-full h-full object-cover" alt="" />
                <button type="button" onClick={() => removeImage(idx)} className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full backdrop-blur-md"><X className="w-3 h-3" /></button>
              </div>
            ))}
            {images.length < 3 && (
              <label className="aspect-square rounded-2xl border-2 border-dashed border-slate-100 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50">
                <Camera className="w-6 h-6 text-slate-300" />
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} multiple />
              </label>
            )}
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">3</div>
              <Label className="text-xs font-black uppercase tracking-widest text-slate-400">DETAYLI AÇIKLAMA</Label>
            </div>
            <button 
              type="button" 
              onClick={handleAiGenerate}
              disabled={aiLoading || !formData.title}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-full hover:bg-indigo-100 transition-colors disabled:opacity-50"
            >
              {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
              <span className="text-[9px] font-black uppercase tracking-widest">AI ile Yaz</span>
            </button>
          </div>
          <Textarea 
            placeholder="İhtiyacınızı detaylı şekilde açıklayın..." 
            className="min-h-[160px] rounded-2xl bg-slate-50 border-none font-medium p-5 text-base resize-none focus-visible:ring-primary"
            required
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
          />
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">4</div>
            <Label className="text-xs font-black uppercase tracking-widest text-slate-400">BÜTÇE (OPSİYONEL)</Label>
          </div>
          <div className="relative">
            <Wallet className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input 
              type="number" 
              placeholder="Örn: 5000" 
              className="h-14 pl-14 rounded-2xl bg-slate-50 border-none font-black text-lg focus-visible:ring-primary"
              value={formData.budget}
              onChange={(e) => setFormData({...formData, budget: e.target.value})}
            />
            <span className="absolute right-5 top-1/2 -translate-y-1/2 font-black text-slate-300">TL</span>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">5</div>
            <Label className="text-xs font-black uppercase tracking-widest text-slate-400">KATEGORİ SEÇİMİ</Label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {CATEGORIES.map(cat => (
              <button key={cat.id} type="button" onClick={() => setFormData({...formData, mainCategory: cat.name, category: ""})} className={`p-4 rounded-2xl border-2 transition-all text-center ${formData.mainCategory === cat.name ? 'border-primary bg-primary/5' : 'border-slate-50 bg-slate-50'}`}>
                <LayoutGrid className={`w-5 h-5 mx-auto mb-2 ${formData.mainCategory === cat.name ? 'text-primary' : 'text-slate-400'}`} />
                <span className="text-[10px] font-black uppercase block">{cat.name}</span>
              </button>
            ))}
          </div>
          {formData.mainCategory && (
            <div className="mt-4 animate-in fade-in slide-in-from-top-2">
              <Label className="text-[9px] font-black uppercase text-slate-300 ml-1 mb-2 block">HİZMET TÜRÜ</Label>
              <div className="grid grid-cols-1 gap-2">
                {subCategories.map(sub => (
                  <button key={sub.id} type="button" onClick={() => setFormData({...formData, category: sub.name})} className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${formData.category === sub.name ? 'border-primary bg-primary/5' : 'border-slate-50 bg-white'}`}>
                    <span className="text-xs font-bold text-slate-700">{sub.name}</span>
                    {formData.category === sub.name && <CheckCircle2 className="w-4 h-4 text-primary" />}
                  </button>
                ))}
              </div>
            </div>
          )}
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white font-black text-xs">6</div>
            <Label className="text-xs font-black uppercase tracking-widest text-slate-400">KONUM BELİRLE</Label>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => { if (profile?.şehir) { setLocationMode("profile"); setFormData({ ...formData, location: `${profile.şehir} / ${profile.ilçe || ""}`.trim() }); } else { setIsProfileDialogOpen(true); } }} className={`flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all ${locationMode === 'profile' ? 'border-primary bg-primary/5' : 'bg-slate-50 border-slate-50'}`}>
              <MapPin className={`w-5 h-5 mb-2 ${locationMode === 'profile' ? 'text-primary' : 'text-slate-400'}`} />
              <span className="text-[10px] font-black uppercase">Profil Konumu</span>
            </button>
            <button type="button" onClick={() => setShowProvinceList(true)} className={`flex flex-col items-center justify-center p-5 rounded-2xl border-2 transition-all ${locationMode === 'manual' ? 'border-primary bg-primary/5' : 'bg-slate-50 border-slate-50'}`}>
              <Sparkles className={`w-5 h-5 mb-2 ${locationMode === 'manual' ? 'text-primary' : 'text-slate-400'}`} />
              <span className="text-[10px] font-black uppercase">Yeni Konum</span>
            </button>
          </div>
          {formData.location && <div className="p-4 bg-emerald-50 rounded-2xl flex items-center gap-3 border border-emerald-100 mt-2"><CheckCircle2 className="w-5 h-5 text-emerald-600" /><span className="text-sm font-black text-emerald-800 uppercase">{formData.location}</span></div>}
        </section>

        <Button type="submit" disabled={loading} className="w-full bg-primary hover:bg-primary/90 text-white font-black h-16 rounded-[2rem] border-none shadow-2xl mt-10 text-lg transition-all">
          {loading ? <Loader2 className="animate-spin" /> : "TALEBİ YAYINLA"}
        </Button>
      </form>

      <AuthPanel isOpen={isAuthPanelOpen} onClose={() => setIsAuthPanelOpen(false)} />
      <ProfileCompletionDialog isOpen={isProfileDialogOpen} onClose={() => setIsProfileDialogOpen(false)} />
    </div>
  );
}
