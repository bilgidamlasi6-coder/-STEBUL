"use client";

import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/context/AuthContext";
import { useFirestore } from "@/firebase";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { MessageSquare, ChevronRight, Loader2, ArrowLeft, Clock, AlertCircle } from "lucide-react";
import { useRouter } from "next/navigation";
import { RelativeTime } from "@/components/RelativeTime";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function ChatsPage() {
  const { user, loading: authLoading } = useAuth();
  const db = useFirestore();
  const router = useRouter();
  
  const [chats, setChats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const chatsQuery = useMemo(() => {
    if (!db || !user?.uid) return null;
    try {
      return query(
        collection(db, "chats"),
        where("participants", "array-contains", user.uid),
        orderBy("updatedAt", "desc")
      );
    } catch (e) {
      console.error("Query creation error:", e);
      return null;
    }
  }, [db, user?.uid]);

  useEffect(() => {
    // Auth yüklenirken bekle
    if (authLoading) return;

    // Kullanıcı yoksa loading bitir
    if (!user) {
      setLoading(false);
      return;
    }

    if (!chatsQuery) {
      setLoading(false);
      return;
    }

    const unsub = onSnapshot(
      chatsQuery, 
      (snap) => {
        setChats(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        setLoading(false);
        setError(null);
      }, 
      (err) => {
        console.error("Chats error:", err);
        setLoading(false);
        
        // Sadece gerçek hatalarda (index eksikliği vb) hata göster
        if (err.code === 'failed-precondition') {
          setError("Veritabanı yapılandırılıyor, lütfen birkaç dakika sonra tekrar deneyin.");
        } else if (err.code === 'permission-denied') {
          setError("Bu mesajları görme yetkiniz bulunmuyor.");
        } else {
          setError("Mesaj listesi şu an alınamıyor.");
        }
      }
    );

    return () => unsub();
  }, [chatsQuery, authLoading, user]);

  if (loading || authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  if (error && chats.length === 0) {
    return (
      <div className="max-w-md mx-auto min-h-screen flex flex-col items-center justify-center p-10 text-center bg-slate-50">
        <AlertCircle className="w-12 h-12 text-amber-500 mb-4" />
        <p className="text-slate-600 font-bold mb-6 text-sm">{error}</p>
        <Button onClick={() => window.location.reload()} className="bg-primary text-white rounded-xl h-12 px-8 font-black uppercase text-[10px] tracking-widest">Tekrar Dene</Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen">
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md px-6 pt-8 pb-4 border-b border-slate-50">
        <div className="flex items-center gap-3">
          <button onClick={() => router.back()} className="p-2 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors">
            <ArrowLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h1 className="text-xl font-black text-slate-900 tracking-tight uppercase">Mesajlar</h1>
            <p className="text-slate-400 font-bold text-[9px] uppercase tracking-widest mt-1">Görüşmelerim</p>
          </div>
        </div>
      </header>

      <div className="px-6 py-4 space-y-3 pb-24">
        {chats.length > 0 ? chats.map((chat) => (
          <Link key={chat.id} href={`/chats/${chat.id}`}>
            <div className="flex items-center p-4 bg-white border border-slate-100 rounded-3xl hover:border-primary hover:shadow-sm transition-all active:scale-[0.98] group">
              <div className="w-12 h-12 bg-primary/5 rounded-2xl flex items-center justify-center shrink-0">
                <MessageSquare className="w-6 h-6 text-primary" />
              </div>
              <div className="ml-4 flex-1 min-w-0">
                <p className="text-[10px] font-black text-primary uppercase tracking-widest truncate">{chat.requestTitle}</p>
                <p className="text-xs font-bold text-slate-900 line-clamp-1 mt-0.5">{chat.lastMessage}</p>
                <div className="flex items-center gap-1.5 mt-1.5 text-[8px] font-black text-slate-300 uppercase">
                  <Clock className="w-2.5 h-2.5" />
                  <RelativeTime date={chat.updatedAt} />
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-primary ml-2" />
            </div>
          </Link>
        )) : (
          <div className="py-20 text-center bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-100">
            <MessageSquare className="w-12 h-12 text-slate-200 mx-auto mb-4" />
            <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest">Henüz mesajınız yok.</p>
          </div>
        )}
      </div>
    </div>
  );
}
