
"use client";

import { useState, useMemo } from "react";
import { useRouter } from "next/navigation";
import { 
  ArrowLeft, 
  Search,
  Truck,
  Wrench,
  Hammer,
  Briefcase,
  CarFront,
  House,
  Wheat,
  HeartPulse,
  Laptop,
  ClipboardList,
  LucideIcon,
  ChevronRight
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { CATEGORIES } from "@/lib/categories";
import Link from "next/link";

const ICON_MAP: Record<string, LucideIcon> = {
  Truck,
  Wrench,
  Hammer,
  Briefcase,
  CarFront,
  House,
  Wheat,
  HeartPulse,
  Laptop,
  ClipboardList
};

export default function AllCategoriesPage() {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCategories = useMemo(() => {
    if (!searchTerm) return CATEGORIES;
    const term = searchTerm.toLocaleLowerCase("tr");
    return CATEGORIES.filter(cat => 
      cat.name.toLocaleLowerCase("tr").includes(term) ||
      cat.subCategories.some(sub => sub.name.toLocaleLowerCase("tr").includes(term))
    );
  }, [searchTerm]);

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto">
      {/* COMPACT STICKY HEADER */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm px-6 pt-8 pb-3 border-b border-slate-50">
        <div className="flex items-center gap-4 mb-4">
          <button 
            onClick={() => router.back()} 
            className="p-2.5 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-slate-900" />
          </button>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight leading-none">Kategoriler</h1>
            <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mt-1">
              İHTİYACINIZI SEÇİN
            </p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <Input 
            placeholder="Kategori veya hizmet ara..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 h-11 bg-slate-50 border-none rounded-2xl focus-visible:ring-primary text-sm font-medium"
          />
        </div>
      </header>

      {/* CATEGORY LIST */}
      <div className="px-6 py-6 space-y-4 pb-24">
        <div className="grid grid-cols-2 gap-3">
          {filteredCategories.map((cat) => {
            const IconComponent = ICON_MAP[cat.iconName];
            return (
              <Link key={cat.id} href={`/categories/${cat.slug}`}>
                <div className="flex flex-col bg-white border border-slate-100 p-5 rounded-[2rem] text-center shadow-sm hover:border-primary hover:shadow-md transition-all group h-full">
                  <div className="bg-slate-50 w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-primary/5 transition-colors">
                    {IconComponent && <IconComponent className="w-7 h-7 text-primary" />}
                  </div>
                  <span className="text-[11px] font-black text-slate-800 uppercase tracking-tight leading-tight group-hover:text-primary transition-colors">
                    {cat.name}
                  </span>
                  <p className="text-[9px] font-bold text-slate-400 mt-2">
                    {cat.subCategories.length} Hizmet
                  </p>
                </div>
              </Link>
            );
          })}
        </div>

        {filteredCategories.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-slate-300 font-black uppercase text-xs tracking-widest">Sonuç bulunamadı.</p>
          </div>
        )}

        {/* CTA SECTION */}
        <div className="mt-8 p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 text-center">
          <p className="text-slate-500 font-medium text-sm mb-4">Aradığınız kategori yok mu?</p>
          <button 
            onClick={() => router.push('/create')}
            className="bg-primary hover:bg-primary/90 text-white font-black h-12 rounded-2xl px-8 transition-colors flex items-center justify-center gap-2 mx-auto border-none"
          >
            Özel Talep Oluştur
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
