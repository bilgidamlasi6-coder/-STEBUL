
"use client";

import { useState, useMemo } from "react";
import { useParams, useRouter } from "next/navigation";
import { CATEGORIES } from "@/lib/categories";
import { 
  ArrowLeft, 
  ChevronRight, 
  Search,
  Truck,
  Wrench,
  Hammer,
  Briefcase,
  CarFront,
  House,
  Wheat,
  HeartPulse,
  Laptop,
  ClipboardList,
  LucideIcon
} from "lucide-react";
import { Input } from "@/components/ui/input";

const ICON_MAP: Record<string, LucideIcon> = {
  Truck,
  Wrench,
  Hammer,
  Briefcase,
  CarFront,
  House,
  Wheat,
  HeartPulse,
  Laptop,
  ClipboardList
};

export default function CategoryDetail() {
  const { slug } = useParams();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  
  const category = CATEGORIES.find(c => c.slug === slug);

  const filteredSubCategories = useMemo(() => {
    if (!category) return [];
    if (!searchTerm) return category.subCategories;
    const term = searchTerm.toLocaleLowerCase("tr");
    return category.subCategories.filter(sub => 
      sub.name.toLocaleLowerCase("tr").includes(term)
    );
  }, [category, searchTerm]);

  if (!category) {
    return <div className="p-10 text-center font-bold">Kategori bulunamadı.</div>;
  }

  const IconComponent = ICON_MAP[category.iconName];

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto">
      {/* COMPACT STICKY HEADER */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm px-6 pt-8 pb-3 border-b border-slate-50">
        <button 
          onClick={() => router.back()} 
          className="mb-3 p-2.5 bg-slate-50 rounded-full hover:bg-slate-100 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-slate-900" />
        </button>
        
        <div className="flex items-center gap-4 mb-3">
          <div className="w-12 h-12 bg-primary/5 rounded-[1.2rem] flex items-center justify-center shrink-0">
            {IconComponent && <IconComponent className="w-6 h-6 text-primary" />}
          </div>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight leading-none">{category.name}</h1>
            <p className="text-slate-400 font-bold text-[10px] uppercase tracking-widest mt-1">
              {category.subCategories.length} Alt Kategori Mevcut
            </p>
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <Input 
            placeholder={`${category.name} içinde ara...`} 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-12 h-11 bg-slate-50 border-none rounded-2xl focus-visible:ring-primary text-sm font-medium"
          />
        </div>
      </header>

      {/* SCROLLABLE CONTENT */}
      <div className="px-6 py-3 space-y-3 pb-24">
        {filteredSubCategories.length > 0 ? filteredSubCategories.map((sub) => (
          <button 
            key={sub.id}
            onClick={() => router.push(`/requests?category=${sub.name}`)}
            className="w-full flex items-center justify-between p-5 bg-white border border-slate-100 rounded-3xl hover:border-primary hover:shadow-sm transition-all group"
          >
            <span className="font-bold text-slate-700 group-hover:text-primary transition-colors">{sub.name}</span>
            <div className="bg-slate-50 p-2 rounded-xl group-hover:bg-primary/10 transition-colors">
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-primary" />
            </div>
          </button>
        )) : (
          <div className="py-20 text-center">
            <p className="text-slate-300 font-black uppercase text-xs tracking-widest">Hizmet bulunamadı.</p>
          </div>
        )}

        <div className="mt-8 p-8 bg-slate-50 rounded-[2.5rem] border border-slate-100 text-center">
          <p className="text-slate-500 font-medium text-sm mb-4">Aradığınızı bulamadınız mı?</p>
          <button 
            onClick={() => router.push('/create')}
            className="bg-primary hover:bg-primary/90 text-white font-black h-12 rounded-2xl px-8 transition-colors"
          >
            Hemen Talep Oluştur
          </button>
        </div>
      </div>
    </div>
  );
}
