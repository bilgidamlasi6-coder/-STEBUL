
'use client';

import React, { createContext, useContext, useEffect, useState } from "react";
import { 
  onAuthStateChanged, 
  User as FirebaseUser, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile
} from "firebase/auth";
import { doc, setDoc, onSnapshot } from "firebase/firestore";
import { useAuth as useFirebaseAuth, useFirestore } from "@/firebase";

export interface UserProfile {
  uid: string;
  isim: string;
  soyadı: string;
  "e-posta": string;
  avatar: string;
  rol: 'SUPER_ADMIN' | 'USER';
  "oluşturulma tarihi": string;
  telefon?: string;
  şehir?: string;
  ilçe?: string;
  adres?: string;
}

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (email: string, pass: string, name: string, surname: string) => Promise<void>;
  logout: () => Promise<void>;
  isProfileComplete: () => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const SUPER_ADMIN_EMAIL = "vkaraaslan76@gmail.com";

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const auth = useFirebaseAuth();
  const db = useFirestore();
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // 1. Auth State Listener
  useEffect(() => {
    if (!auth) return;
    const unsubscribeAuth = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      if (!firebaseUser) {
        setProfile(null);
        setLoading(false);
      }
    });
    return () => unsubscribeAuth();
  }, [auth]);

  // 2. Profile Data Listener
  useEffect(() => {
    if (!db || !user) return;

    const userDocRef = doc(db, "kullanıcılar", user.uid);
    const unsubscribeProfile = onSnapshot(userDocRef, (docSnap) => {
      if (docSnap.exists()) {
        setProfile(docSnap.data() as UserProfile);
      } else {
        setProfile(null);
      }
      setLoading(false);
    }, (error) => {
      console.error("Profile listen error:", error);
      setLoading(false);
    });

    return () => unsubscribeProfile();
  }, [db, user]);

  const login = async (email: string, pass: string) => {
    if (!auth) return;
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const register = async (email: string, pass: string, name: string, surname: string) => {
    if (!auth || !db) return;
    const userCredential = await createUserWithEmailAndPassword(auth, email, pass);
    const firebaseUser = userCredential.user;

    await updateProfile(firebaseUser, {
      displayName: `${name} ${surname}`
    });

    const isSuperAdmin = email.trim().toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();

    const initialProfile: UserProfile = {
      uid: firebaseUser.uid,
      isim: name,
      soyadı: surname,
      "e-posta": email,
      avatar: `https://picsum.photos/seed/${firebaseUser.uid}/160/160`,
      rol: isSuperAdmin ? 'SUPER_ADMIN' : 'USER',
      "oluşturulma tarihi": new Date().toISOString(),
    };

    await setDoc(doc(db, "kullanıcılar", firebaseUser.uid), initialProfile);
  };

  const logout = async () => {
    if (!auth) return;
    await signOut(auth);
  };

  const isProfileComplete = () => {
    if (!profile) return false;
    return !!(
      profile.isim && 
      profile.soyadı && 
      profile.telefon && 
      profile.şehir && 
      profile.ilçe
    );
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      login,
      register,
      logout,
      isProfileComplete
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
