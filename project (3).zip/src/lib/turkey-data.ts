
export const TURKEY_PROVINCES = [
  "Adana", "Adıyaman", "Afyonkarahisar", "Ağrı", "Amasya", "Ankara", "Antalya", "Artvin",
  "Aydın", "Balıkesir", "Bilecik", "Bingöl", "Bitlis", "Bolu", "Burdur", "Bursa", "Çanakkale",
  "Çankırı", "Çorum", "Denizli", "Diyarbakır", "Edirne", "Elazığ", "Erzincan", "Erzurum",
  "Eskişehir", "Gaziantep", "Giresun", "Gümüşhane", "Hakkari", "Hatay", "Isparta", "Mersin",
  "İstanbul", "İzmir", "Kars", "Kastamonu", "Kayseri", "Kırklareli", "Kırşehir", "Kocaeli",
  "Konya", "Kütahya", "Malatya", "Manisa", "Kahramanmaraş", "Mardin", "Muğla", "Muş",
  "Nevşehir", "Niğde", "Ordu", "Rize", "Sakarya", "Samsun", "Siirt", "Sinop", "Sivas",
  "Tekirdağ", "Tokat", "Trabzon", "Tunceli", "Şanlıurfa", "Uşak", "Van", "Yozgat", "Zonguldak",
  "Aksaray", "Bayburt", "Karaman", "Kırıkkale", "Batman", "Şırnak", "Bartın", "Ardahan",
  "Iğdır", "Yalova", "Karabük", "Kilis", "Osmaniye", "Düzce"
].sort((a, b) => a.localeCompare(b, 'tr'));

export const TURKEY_DISTRICTS: Record<string, string[]> = {
  "Adana": ["Aladağ", "Ceyhan", "Çukurova", "Feke", "İmamoğlu", "Karaisalı", "Karataş", "Kozan", "Pozantı", "Saimbeyli", "Sarıçam", "Seyhan", "Tufanbeyli", "Yumurtalık", "Yüreğir"],
  "Adıyaman": ["Besni", "Çelikhan", "Gerger", "Gölbaşı", "Kahta", "Merkez", "Samsat", "Sincik", "Tut"],
  "Afyonkarahisar": ["Başmakçı", "Bayat", "Bolvadin", "Çay", "Çobanlar", "Dazkırı", "Dinar", "Emirdağ", "Evciler", "Hocalar", "İhsaniye", "İscehisar", "Kızılören", "Merkez", "Sandıklı", "Sinanpaşa", "Sultandağı", "Şuhut"],
  "Ağrı": ["Diyadin", "Doğubayazıt", "Eleşkirt", "Hamur", "Merkez", "Patnos", "Taşlıçay", "Tutak"],
  "Amasya": ["Göynücek", "Gümüşhacıköy", "Hamamözü", "Merkez", "Merzifon", "Suluova", "Taşova"],
  "Ankara": ["Akyurt", "Altındağ", "Ayaş", "Bala", "Beypazarı", "Çamlıdere", "Çankaya", "Çubuk", "Elmadağ", "Etimesgut", "Evren", "Gölbaşı", "Güdül", "Haymana", "Kahramankazan", "Kalecik", "Keçiören", "Kızılcahamam", "Mamak", "Nallıhan", "Polatlı", "Pursaklar", "Sincan", "Şereflikoçhisar", "Yenimahalle"],
  "Antalya": ["Akseki", "Aksu", "Alanya", "Demre", "Döşemealtı", "Elmalı", "Finike", "Gazipaşa", "Gündoğmuş", "İbradı", "Kaş", "Kemer", "Kepez", "Konyaaltı", "Korkuteli", "Kumluca", "Manavgat", "Muratpaşa", "Serik"],
  "Artvin": ["Ardanuç", "Arhavi", "Borçka", "Hopa", "Kemalpaşa", "Merkez", "Murgul", "Şavşat", "Yusufeli"],
  "Aydın": ["Bozdoğan", "Buharkent", "Çine", "Didim", "Efeler", "Germencik", "İncirliova", "Karacasu", "Karpuzlu", "Koçarlı", "Köşk", "Kuşadası", "Kuyucak", "Nazilli", "Söke", "Sultanhisar", "Yenipazar"],
  "Balıkesir": ["Altıeylül", "Ayvalık", "Balya", "Bandırma", "Bigadiç", "Burhaniye", "Dursunbey", "Edremit", "Erdek", "Gömeç", "Gönen", "Havran", "İvrindi", "Karesi", "Kepsut", "Manyas", "Marmara", "Savaştepe", "Sındırgı", "Susurluk"],
  "Bilecik": ["Bozüyük", "Gölpazarı", "İnhisar", "Merkez", "Osmaneli", "Pazaryeri", "Söğüt", "Yenipazar"],
  "Bingöl": ["Adaklı", "Genç", "Karlıova", "Kiğı", "Merkez", "Solhan", "Yayladere", "Yedisu"],
  "Bitlis": ["Adilcevaz", "Ahlat", "Güroymak", "Hizan", "Merkez", "Mutki", "Tatvan"],
  "Bolu": ["Dörtdivan", "Gerede", "Göynük", "Kıbrıscık", "Mengen", "Merkez", "Mudurnu", "Seben", "Yeniçağa"],
  "Burdur": ["Ağlasun", "Altınyayla", "Bucak", "Çavdır", "Çeltikçi", "Gölhisar", "Karamanlı", "Kemer", "Merkez", "Tefenni", "Yeşilova"],
  "Bursa": ["Büyükorhan", "Gemlik", "Gürsu", "Harmancık", "İnegöl", "İznik", "Karacabey", "Keles", "Kestel", "Mudanya", "Mustafakemalpaşa", "Nilüfer", "Orhaneli", "Orhangazi", "Osmangazi", "Yenişehir", "Yıldırım"],
  "Çanakkale": ["Ayvacık", "Bayramiç", "Biga", "Bozcaada", "Çan", "Eceabat", "Ezine", "Gelibolu", "Gökçeada", "Lapseki", "Merkez", "Yenice"],
  "Çankırı": ["Atkaracalar", "Bayramören", "Çerkeş", "Eldivan", "Ilgaz", "Kızılırmak", "Korgun", "Kurşunlu", "Merkez", "Orta", "Şabanözü", "Yapraklı"],
  "Çorum": ["Alaca", "Bayat", "Boğazkale", "Dodurga", "İskilip", "Kargı", "Laçin", "Mecitözü", "Merkez", "Oğuzlar", "Ortaköy", "Osmancık", "Sungurlu", "Uğurludağ"],
  "Denizli": ["Acıpayam", "Babadağ", "Baklan", "Bekilli", "Beyağaç", "Bozkurt", "Buldan", "Çal", "Çameli", "Çardak", "Çivril", "Güney", "Honaz", "Kale", "Merkezefendi", "Pamukkale", "Sarayköy", "Serinhisar", "Tavas"],
  "Diyarbakır": ["Bağlar", "Bismil", "Çermik", "Çınar", "Çüngüş", "Dicle", "Eğil", "Ergani", "Hani", "Hazro", "Kayapınar", "Kocaköy", "Kulp", "Lice", "Silvan", "Sur", "Yenişehir"],
  "Edirne": ["Enez", "Havsa", "İpsala", "Keşan", "Lalapaşa", "Meriç", "Merkez", "Süloğlu", "Uzunköprü"],
  "Elazığ": ["Ağın", "Alacakaya", "Arıcak", "Baskil", "Karakoçan", "Keban", "Kovancılar", "Maden", "Merkez", "Palu", "Sivrice"],
  "Erzincan": ["Çayırlı", "İliç", "Kemah", "Kemaliye", "Merkez", "Otlukbeli", "Refahiye", "Tercan", "Üzümlü"],
  "Erzurum": ["Aşkale", "Aziziye", "Çat", "Hınıs", "Horasan", "İspir", "Karaçoban", "Karayazı", "Köprüköy", "Narman", "Oltu", "Olur", "Palandöken", "Pasinler", "Pazaryolu", "Şenkaya", "Tekman", "Tortum", "Uzundere", "Yakutiye"],
  "Eskişehir": ["Alpu", "Beylikova", "Çifteler", "Günyüzü", "Han", "İnönü", "Mahmudiye", "Mihalgazi", "Mihalıççık", "Odunpazarı", "Sarıcakaya", "Seyitgazi", "Sivrihisar", "Tepebaşı"],
  "Gaziantep": ["Araban", "İslahiye", "Karkamış", "Nizip", "Nurdağı", "Oğuzeli", "Şahinbey", "Şehitkamil", "Yavuzeli"],
  "Giresun": ["Alucra", "Bulancak", "Çamoluk", "Çanakçı", "Dereli", "Doğankent", "Espiye", "Eynesil", "Görele", "Güce", "Keşap", "Merkez", "Piraziz", "Şebinkarahisar", "Tirebolu", "Yağlıdere"],
  "Gümüşhane": ["Kelkit", "Köse", "Kürtün", "Merkez", "Şiran", "Torul"],
  "Hakkari": ["Çukurca", "Derecik", "Merkez", "Şemdinli", "Yüksekova"],
  "Hatay": ["Altınözü", "Antakya", "Arsuz", "Belen", "Defne", "Dörtyol", "Erzin", "Hassa", "İskenderun", "Kırıkhan", "Kumlu", "Payas", "Reyhanlı", "Samandağ", "Yayladağı"],
  "Isparta": ["Aksu", "Atabey", "Eğirdir", "Gelendost", "Gönen", "Keçiborlu", "Merkez", "Senirkent", "Sütçüler", "Şarkikaraağaç", "Uluborlu", "Yalvaç", "Yenişarbademli"],
  "Mersin": ["Akdeniz", "Anamur", "Aydıncık", "Bozyazı", "Çamlıyayla", "Erdemli", "Gülnar", "Mezitli", "Mut", "Silifke", "Tarsus", "Toroslar", "Yenişehir"],
  "İstanbul": ["Adalar", "Arnavutköy", "Ataşehir", "Avcılar", "Bağcılar", "Bahçelievler", "Bakırköy", "Başakşehir", "Bayrampaşa", "Beşiktaş", "Beykoz", "Beylikdüzü", "Beyoğlu", "Büyükçekmece", "Çatalca", "Çekmeköy", "Esenler", "Esenyurt", "Eyüpsultan", "Fatih", "Gaziosmanpaşa", "Güngören", "Kadıköy", "Kağıthane", "Kartal", "Küçükçekmece", "Maltepe", "Pendik", "Sancaktepe", "Sarıyer", "Silivri", "Sultanbeyli", "Sultangazi", "Şile", "Şişli", "Tuzla", "Ümraniye", "Üsküdar", "Zeytinburnu"],
  "İzmir": ["Aliağa", "Balçova", "Bayındır", "Bayraklı", "Bergama", "Beydağ", "Bornova", "Buca", "Çeşme", "Çiğli", "Dikili", "Foça", "Gaziemir", "Güzelbahçe", "Karabağlar", "Karaburun", "Karşıyaka", "Kemalpaşa", "Kınık", "Kiraz", "Konak", "Menderes", "Menemen", "Narlıdere", "Ödemiş", "Seferihisar", "Selçuk", "Tire", "Torbalı", "Urla"],
  "Kars": ["Akyaka", "Arpaçay", "Digor", "Kağızman", "Merkez", "Sarıkamış", "Selim", "Susuz"],
  "Kastamonu": ["Abana", "Ağlı", "Araç", "Azdavay", "Bozkurt", "Cide", "Çatalzeytin", "Daday", "Devrekani", "Doğanyurt", "Hanönü", "İhsangazi", "İnebolu", "Küre", "Merkez", "Pınarbaşı", "Seydiler", "Şenpazar", "Taşköprü", "Tosya"],
  "Kayseri": ["Akkışla", "Bünyan", "Develi", "Felahiye", "Hacılar", "İncesu", "Kocasinan", "Melikgazi", "Özvatan", "Pınarbaşı", "Sarıoğlan", "Sarız", "Talas", "Tomarza", "Yahyalı", "Yeşilhisar"],
  "Kırklareli": ["Babaeski", "Demirköy", "Kofçaz", "Lüleburgaz", "Merkez", "Pehlivanköy", "Pınarhisar", "Vize"],
  "Kırşehir": ["Akçakent", "Akpınar", "Boztepe", "Çiçekdağı", "Kaman", "Merkez", "Mucur"],
  "Kocaeli": ["Başiskele", "Çayırova", "Darica", "Derince", "Dilovası", "Gebze", "Gölcük", "İzmit", "Kandıra", "Karamürsel", "Kartepe", "Körfez"],
  "Konya": ["Ahırlı", "Akören", "Akşehir", "Altınekin", "Beyşehir", "Bozkır", "Cihanbeyli", "Çeltik", "Çumra", "Derbent", "Derebucak", "Doğanhisar", "Emirgazi", "Ereğli", "Güneysınır", "Hadim", "Halkapınar", "Hüyük", "Ilgın", "Kadınhanı", "Karapınar", "Karatay", "Kulu", "Meram", "Sarayönü", "Selçuklu", "Seydişehir", "Taşkent", "Tuzlukçu", "Yalıhüyük", "Yunak"],
  "Kütahya": ["Altıntaş", "Aslanapa", "Çavdarhisar", "Domaniç", "Dumlupınar", "Emet", "Gediz", "Hisarcık", "Merkez", "Pazarlar", "Simav", "Şaphane", "Tavşanlı"],
  "Malatya": ["Akçadağ", "Arapgir", "Arguvan", "Battalgazi", "Darende", "Doğanşehir", "Doğanyol", "Hekimhan", "Kale", "Kuluncak", "Pütürge", "Yazıhan", "Yeşilyurt"],
  "Manisa": ["Ahmetli", "Akhisar", "Alaşehir", "Demirci", "Gölmarmara", "Gördes", "Kırkağaç", "Köprübaşı", "Kula", "Salihli", "Sarıgöl", "Saruhanlı", "Selendi", "Soma", "Şehzadeler", "Turgutlu", "Yunusemre"],
  "Kahramanmaraş": ["Afşin", "Andırın", "Çağlayancerit", "Dulkadiroğlu", "Ekinözü", "Elbistan", "Göksun", "Nurhak", "Onikişubat", "Pazarcık", "Türkoğlu"],
  "Mardin": ["Artuklu", "Dargeçit", "Derik", "Kızıltepe", "Mazıdağı", "Midyat", "Nusaybin", "Ömerli", "Savur", "Yeşilli"],
  "Muğla": ["Bodrum", "Dalaman", "Datça", "Fethiye", "Kavaklıdere", "Köyceğiz", "Marmaris", "Menteşe", "Milas", "Ortaca", "Seydikemer", "Ula", "Yatağan"],
  "Muş": ["Bulanık", "Hasköy", "Korkut", "Malazgirt", "Merkez", "Varto"],
  "Nevşehir": ["Acıgöl", "Avanos", "Derinkuyu", "Gülşehir", "Hacıbektaş", "Kozaklı", "Merkez", "Ürgüp"],
  "Niğde": ["Altunhisar", "Bor", "Çamardı", "Çiftlik", "Merkez", "Ulukışla"],
  "Ordu": ["Akkuş", "Altınordu", "Aybastı", "Çamaş", "Çatalpınar", "Çaybaşı", "Fatsa", "Gölköy", "Gülyalı", "Gürgentepe", "İkizce", "Kabadüz", "Kabataş", "Korgan", "Kumru", "Mesudiye", "Perşembe", "Ulubey", "Ünye"],
  "Rize": ["Ardeşen", "Çamlıhemşin", "Çayeli", "Derepazarı", "Fındıklı", "Güneysu", "Hemşin", "İkizdere", "İyidere", "Kalkandere", "Merkez", "Pazar"],
  "Sakarya": ["Adapazarı", "Akyazı", "Arifiye", "Erenler", "Ferizli", "Geyve", "Hendek", "Karapürçek", "Karasu", "Kaynarca", "Kocaali", "Pamukova", "Sapanca", "Serdivan", "Söğütlü", "Taraklı"],
  "Samsun": ["19 Mayıs", "Alaçam", "Asarcık", "Atakum", "Ayvacık", "Bafra", "Canik", "Çarşamba", "Havza", "İlkadım", "Kavak", "Ladik", "Salıpazarı", "Tekkeköy", "Terme", "Vezirköprü", "Yakakent"],
  "Siirt": ["Baykan", "Eruh", "Kurtalan", "Merkez", "Pervari", "Şirvan", "Tillo"],
  "Sinop": ["Ayancık", "Boyabat", "Dikmen", "Durağan", "Erfelek", "Gerze", "Merkez", "Saraydüzü", "Türkeli"],
  "Sivas": ["Akıncılar", "Altınyayla", "Divriği", "Doğanşar", "Gemerek", "Gölova", "Gürün", "Hafik", "İmranlı", "Kangal", "Koyulhisar", "Merkez", "Suşehri", "Şarkışla", "Ulaş", "Yıldızeli", "Zara"],
  "Tekirdağ": ["Çerkezköy", "Çorlu", "Ergene", "Hayrabolu", "Kapaklı", "Malkara", "Marmaraereğlisi", "Muratlı", "Saray", "Süleymanpaşa", "Şarköy"],
  "Tokat": ["Almus", "Artova", "Başçiftlik", "Erbaa", "Merkez", "Niksar", "Pazar", "Reşadiye", "Sulusaray", "Turhal", "Yeşilyurt", "Zile"],
  "Trabzon": ["Akçaabat", "Araklı", "Arsin", "Beşikdüzü", "Çarşıbaşı", "Çaykara", "Dernekpazarı", "Düzköy", "Hayrat", "Köprübaşı", "Maçka", "Of", "Ortahisar", "Sürmene", "Şalpazarı", "Tonya", "Vakfıkebir", "Yomra"],
  "Tunceli": ["Çemişgezek", "Hozat", "Mazgirt", "Merkez", "Nazımiye", "Ovacık", "Pertek", "Pülümür"],
  "Şanlıurfa": ["Akçakale", "Birecik", "Bozova", "Ceylanpınar", "Eyyübiye", "Halfeti", "Haliliye", "Harran", "Hilvan", "Karaköprü", "Siverek", "Suruç", "Viranşehir"],
  "Uşak": ["Banaz", "Eşme", "Karahallı", "Merkez", "Sivaslı", "Ulubey"],
  "Van": ["Bahçesaray", "Başkale", "Çaldıran", "Çatak", "Edremit", "Erciş", "Gevaş", "Gürpınar", "İpekyolu", "Muradiye", "Özalp", "Saray", "Tuşba"],
  "Yozgat": ["Akdağmadeni", "Aydıncık", "Boğazlıyan", "Çandır", "Çayıralan", "Çekerek", "Kadışehri", "Merkez", "Saraykent", "Sarıkaya", "Sorgun", "Şefaatli", "Yenifakılı", "Yerköy"],
  "Zonguldak": ["Alaplı", "Çaycuma", "Devrek", "Gökçebey", "Kilimli", "Kozlu", "Merkez", "Karadeniz Ereğli"],
  "Aksaray": ["Ağaçören", "Eskil", "Gülağaç", "Güzelyurt", "Merkez", "Ortaköy", "Sarıyahşi", "Sultanhanı"],
  "Bayburt": ["Aydıntepe", "Demirözü", "Merkez"],
  "Karaman": ["Ayrancı", "Başyayla", "Ermenek", "Kazımkarabekir", "Merkez", "Sarıveliler"],
  "Kırıkkale": ["Bahşılı", "Balışeyh", "Çelebi", "Delice", "Karakeçili", "Keskin", "Merkez", "Sulakyurt", "Yahşihan"],
  "Batman": ["Beşiri", "Gercüş", "Hasankeyf", "Kozluk", "Merkez", "Sason"],
  "Şırnak": ["Beytüşşebap", "Cizre", "Güçlükonak", "İdil", "Merkez", "Silopi", "Uludere"],
  "Bartın": ["Amasra", "Kurucaşile", "Merkez", "Ulus"],
  "Ardahan": ["Çıldır", "Damal", "Göle", "Hanak", "Merkez", "Posof"],
  "Iğdır": ["Aralık", "Karakoyunlu", "Merkez", "Tuzluca"],
  "Yalova": ["Altınova", "Armutlu", "Çiftlikköy", "Çınarcık", "Merkez", "Termal"],
  "Karabük": ["Eflani", "Eskipazar", "Merkez", "Ovacık", "Safranbolu", "Yenice"],
  "Kilis": ["Elbeyli", "Merkez", "Musabeyli", "Polateli"],
  "Osmaniye": ["Bahçe", "Düziçi", "Hasanbeyli", "Kadirli", "Merkez", "Sumbas", "Toprakkale"],
  "Düzce": ["Akçakoca", "Cumayeri", "Çilimli", "Gölyaka", "Gümüşova", "Kaynaşlı", "Merkez", "Yığılca"]
};

/**
 * Benzersiz Mahalle Yapısı: İl_İlçe kombinasyonu kullanılır.
 * Bu sayede farklı illerdeki aynı isimli ilçelerin (örn: Merkez) mahalleleri çakışmaz.
 */
export const TURKEY_NEIGHBORHOODS: Record<string, string[]> = {
  // İSTANBUL
  "İstanbul_Kadıköy": ["Acıbadem Mah.", "Bostancı Mah.", "Caddebostan Mah.", "Caferağa Mah.", "Dumlupınar Mah.", "Eğitim Mah.", "Erenköy Mah.", "Fenerbahçe Mah.", "Feneryolu Mah.", "Fikirtepe Mah.", "Göztepe Mah.", "Hasanpaşa Mah.", "Koşuyolu Mah.", "Kozyatağı Mah.", "Merdivenköy Mah.", "Osmanağa Mah.", "Rasimpaşa Mah.", "Sahrayıcedit Mah.", "Suadiye Mah.", "Zühtüpaşa Mah."],
  "İstanbul_Arnavutköy": ["Adnan Menderes Mah.", "Anadolu Mah.", "Arnavutköy Merkez Mah.", "Baklalı Mah.", "Boğazköy Mah.", "Bolluca Mah.", "Çilingir Mah.", "Dursunköy Mah.", "Hacımaşlı Mah.", "Hadımköy Mah.", "Haraççı Mah.", "İmrahor Mah.", "İslambey Mah.", "Karaburun Mah.", "Karlıbayır Mah.", "Mavigöl Mah.", "Nenehatun Mah.", "Taşoluk Mah.", "Yeniköy Mah."],
  "İstanbul_Beşiktaş": ["Abbasağa Mah.", "Akat Mah.", "Arnavutköy Mah.", "Balmumcu Mah.", "Bebek Mah.", "Cihannüma Mah.", "Dikilitaş Mah.", "Etiler Mah.", "Gayrettepe Mah.", "Konaklar Mah.", "Kuruçeşme Mah.", "Kültür Mah.", "Levazım Mah.", "Levent Mah.", "Mecidiye Mah.", "Muradiye Mah.", "Nisbetiye Mah.", "Ortaköy Mah.", "Sinanpaşa Mah.", "Türkali Mah.", "Ulus Mah.", "Vişnezade Mah.", "Yıldız Mah."],
  
  // ANKARA
  "Ankara_Çankaya": ["Ahlatlıbel Mah.", "Anıttepe Mah.", "Ayrancı Mah.", "Bahçelievler Mah.", "Balgat Mah.", "Birlik Mah.", "Cebeci Mah.", "Çukurambar Mah.", "Dikmen Mah.", "Emek Mah.", "Esat Mah.", "Gaziosmanpaşa Mah.", "Huzur Mah.", "Kavaklıdere Mah.", "Kırkkonaklar Mah.", "Kızılay Mah.", "Maltepe Mah.", "Mebusevleri Mah.", "Mutlukent Mah.", "Oran Mah.", "Sancak Mah.", "Söğütözü Mah.", "Yıldız Mah."],
  "Ankara_Etimesgut": ["30 Ağustos Mah.", "Alsancak Mah.", "Altay Mah.", "Atakent Mah.", "Bağlıca Mah.", "Bahçekapı Mah.", "Elvan Mah.", "Erler Mah.", "Eryaman Mah.", "Etiler Mah.", "İstasyon Mah.", "Kazım Karabekir Mah.", "Piyade Mah.", "Şeker Mah.", "Topçu Mah.", "Tunahan Mah.", "Yapracık Mah.", "Yeşilova Mah."],
  "Ankara_Ayaş": ["Camiatik Mah.", "Camicedit Mah.", "Dervişimam Mah.", "Emine Tevfika Mah.", "Ferahfaki Mah.", "Hacı Memi Mah.", "Hacı Recep Mah.", "Ömeroğlu Mah.", "Şeyhmuhittin Mah."],
  
  // İZMİR
  "İzmir_Gaziemir": ["Akçay Mah.", "Atatürk Mah.", "Atıfbey Mah.", "Beyazevler Mah.", "Binbaşı Reşatbey Mah.", "Dokuz Eylül Mah.", "Emrez Mah.", "Fatih Mah.", "Gazi Mah.", "Gazikent Mah.", "Hürriyet Mah.", "Irmak Mah.", "Menderes Mah.", "Sarnıç Mah.", "Sevgi Mah.", "Yeşil Mah.", "Zafer Mah."],
  "İzmir_Bornova": ["Atatürk Mah.", "Barbaros Mah.", "Birlik Mah.", "Çamkule Mah.", "Çınar Mah.", "Doğanlar Mah.", "Egemenlik Mah.", "Erzene Mah.", "Evka 3 Mah.", "Evka 4 Mah.", "Işıklar Mah.", "İnönü Mah.", "Karacaoğlan Mah.", "Kazımdirik Mah.", "Kızılay Mah.", "Mevlana Mah.", "Naldöken Mah.", "Rafet Paşa Mah.", "Tuna Mah.", "Yeşilova Mah."],
  "İzmir_Konak": ["Akdeniz Mah.", "Alsancak Mah.", "Altay Mah.", "Atilla Mah.", "Barbaros Mah.", "Boğaziçi Mah.", "Çankaya Mah.", "Ege Mah.", "Göztepe Mah.", "Gültepe Mah.", "Güneşli Mah.", "Huzur Mah.", "Kahramanlar Mah.", "Kültür Mah.", "Mehtap Mah.", "Mithatpaşa Mah.", "Murat Mah.", "Piri Reis Mah.", "Turgut Reis Mah.", "Yeni Mah."],

  // ADANA
  "Adana_Seyhan": ["Aydınlar Mah.", "Baraj Mah.", "Beşocak Mah.", "Bey Mah.", "Cemalpaşa Mah.", "Çınarlı Mah.", "Döşeme Mah.", "Gazipaşa Mah.", "Gülbahçesi Mah.", "Gürselpaşa Mah.", "Kurtuluş Mah.", "Mestanzade Mah.", "Namık Kemal Mah.", "Onur Mah.", "Pınar Mah.", "Reşatbey Mah.", "Sakarya Mah.", "Sümer Mah.", "Yeşiloba Mah.", "Ziyapaşa Mah."],
  "Adana_Çukurova": ["Belediyeevleri Mah.", "Beyazevler Mah.", "Güzelyalı Mah.", "Huzurevleri Mah.", "Karslılar Mah.", "Kurttepe Mah.", "Mahfesığmaz Mah.", "Piri Reis Mah.", "Toros Mah.", "Yurt Mah.", "Yüzüncüyıl Mah."],

  // KONYA
  "Konya_Selçuklu": ["Akademi Mah.", "Aydınlıkevler Mah.", "Bosna Hersek Mah.", "Buhara Mah.", "Cumhuriyet Mah.", "Dumlupınar Mah.", "Erenköy Mah.", "Feritpaşa Mah.", "Hacıkaymak Mah.", "Işıklar Mah.", "İhsaniye Mah.", "Kılıçarslan Mah.", "Kosova Mah.", "Musalla Bağları Mah.", "Nişantaşı Mah.", "Parsana Mah.", "Sancak Mah.", "Şeker Mah.", "Yazır Mah."],
  "Konya_Meram": ["Alpaslan Mah.", "Ateşbaz Veli Mah.", "Ayanbey Mah.", "Çaybaşı Mah.", "Dere Mah.", "Gödene Mah.", "Harmancık Mah.", "Hasanköy Mah.", "Kalfalar Mah.", "Konyar Mah.", "Köyceğiz Mah.", "Lalebahçe Mah.", "Melikşah Mah.", "Turgut Reis Mah.", "Uluırmak Mah.", "Yaka Mah."],

  // HATAY
  "Hatay_Antakya": ["Akevler Mah.", "Aksaray Mah.", "Bağrıyanık Mah.", "Cebrail Mah.", "Cumhuriyet Mah.", "Dutdibi Mah.", "Emek Mah.", "Esentepe Mah.", "Gazi Mah.", "Habibi Neccar Mah.", "Kışlasaray Mah.", "Kuyulu Mah.", "Odabaşı Mah.", "Saraykent Mah.", "Ürgenpaşa Mah."],
  "Hatay_İskenderun": ["Barbaros Mah.", "Buluttepe Mah.", "Cumhuriyet Mah.", "Çay Mah.", "Dumlupınar Mah.", "Esentepe Mah.", "Gürsel Mah.", "İsmet Paşa Mah.", "Kocatepe Mah.", "Meydan Mah.", "Modern Evler Mah.", "Muradiye Mah.", "Numune Mah.", "Piri Reis Mah.", "Savaş Mah.", "Süleymaniye Mah.", "Yenişehir Mah."],

  // MARDİN
  "Mardin_Artuklu": ["13 Mart Mah.", "İstasyon Mah.", "Kabala Mah.", "Kotek Mah.", "Nur Mah.", "Ortaköy Mah.", "Savurkapı Mah.", "Teker Mah.", "Yenişehir Mah."],
  "Mardin_Kızıltepe": ["Atatürk Mah.", "Cumhuriyet Mah.", "Dunaysır Mah.", "Ersoylu Mah.", "Fırat Mah.", "İpek Mah.", "Koçhisar Mah.", "Mezopotamya Mah.", "Sanayi Mah.", "Tepebaşı Mah.", "Turgut Özal Mah.", "Yeni Mah."],

  // IĞDIR
  "Iğdır_Merkez": ["14 Kasım Mah.", "Atatürk Mah.", "Bağlar Mah.", "Cumhuriyet Mah.", "Emek Mah.", "Hakmehmet Mah.", "Karaağaç Mah.", "Konaklı Mah.", "Özgür Mah.", "Söğütlü Mah.", "Topçular Mah.", "Yeni Mah."]
};

export function getDistricts(province: string): string[] {
  return TURKEY_DISTRICTS[province] || [];
}

export function getNeighborhoods(province: string, district: string): string[] {
  const key = `${province}_${district}`;
  if (province && district && TURKEY_NEIGHBORHOODS[key]) {
    return TURKEY_NEIGHBORHOODS[key];
  }
  return [];
}
