
export interface Request {
  id: string;
  title: string;
  description: string;
  images?: string[];
  budget: string;
  location: string;
  category: string;
  offerCount: number;
  createdAt: string;
  status: 'active' | 'closed' | 'pending' | 'in_progress' | 'completed' | 'cancelled' | 'inactive' | 'deleted';
  userId?: string;
  user: {
    name: string;
    avatar?: string;
  }
}

export interface Offer {
  id: string;
  requestId: string;
  businessName: string;
  amount: string;
  message: string;
  createdAt: string;
}

// Sahte veriler tamamen temizlendi
export const SAMPLE_REQUESTS: Request[] = [];
export const SAMPLE_OFFERS: Offer[] = [];
