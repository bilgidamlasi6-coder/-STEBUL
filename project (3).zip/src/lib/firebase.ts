
/**
 * ÖNEMLİ: Bu dosya artık kullanılmamalıdır. 
 * Lütfen 'src/firebase' Hook'larını kullanın.
 * Hata oluşmaması için boş export bırakılmıştır.
 */
export const db = null as any;
export const auth = null as any;
export const app = null as any;
