
export interface SubCategory {
  id: string;
  name: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  iconName: string;
  subCategories: SubCategory[];
}

export const CATEGORIES: Category[] = [
  {
    id: 'cat_nakliye',
    name: 'Nakliye & Taşıma',
    slug: 'nakliye-ve-tasima',
    iconName: 'Truck',
    subCategories: [
      { id: 'sub_ev_tasima', name: 'Ev Taşıma' },
      { id: 'sub_ofis_tasima', name: 'Ofis Taşıma' },
      { id: 'sub_sehirler_arasi', name: 'Şehirler Arası Nakliye' },
      { id: 'sub_parca_esya', name: 'Parça Eşya Taşıma' },
      { id: 'sub_kurye', name: 'Kurye' },
      { id: 'sub_moto_kurye', name: 'Moto Kurye' },
      { id: 'sub_yuk_tasima', name: 'Yük Taşıma' },
      { id: 'sub_palet_tasima', name: 'Palet Taşıma' },
      { id: 'sub_asansorlu', name: 'Asansörlü Taşıma' },
      { id: 'sub_depolama', name: 'Depolama Hizmeti' },
    ]
  },
  {
    id: 'cat_teknik',
    name: 'Teknik Servis',
    slug: 'teknik-servis',
    iconName: 'Wrench',
    subCategories: [
      { id: 'sub_tel_tamir', name: 'Telefon Tamiri' },
      { id: 'sub_pc_tamir', name: 'Bilgisayar Tamiri' },
      { id: 'sub_laptop_tamir', name: 'Laptop Tamiri' },
      { id: 'sub_yazici_tamir', name: 'Yazıcı Tamiri' },
      { id: 'sub_beyaz_esya', name: 'Beyaz Eşya Servisi' },
      { id: 'sub_klima', name: 'Klima Servisi' },
      { id: 'sub_elektrikci', name: 'Elektrikçi' },
      { id: 'sub_kamera', name: 'Kamera Sistemleri' },
      { id: 'sub_kart_tamir', name: 'Elektronik Kart Tamiri' },
    ]
  },
  {
    id: 'cat_insaat',
    name: 'İnşaat & Usta',
    slug: 'insaat-ve-usta',
    iconName: 'Hammer',
    subCategories: [
      { id: 'sub_kalip', name: 'Kalıp Ustası' },
      { id: 'sub_duvar', name: 'Duvar Ustası' },
      { id: 'sub_boya', name: 'Boya Badana' },
      { id: 'sub_siva', name: 'Sıva Ustası' },
      { id: 'sub_fayans', name: 'Fayans & Seramik' },
      { id: 'sub_su_tesisat', name: 'Su Tesisatı' },
      { id: 'sub_elek_tesisat', name: 'Elektrik Tesisatı' },
      { id: 'sub_alci', name: 'Alçı & Alçıpan' },
      { id: 'sub_cati', name: 'Çatı İşleri' },
      { id: 'sub_beton', name: 'Beton Dökümü' },
      { id: 'sub_demir', name: 'Demir & Kaynak İşleri' },
      { id: 'sub_iskele', name: 'İskele Kurulumu' },
    ]
  },
  {
    id: 'cat_is',
    name: 'İş & Personel',
    slug: 'is-ve-personel',
    iconName: 'Briefcase',
    subCategories: [
      { id: 'sub_eleman', name: 'Eleman Arıyorum' },
      { id: 'sub_sofor', name: 'Şoför Arıyorum' },
      { id: 'sub_muhasebe', name: 'Muhasebeci Arıyorum' },
      { id: 'sub_satis', name: 'Satış Personeli' },
      { id: 'sub_sekreter', name: 'Sekreter' },
      { id: 'sub_garson', name: 'Garson' },
      { id: 'sub_usta_ara', name: 'Usta Arıyorum' },
      { id: 'sub_kalfa_ara', name: 'Kalfa Arıyorum' },
    ]
  },
  {
    id: 'cat_arac',
    name: 'Araç & Otomotiv',
    slug: 'arac-ve-otomotiv',
    iconName: 'CarFront',
    subCategories: [
      { id: 'sub_kiralama', name: 'Araç Kiralama' },
      { id: 'sub_soforlu', name: 'Şoförlü Araç' },
      { id: 'sub_oto_tamir', name: 'Oto Tamir' },
      { id: 'sub_oto_elektrik', name: 'Oto Elektrik' },
      { id: 'sub_lastik', name: 'Lastik Hizmeti' },
      { id: 'sub_cekici', name: 'Oto Çekici' },
      { id: 'sub_yedek_parca', name: 'Yedek Parça' },
      { id: 'sub_ekspertiz', name: 'Ekspertiz' },
    ]
  },
  {
    id: 'cat_ev',
    name: 'Ev & Yaşam',
    slug: 'ev-ve-yasam',
    iconName: 'House',
    subCategories: [
      { id: 'sub_ev_ara', name: 'Ev Arıyorum' },
      { id: 'sub_kiralik', name: 'Kiralık Daire Arıyorum' },
      { id: 'sub_satilik', name: 'Satılık Ev Arıyorum' },
      { id: 'sub_oda', name: 'Oda Arkadaşı Arıyorum' },
      { id: 'sub_isyeri', name: 'İş Yeri Arıyorum' },
      { id: 'sub_arsa', name: 'Arsa Arıyorum' },
      { id: 'sub_temizlik', name: 'Temizlik Hizmeti' },
      { id: 'sub_tadilat', name: 'Ev Tadilatı' },
      { id: 'sub_mobilya', name: 'Mobilya Montaj' },
      { id: 'sub_perde', name: 'Perde & Stor' },
      { id: 'sub_bahce', name: 'Bahçe Düzenleme' },
      { id: 'sub_cambalkon', name: 'Cam Balkon' },
      { id: 'sub_guvenlik', name: 'Güvenlik Sistemleri' },
      { id: 'sub_tasinma', name: 'Taşınma Yardımı' },
      { id: 'sub_cilingir', name: 'Çilingir Hizmeti' },
    ]
  },
  {
    id: 'cat_gida',
    name: 'Gıda & Tarım',
    slug: 'gida-ve-tarim',
    iconName: 'Wheat',
    subCategories: [
      { id: 'sub_kuruyemis', name: 'Kuruyemiş Alımı' },
      { id: 'sub_kurumeyve', name: 'Kuru Meyve Alımı' },
      { id: 'sub_meyvesebze', name: 'Meyve Sebze Alımı' },
      { id: 'sub_toplugida', name: 'Toplu Gıda Alımı' },
      { id: 'sub_yem', name: 'Hayvan Yemi' },
      { id: 'sub_tarim', name: 'Tarım Ürünleri' },
      { id: 'sub_gubre', name: 'Gübre' },
      { id: 'sub_tohum', name: 'Tohum & Fide' },
    ]
  },
  {
    id: 'cat_saglik',
    name: 'Sağlık & Bakım',
    slug: 'saglik-ve-bakim',
    iconName: 'HeartPulse',
    subCategories: [
      { id: 'sub_hastabakici', name: 'Hasta Bakıcı' },
      { id: 'sub_yaslibakim', name: 'Yaşlı Bakımı' },
      { id: 'sub_cocukbakici', name: 'Çocuk Bakıcısı' },
      { id: 'sub_evdebakim', name: 'Evde Bakım' },
      { id: 'sub_fizik', name: 'Fizik Tedavi' },
      { id: 'sub_psikolog', name: 'Psikolog' },
      { id: 'sub_diyetisyen', name: 'Diyetisyen' },
      { id: 'sub_hemsire', name: 'Hemşire' },
    ]
  },
  {
    id: 'cat_teknoloji',
    name: 'Yazılım & Teknoloji',
    slug: 'yazilim-ve-teknoloji',
    iconName: 'Laptop',
    subCategories: [
      { id: 'sub_web', name: 'Web Sitesi' },
      { id: 'sub_mobil', name: 'Mobil Uygulama' },
      { id: 'sub_eticaret', name: 'E-Ticaret' },
      { id: 'sub_grafik', name: 'Grafik Tasarım' },
      { id: 'sub_sosyalmedya', name: 'Sosyal Medya Yönetimi' },
      { id: 'sub_seo', name: 'SEO Hizmeti' },
      { id: 'sub_hosting', name: 'Hosting' },
      { id: 'sub_teknikdestek', name: 'Teknik Destek' },
    ]
  },
  {
    id: 'cat_diger',
    name: 'Diğer Talepler',
    slug: 'diger-talepler',
    iconName: 'ClipboardList',
    subCategories: [
      { id: 'sub_danismanlik', name: 'Danışmanlık' },
      { id: 'sub_organizasyon', name: 'Organizasyon' },
      { id: 'sub_egitim', name: 'Eğitim Hizmetleri' },
      { id: 'sub_foto', name: 'Fotoğraf & Video' },
      { id: 'sub_ceviri', name: 'Çeviri Hizmeti' },
      { id: 'sub_reklam', name: 'Reklam & Tanıtım' },
      { id: 'sub_diger_hepsi', name: 'Diğer' },
    ]
  }
];
