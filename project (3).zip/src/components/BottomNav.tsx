
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, PlusCircle, Handshake, User } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { label: "Ana Sayfa", icon: Home, href: "/" },
  { label: "Talepler", icon: Search, href: "/requests" },
  { label: "Talep Oluştur", icon: PlusCircle, href: "/create" },
  { label: "Teklifler", icon: Handshake, href: "/offers" },
  { label: "Profil", icon: User, href: "/profile" },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-100 flex items-center justify-around h-16 pb-safe safe-area-inset-bottom shadow-[0_-4px_20px_-12px_rgba(0,0,0,0.08)]">
      {navItems.map((item) => {
        const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
        const Icon = item.icon;
        
        return (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center justify-center w-full h-full transition-all duration-300 relative",
              isActive ? "text-primary scale-110" : "text-slate-400 hover:text-primary"
            )}
          >
            <Icon className={cn("w-6 h-6", isActive && "fill-primary/10")} />
            <span className="text-[10px] mt-1 font-bold">{item.label}</span>
            {isActive && (
              <span className="absolute -top-1 w-12 h-1 bg-primary rounded-full" />
            )}
          </Link>
        );
      })}
    </nav>
  );
}
