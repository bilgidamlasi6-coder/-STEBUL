
'use client';

import { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface RelativeTimeProps {
  date: any;
  className?: string;
}

export function RelativeTime({ date, className }: RelativeTimeProps) {
  const [formatted, setFormatted] = useState<string>('');

  useEffect(() => {
    if (!date) return;
    
    try {
      let d: Date;
      if (typeof date.toDate === 'function') {
        d = date.toDate();
      } else if (date instanceof Date) {
        d = date;
      } else {
        d = new Date(date);
      }
      
      if (!isNaN(d.getTime())) {
        setFormatted(formatDistanceToNow(d, { addSuffix: true, locale: tr }));
      }
    } catch (e) {
      setFormatted('Yeni');
    }
  }, [date]);

  if (!formatted) return <span className={className}>...</span>;

  return <span className={className}>{formatted}</span>;
}
