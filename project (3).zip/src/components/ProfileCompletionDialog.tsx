
"use client";

import React, { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { doc, setDoc } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { MapPin, Phone, User as UserIcon, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProfileCompletionDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProfileCompletionDialog({ isOpen, onClose }: ProfileCompletionDialogProps) {
  const { user, profile } = useAuth();
  const db = useFirestore();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    isim: "",
    soyadı: "",
    telefon: "",
    şehir: "",
    ilçe: "",
    adres: ""
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        isim: profile.isim || "",
        soyadı: profile.soyadı || "",
        telefon: profile.telefon || "",
        şehir: profile.şehir || "",
        ilçe: profile.ilçe || "",
        adres: profile.adres || ""
      });
    }
  }, [profile, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !db) return;
    
    setLoading(true);
    try {
      const userRef = doc(db, "kullanıcılar", user.uid);
      await setDoc(userRef, {
        ...formData,
        uid: user.uid,
        "e-posta": user.email,
        rol: profile?.rol || (user.email === 'vkaraaslan76@gmail.com' ? 'SUPER_ADMIN' : 'USER'),
        "oluşturulma tarihi": profile?.["oluşturulma tarihi"] || new Date().toISOString()
      }, { merge: true });

      toast({
        title: "Bilgiler Kaydedildi",
        description: "Profiliniz başarıyla güncellendi. İşleminize devam edebilirsiniz.",
      });
      onClose();
    } catch (error: any) {
      console.error("Profile Update Error:", error);
      toast({
        variant: "destructive",
        title: "Hata",
        description: "Bilgiler kaydedilirken bir sorun oluştu. Lütfen tekrar deneyin.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white max-h-[90vh] flex flex-col">
        <div className="overflow-y-auto flex-1 px-8 py-10">
          <DialogHeader className="space-y-3 items-center text-center mb-6">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center shrink-0">
              <UserIcon className="w-8 h-8 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-2xl font-black text-slate-900 tracking-tight">Profilini Tamamla</DialogTitle>
              <DialogDescription className="text-slate-400 font-bold text-[10px] uppercase tracking-[0.2em] mt-1">
                GÜVENLİ TİCARET İÇİN BİLGİLERİN GEREKLİ
              </DialogDescription>
            </div>
          </DialogHeader>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">AD</Label>
                <Input 
                  value={formData.isim}
                  onChange={(e) => setFormData({...formData, isim: e.target.value})}
                  required
                  className="h-12 rounded-2xl bg-slate-50 border-none font-bold"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">SOYAD</Label>
                <Input 
                  value={formData.soyadı}
                  onChange={(e) => setFormData({...formData, soyadı: e.target.value})}
                  required
                  className="h-12 rounded-2xl bg-slate-50 border-none font-bold"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">TELEFON</Label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                <Input 
                  placeholder="05XX XXX XX XX"
                  value={formData.telefon}
                  onChange={(e) => setFormData({...formData, telefon: e.target.value})}
                  required
                  className="h-12 pl-11 rounded-2xl bg-slate-50 border-none font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">ŞEHİR</Label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <Input 
                    placeholder="Örn: İstanbul"
                    value={formData.şehir}
                    onChange={(e) => setFormData({...formData, şehir: e.target.value})}
                    required
                    className="h-12 pl-11 rounded-2xl bg-slate-50 border-none font-bold"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">İLÇE</Label>
                <Input 
                  placeholder="Örn: Kadıköy"
                  value={formData.ilçe}
                  onChange={(e) => setFormData({...formData, ilçe: e.target.value})}
                  required
                  className="h-12 rounded-2xl bg-slate-50 border-none font-bold"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">AÇIK ADRES</Label>
              <Input 
                placeholder="Mahalle, Sokak, No..."
                value={formData.adres}
                onChange={(e) => setFormData({...formData, adres: e.target.value})}
                required
                className="h-12 rounded-2xl bg-slate-50 border-none font-bold"
              />
            </div>

            <Button 
              type="submit" 
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 text-white font-black h-14 rounded-2xl shadow-xl shadow-primary/20 transition-all active:scale-95 text-lg mt-4"
            >
              {loading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                "Bilgileri Kaydet"
              )}
            </Button>
            
            <button 
              type="button"
              onClick={onClose}
              className="w-full text-[11px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-600 transition-colors py-2"
            >
              Daha Sonra
            </button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}
