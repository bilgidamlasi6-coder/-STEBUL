'use client';

import Link from "next/link";
import { Wallet, MessageSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Request } from "@/lib/sample-data";

interface RequestCardProps {
  request: Request;
}

export function RequestCard({ request }: RequestCardProps) {
  return (
    <Card className="hover:shadow-sm transition-all duration-300 border border-slate-50 bg-white overflow-hidden group">
      <CardContent className="p-0">
        <Link href={`/requests/${request.id}`} className="block p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              {/* Header: Offer Count only */}
              <div className="flex items-center mb-1.5">
                <div className="flex items-center text-primary text-[9px] font-black uppercase tracking-tight bg-primary/5 px-2 py-0.5 rounded-full">
                  <MessageSquare className="w-2.5 h-2.5 mr-1" />
                  {request.offerCount || 0} Teklif
                </div>
              </div>
              
              {/* Title */}
              <h3 className="text-[14px] font-black text-slate-900 mb-3 line-clamp-2 group-hover:text-primary transition-colors uppercase tracking-tight leading-tight">
                {request.title}
              </h3>
              
              {/* Bottom Info: Only Budget as requested */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center text-[10px] font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-xl">
                  <Wallet className="w-3 h-3 mr-1.5 shrink-0" />
                  <span className="truncate">{request.budget ? `${request.budget} TL` : "Bütçe Belirtilmemiş"}</span>
                </div>
              </div>
            </div>

            {/* Thumbnail Image */}
            {request.images && request.images.length > 0 && (
              <div className="shrink-0">
                <img 
                  src={request.images[0]} 
                  className="w-20 h-20 rounded-2xl object-cover border border-slate-100 shadow-sm" 
                  alt={request.title}
                  loading="lazy"
                />
              </div>
            )}
          </div>
        </Link>
      </CardContent>
    </Card>
  );
}
