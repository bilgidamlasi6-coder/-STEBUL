"use client";

import React, { useState } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Mail, Lock, Eye, EyeOff, ArrowRight, Loader2, X } from "lucide-react";

interface AuthPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthPanel({ isOpen, onClose }: AuthPanelProps) {
  const { login, register } = useAuth();
  const { toast } = useToast();
  
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const [formData, setFormData] = useState({
    name: "",
    surname: "",
    email: "",
    password: "",
    passwordConfirm: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isLoginMode) {
        await login(formData.email, formData.password);
        toast({ title: "Giriş Başarılı", description: "İSTEBUL dünyasına hoş geldiniz!" });
      } else {
        if (formData.password !== formData.passwordConfirm) {
          throw new Error("Şifreler uyuşmuyor.");
        }
        await register(formData.email, formData.password, formData.name, formData.surname);
        toast({ title: "Kayıt Başarılı", description: "Hesabınız başarıyla oluşturuldu." });
      }
      onClose();
    } catch (error: any) {
      toast({ 
        variant: "destructive", 
        title: "Hata", 
        description: error.message || "İşlem başarısız oldu." 
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md rounded-[2.5rem] border-none shadow-2xl p-0 overflow-hidden bg-white max-h-[90vh] flex flex-col">
        <div className="bg-white px-8 pt-10 pb-4 relative shrink-0">
          <button onClick={onClose} className="absolute right-6 top-6 p-2 text-slate-300 hover:text-slate-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="w-16 h-16 bg-primary rounded-[1.5rem] flex items-center justify-center shadow-xl shadow-primary/20">
              <span className="text-white font-black text-4xl italic">İ</span>
            </div>
            <div>
              <DialogTitle className="text-xl font-black text-slate-900 tracking-tight uppercase">
                İSTEBUL DÜNYASINA HOŞ GELDİNİZ
              </DialogTitle>
            </div>
          </div>
        </div>
        
        <div className="overflow-y-auto flex-1 px-8 py-6 custom-scrollbar">
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLoginMode && (
              <div className="grid grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2">
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">AD</Label>
                  <Input 
                    placeholder="Adınız"
                    className="h-12 rounded-xl bg-slate-50 border-none font-bold text-sm"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">SOYAD</Label>
                  <Input 
                    placeholder="Soyadınız"
                    className="h-12 rounded-xl bg-slate-50 border-none font-bold text-sm"
                    required
                    value={formData.surname}
                    onChange={(e) => setFormData({...formData, surname: e.target.value})}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">E-POSTA</Label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                <Input 
                  type="email"
                  placeholder="eposta@istebul.com"
                  className="h-12 pl-12 rounded-xl bg-slate-50 border-none font-bold text-sm"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">ŞİFRE</Label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                <Input 
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  className="h-12 pl-12 pr-12 rounded-xl bg-slate-50 border-none font-bold text-sm"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                />
                <button 
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {!isLoginMode && (
              <div className="space-y-1.5 animate-in fade-in slide-in-from-top-2">
                <Label className="text-[10px] font-black uppercase tracking-widest text-slate-400 ml-1">ŞİFRE TEKRAR</Label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                  <Input 
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    className="h-12 pl-12 rounded-xl bg-slate-50 border-none font-bold text-sm"
                    required
                    value={formData.passwordConfirm}
                    onChange={(e) => setFormData({...formData, passwordConfirm: e.target.value})}
                  />
                </div>
              </div>
            )}

            <Button 
              type="submit" 
              disabled={loading}
              className="w-full bg-primary hover:bg-primary/90 text-white font-black h-14 rounded-2xl shadow-xl shadow-primary/10 transition-all active:scale-95 mt-4 text-base border-none"
            >
              {loading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <span className="flex items-center justify-center gap-2 uppercase tracking-widest">
                  {isLoginMode ? "GİRİŞ YAP" : "KAYIT OL"} <ArrowRight className="w-5 h-5" />
                </span>
              )}
            </Button>
          </form>

          <div className="mt-10 text-center space-y-6 pb-10">
            <button 
              onClick={() => setIsLoginMode(!isLoginMode)}
              className="text-[11px] font-black uppercase tracking-widest transition-colors text-orange-500 hover:text-orange-600"
            >
              {isLoginMode ? "Hesabınız yok mu? Hemen Üye Olun" : "Hesabınız var mı? Giriş Yapın"}
            </button>
            
            <p className="text-[9px] text-slate-300 font-bold px-4 leading-relaxed uppercase tracking-tighter">
              Devam ederek <span className="text-slate-400 underline cursor-pointer">Kullanım Koşulları</span> ve <br /><span className="text-slate-400 underline cursor-pointer">Gizlilik Sözleşmesini</span> onaylamış sayılırsınız.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}